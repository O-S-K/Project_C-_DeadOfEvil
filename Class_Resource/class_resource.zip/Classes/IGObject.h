#ifndef __IGOBJECT_H__
#define __IGOBJECT_H__

#include "cocos2d.h"
USING_NS_CC;

class IGObject : public cocos2d::Node
{
public:
	cocos2d::Sprite* spr;
	cocos2d::Sprite* sprBlood;
    CREATE_FUNC(IGObject);
};

#endif // __IGOBJECT_H__
