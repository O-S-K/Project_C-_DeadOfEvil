#ifndef __LOADINGSCENE_H__
#define __LOADINGSCENE_H__

#include "cocos2d.h"

class LoadingScene : public cocos2d::Scene
{
public:
	virtual bool init() override;
	CREATE_FUNC(LoadingScene);
private:
	void update(float);
	void loadPreAudio();
	cocos2d::ProgressTimer* loadProgress;
	int totalNum;
	int loadedNum;
};

#endif // __LOADINGSCENE_H__