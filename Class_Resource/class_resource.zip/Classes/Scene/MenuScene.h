#ifndef __MENUSCENE_H__
#define __MENUSCENE_H__

#include "cocos2d.h"
#include "cocos/ui/UIButton.h"
#include "cocos/ui/UIVideoPlayer.h"
#include "ui/CocosGUI.h"  
#include "SimpleAudioEngine.h"
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_IOS)  
using namespace cocos2d::experimental::ui;
#endif  
using namespace cocos2d::ui;
using namespace std;
using namespace cocos2d;
using namespace CocosDenshion;

class MenuScene : public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene();
	virtual bool init();

	bool playVideo;
	bool skipVideo = true;

	SimpleAudioEngine* musicBG;

	Sprite* sprFont;
	Sprite* sprBG;
	Sprite* sprKnight;
	Sprite* sprFox;

	void Video();
	void createButton();
	void createBackground();

	Sprite* createSprite(Sprite* sprBnt, const char* path, float scaleX, float scaleY, float posX, float posY, int oderInLayer);
	Animate* createAnimation(Sprite* spr, const char* spriteIndex, int countFrame, float speedFamre);

	void onClickSkipVideo(Ref* pSender, Widget::TouchEventType);
	void onClickStart(Ref* pSender, Widget::TouchEventType);
	void menuCloseCallback(Ref* pSender, Widget::TouchEventType);


#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_IOS)  
	cocos2d::experimental::ui::VideoPlayer* videoPlayer;
	void videoEventCallback(Ref* sender, cocos2d::experimental::ui::VideoPlayer::EventType eventType);
	bool tapToSkip = false;
#endif 

	CREATE_FUNC(MenuScene);
};

#endif // __MENUSCENE_H__
