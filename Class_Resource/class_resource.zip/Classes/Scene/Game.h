﻿#ifndef __GAME_H__
#define __GAME_H__

#include <string>
#include "Logic.h"
#include "cocos2d.h"
#include "Scene/UI.h"
#include "Scene/GameOver.h"
#include "Character/Shoot.h"
#include "Character/Player.h"
#include "cocos/ui/CocosGUI.h"
#include "cocos/ui/UIButton.h"
#include "State/TileMapGame.h"
#include "Character/Archery.h"
#include "Scene/InfiniteParallaxNode.h"
#include"Character/Enemy/Boss/Buffalo.h"
#include "Character/Enemy/Boss/Fireball.h"
#include "Character/Enemy/EnemyOnLand/TreeHurt.h"
#include "Character/Enemy/EnemyOnLand/SkeletonEnemy.h"
#include "Character/Enemy/EnemyOnLand/DullnessShoot.h"
#include "Object/Climb.h"
#include "Object/Chest.h"
#include "Object/ItemHP.h"

using namespace std;
using namespace cocos2d;
using namespace cocos2d::ui;

class Game : public cocos2d::Scene
{
	InfiniteParallaxNode* _backgroundElements;
	float randomValueBetween(float low, float high);

public:
	static cocos2d::Scene* createScene();
	virtual bool init();

	Size visibleSize;
	Vec2 visibleOrigin;

	Node* node;
	Vec2 nextPos;
	Node* nodeB;

	UI* uiCavas;
	Camera* camera;
	Vec2 posCam;
	int countDead = 0;

	Player* player;
	Buffalo* buffalo;
	SkeletonEnemy* skeletonEnemy;
	TreeHurt* treehurt;
	DullnessShoot* dullnessShoot;
	Climb* climb;
	Target* target;

	Sprite* bgMap1;
	Sprite* bgMap3;
	Sprite* bgMap4;
	Sprite* bgMap5;
	Sprite* bgMap6;

	TileMapGame* tileMapGame;
	Logic* logic;
	Archery* archery;
	Fireball* fireball;
	Shoot* shoot;
	Door* door;
	ItemHP* itemhp;

	SimpleAudioEngine* musicBG;
	bool turnOnSound ;


	void receiveEvent();
	void Follow();
	void createBackGround();
	void createSound();
	bool onContactBeginPlayer(const PhysicsContact& contact);
	bool onContactBeginEnemy(const PhysicsContact& contact);
	bool onContactObstancle(const PhysicsContact& contact);
	void shootEnemy(EventCustom* e);
	void shootWinzard(EventCustom* e);
	void shootBuffalo(EventCustom*);
	void onTurnSound(EventCustom*);
	void eventQuitMenuScene(EventCustom*);
	void update(float);
	void Pause();


	CREATE_FUNC(Game);
};

#endif //__GAME_H__
