﻿#include "MenuScene.h"
#include "Game.h"
#include "Scene/LoadingScene.h"
#include "cocos/ui/UIButton.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include "extensions/cocos-ext.h"
#include "cocos2d.h"
#include "cocos/ui/UIVideoPlayer.h"

USING_NS_CC;

using namespace ui;
using namespace CocosDenshion;

Scene* MenuScene::createScene()
{
	return MenuScene::create();
}

bool MenuScene::init()
{
	if (!Scene::init()) return false;

	auto visibleSize = Director::getInstance()->getVisibleSize();
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Map/BG/animBgMenu/bgAniamtion.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Map/BG/animKnight/anim-knight.plist");

#pragma region UserDefault
	auto checkQuit = UserDefault::sharedUserDefault()->getBoolForKey("checkQuit");

		// save index map
	if (checkQuit == false)
	{
		
		int indexMap = 1;
		int totalExp = 100;
		int levelPlayer = 1;
		int exp = 0;
		int hp = 100;
		float mp = 100;
		int damage = 35;
		float speed = 3.0F;
		int itemHP = 2;
		bool turnOnSound = true;
		bool playerSound = true;

		UserDefault* def = UserDefault::sharedUserDefault();
		def->setIntegerForKey("IndexMap", indexMap);
		def->setIntegerForKey("totalExpPlayer", totalExp);
		def->setIntegerForKey("LevelPlayer", levelPlayer);
		def->setIntegerForKey("expPlayer", exp);
		def->setIntegerForKey("hpPlayer", hp);
		def->setIntegerForKey("mpPlayer", mp);
		def->setIntegerForKey("damagePlayer", damage);
		def->setIntegerForKey("speedPlayer", speed);
		def->setIntegerForKey("itemhp", itemHP);
		def->setBoolForKey("turnOnSound", turnOnSound);
		def->setBoolForKey("playerSound", playerSound);
		def->flush();
	}
	else
	{
		UserDefault* defData = UserDefault::sharedUserDefault();
		auto indexMap = defData->getIntegerForKey("IndexMap");
		auto totalExp = defData->getIntegerForKey("totalExpPlayer");
		auto levelPlayer = defData->getIntegerForKey("LevelPlayer");
		auto exp = defData->getIntegerForKey("expPlayer");
		auto hp = defData->getIntegerForKey("hpPlayer");
		auto mp = defData->getIntegerForKey("mpPlayer");
		auto damage = defData->getIntegerForKey("damagePlayer");
		auto speed = defData->getIntegerForKey("speedPlayer");
		auto itemHP = defData->getIntegerForKey("itemhp");
		auto turnOnSound = defData->getBoolForKey("turnOnSound");
		auto playerSound = defData->getBoolForKey("playerSound");


		UserDefault* def = UserDefault::sharedUserDefault();
		def->setIntegerForKey("IndexMap", indexMap);
		def->setIntegerForKey("totalExpPlayer", totalExp);
		def->setIntegerForKey("LevelPlayer", levelPlayer);
		def->setIntegerForKey("expPlayer", exp);
		def->setIntegerForKey("hpPlayer", hp);
		def->setIntegerForKey("mpPlayer", mp);
		def->setIntegerForKey("damagePlayer", damage);
		def->setIntegerForKey("speedPlayer", speed);
		def->setIntegerForKey("itemhp", itemHP);
		def->setBoolForKey("turnOnSound", turnOnSound);
		def->setBoolForKey("playerSound", playerSound);

		def->flush();
	}

#pragma endregion

#pragma region Particle Effect
	auto particle = ParticleRain::create();
	particle->setPosition(visibleSize.width / 2, visibleSize.height);
	addChild(particle, 5);

#pragma endregion

#pragma region Video To Menu
	playVideo = UserDefault::sharedUserDefault()->getBoolForKey("playvideo");

	this->runAction(Sequence::create(
		CallFunc::create([&]() {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
			if (playVideo == false)
			{
				UserDefault* def = UserDefault::sharedUserDefault();
				playVideo = true;
				def->setBoolForKey("playvideo", playVideo);
				def->flush();

				Video();
			}
			else
			{
				musicBG = SimpleAudioEngine::getInstance();
				musicBG->playBackgroundMusic("Sounds/Theme/Firelink Shrine.mp3", true);

				createBackground();
				createButton();
			}
			}), DelayTime::create(37),
				CallFunc::create([&]() {
				if (tapToSkip == false)
				{
					removeChild(videoPlayer);
					musicBG = SimpleAudioEngine::getInstance();
					musicBG->playBackgroundMusic("Sounds/Theme/Firelink Shrine.mp3", true);

					createBackground();
					createButton();
				}
#endif
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32 )
				musicBG = SimpleAudioEngine::getInstance();
				musicBG->playBackgroundMusic("Sounds/Theme/Firelink Shrine.mp3", true);
				createBackground();
				createButton();
#endif
					}), nullptr));
#pragma endregion

	return true;
}
 



void MenuScene::Video() {

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

	auto visibleSize = Director::getInstance()->getVisibleSize();
	videoPlayer = cocos2d::experimental::ui::VideoPlayer::create();
	videoPlayer->setContentSize(visibleSize);
	videoPlayer->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	videoPlayer->setScale(visibleSize.width / videoPlayer->getContentSize().width,
		visibleSize.height / videoPlayer->getContentSize().height);
	videoPlayer->setFileName("video1.mp4");

	videoPlayer->play();
	this->addChild(videoPlayer, 5);
	videoPlayer->addEventListener(CC_CALLBACK_2(MenuScene::videoEventCallback, this));

#endif
}

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_IOS)  
void MenuScene::videoEventCallback(Ref* sender, cocos2d::experimental::ui::VideoPlayer::EventType eventType) {
	switch (eventType) {
	case cocos2d::experimental::ui::VideoPlayer::EventType::PLAYING:
		break;
	case cocos2d::experimental::ui::VideoPlayer::EventType::PAUSED:
		removeChild(videoPlayer);
		tapToSkip = true;
		musicBG = SimpleAudioEngine::getInstance();
		musicBG->playBackgroundMusic("Sounds/Theme/Firelink Shrine.mp3", true);

		createBackground();
		createButton();

		break;
	case cocos2d::experimental::ui::VideoPlayer::EventType::STOPPED:
		break;
	case cocos2d::experimental::ui::VideoPlayer::EventType::COMPLETED:
		break;
	default:
		break;
	}
}
#endif  

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
void MenuScene::onClickSkipVideo(Ref* pSender, Widget::TouchEventType type)
{
	if (type == Widget::TouchEventType::BEGAN)
	{
		videoPlayer->pause();
	}
}
#endif


void MenuScene::createButton() {


	auto visibleSize = Director::getInstance()->getVisibleSize();

	auto buttonStart = Button::create("Sprites/Map/BG/taptoplay.png");
	auto sizeS = buttonStart->getContentSize();
	buttonStart->setScale(visibleSize.width / sizeS.width, visibleSize.height / sizeS.height);
	buttonStart->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	buttonStart->addTouchEventListener(CC_CALLBACK_2(MenuScene::onClickStart, this));
	this->addChild(buttonStart, 9);

	buttonStart->runAction(RepeatForever::create(Sequence::create(FadeTo::create(2, 25),
		DelayTime::create(.25F), FadeTo::create(1, 100), DelayTime::create(1), nullptr)));

	auto buttonExit = Button::create("Sprites/UI/Buttons/btn-Exit.png");
	auto sizeE = buttonExit->getContentSize();
	buttonExit->setScale(visibleSize.width / sizeE.width * .05, visibleSize.height / sizeE.height * .075F);
	buttonExit->setPosition(Vec2(visibleSize.width / 18, visibleSize.height / 18));
	buttonExit->addTouchEventListener(CC_CALLBACK_2(MenuScene::menuCloseCallback, this));
	this->addChild(buttonExit, 10);
}

void MenuScene::createBackground() {

	sprFont = createSprite(sprFont, "Sprites/Map/BG/title-menu.png", 1, 1, 2, 2, 2);
	sprBG = createSprite(sprBG, "Sprites/Map/BG/animBgMenu/bg-anim (1).png", 1, 1, 2, 2, 0);
	sprKnight = createSprite(sprKnight, "Sprites/Map/BG/animBgMenu/bg-anim (1).png", 0.5F, 0.5F, 3, 5, 1);
	sprFox = createSprite(sprFox, "Sprites/Map/BG/fox.png", 0.21F, 0.21F, 1.5F, 6, 1);

	createAnimation(sprBG, "bg-anim (%d).png", 25, 0.075F);
	createAnimation(sprKnight, "knight (%d).png", 32, 0.25F);
}

void MenuScene::onClickStart(Ref* ref, Widget::TouchEventType type)
{
	if (type == Widget::TouchEventType::BEGAN)
	{
		auto audio = SimpleAudioEngine::getInstance();
		audio->playEffect("Sounds/SFX/Button/btn.wav");
		musicBG->pauseBackgroundMusic();
		Director::getInstance()->replaceScene(TransitionFade::create(0.5, LoadingScene::create()));
	}

}

void MenuScene::menuCloseCallback(Ref* pSender, Widget::TouchEventType type)
{
	if (type == Widget::TouchEventType::ENDED)
	{
		Director::getInstance()->end();
		UserDefault::sharedUserDefault()->deleteValueForKey("checkQuit");
		UserDefault::sharedUserDefault()->deleteValueForKey("playvideo");
		UserDefault::sharedUserDefault()->flush();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

		exit(0);
#endif
	}
}

Animate* MenuScene::createAnimation(Sprite* spr, const char* pathSprite, int countFrame, float speedFamre) {
	Vector<SpriteFrame*> animFrames;
	animFrames.reserve(countFrame);
	char spriteFrameByName[50] = { 0 };

	for (int index = 1; index < countFrame; index++)
	{
		sprintf(spriteFrameByName, pathSprite, index);
		auto frame = SpriteFrameCache::getInstance()->getSpriteFrameByName(spriteFrameByName);
		animFrames.pushBack(frame);
	}
	Animation* animation = Animation::createWithSpriteFrames(animFrames, speedFamre);
	Animate* animate = Animate::create(animation);
	spr->runAction(RepeatForever::create(animate));

	return animate;
}

Sprite* MenuScene::createSprite(Sprite* sprBnt, const char* path, float scaleX, float scaleY, float posX, float posY, int oderInLayer) {

	auto visibleSize = Director::getInstance()->getVisibleSize();

	sprBnt = Sprite::create(path);
	auto size = sprBnt->getContentSize();
	sprBnt->setScale(visibleSize.width / size.width * scaleX, visibleSize.height / size.height * scaleY);
	sprBnt->setPosition(visibleSize.width / posX, visibleSize.height / posY);
	this->addChild(sprBnt, oderInLayer);
	return sprBnt;
}
