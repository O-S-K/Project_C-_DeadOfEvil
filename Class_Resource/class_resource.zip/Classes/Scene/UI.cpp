﻿#include "Scene/UI.h"
#include "cocos/ui/UIButton.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"

UI* UI::createUI()
{
	return UI::create();
}

bool UI::init()
{
	if (!Layer::init()) return false;

	CreateButtonPlayer();
	CreateStatusBarPlayer();
	CreateButtonPause();
	CreateStatusBarBoss();
	receiveEvent();
	createButtonInfomationPlayer();
	auto getData = UserDefault::sharedUserDefault();
	countHP = getData->getIntegerForKey("itemhp");

	return true;
}

void UI::receiveEvent() {

	// event dispatcher
	auto touchListenerGame = EventListenerTouchOneByOne::create();
	auto touchListenerUI = EventListenerTouchOneByOne::create();
	auto touchListenerButtonInfor = EventListenerTouchOneByOne::create();

	touchListenerUI->onTouchBegan = CC_CALLBACK_2(UI::onTouchBeganPause, this);
	touchListenerGame->onTouchBegan = CC_CALLBACK_2(UI::onTouchBegan, this);
	touchListenerGame->onTouchMoved = CC_CALLBACK_2(UI::onTouchMove, this);
	touchListenerGame->onTouchEnded = CC_CALLBACK_2(UI::onTouchEnded, this);
	touchListenerButtonInfor->onTouchBegan = CC_CALLBACK_2(UI::onTouchBeganInfor, this);

	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListenerGame, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListenerUI, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListenerButtonInfor, this);

	// event Custom
	auto eventCustomTakeDamagePlayer = EventListenerCustom::create("TakeDamgeHPPlayer", CC_CALLBACK_1(UI::UpdateStatusHPBarPlayer, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventCustomTakeDamagePlayer, this);

	auto TakeDamgeHPBossBuffalo = EventListenerCustom::create("TakeDamgeHPBossBuffalo", CC_CALLBACK_1(UI::UpdateStatusHPBarBossBuffalo, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(TakeDamgeHPBossBuffalo, this);

	auto eventCustomFitnessMPPlayer = EventListenerCustom::create("FitnessMPPlayer", CC_CALLBACK_1(UI::UpdateStatusMPBarPlayer, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventCustomFitnessMPPlayer, this);

	auto eventCustomItem = EventListenerCustom::create("addItem", CC_CALLBACK_1(UI::UpdateItemHPPlayer, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventCustomItem, this);

	auto eventCustomRemoveItem = EventListenerCustom::create("removeItem", CC_CALLBACK_1(UI::removeItemHPPlayer, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventCustomRemoveItem, this);

}

void UI::removeItemHPPlayer(EventCustom* itemhp)
{
	player->countItemHp -= 1;
	countHP = player->countItemHp;
	for (int i = 0; i < itemHP.size(); i++)
	{
		if (itemHP.at(i) == itemHP.back())
		{
			itemHP.at(i)->removeFromParent();
			itemHP.erase(i);
		}
	}
}

void UI::UpdateItemHPPlayer(EventCustom* itemhp)
{
	addItemHP();
}

void UI::CreateButtonPlayer() {

	nodeButtonPlayer = Node::create();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32 )
	nodeButtonPlayer->setPositionY(this->getPositionY() + 1000000);
#endif
	this->addChild(nodeButtonPlayer);
	moveLeftBtn = createButton(moveLeftBtn, "Sprites/UI/ButtonGame/btn-arrowleft.png", .1F, .165F, 12, 5, 10, nodeButtonPlayer);
	moveRightBtn = createButton(moveRightBtn, "Sprites/UI/ButtonGame/btn-arrowRight.png", .1F, .165F, 5, 5, 10, nodeButtonPlayer);
	attackBtn = createButton(attackBtn, "Sprites/UI/ButtonGame/btn-attack.png", .075F, .125F, 1.24F, 7.5F, 10, nodeButtonPlayer);
	jumpBtn = createButton(jumpBtn, "Sprites/UI/ButtonGame/btn-jump.png", .11F, .185F, 1.095F, 6, 10, nodeButtonPlayer);
	rollBtn = createButton(rollBtn, "Sprites/UI/ButtonGame/btn-roll.png", .075F, .125F, 1.21F, 3.6F, 10, nodeButtonPlayer);
	recHPBtn = createButton(recHPBtn, "Sprites/UI/ButtonGame/btn-recHp.png", .075F, .125F, 1.095F, 2.85F, 10, nodeButtonPlayer);
	btnSound = createButton(btnSound, "Sprites/UI/Buttons/btn-Sound.png", .05f, .085f, 1.2F, 1.1F, 10, this);
}

void UI::CreateStatusBarPlayer() {
	Point visibleOrigin = Director::getInstance()->getVisibleOrigin();

	_bgStatusBar = Sprite::create("Sprites/UI/StatusBar/Player/bar-bg.png");
	auto sizeBgBar = _bgStatusBar->getContentSize();
	_bgStatusBar->setScale(visibleSize.width / sizeBgBar.width * .25F, visibleSize.height / sizeBgBar.height * .15F);
	_bgStatusBar->setPosition(visibleOrigin.x + visibleSize.width / 6, visibleOrigin.y + visibleSize.height / 1.125F);
	this->addChild(_bgStatusBar, 10);

	_hpPlayerBar = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Player/bar-hp.png"));
	auto sizeHpBar = _hpPlayerBar->getContentSize();
	_hpPlayerBar->setScale(visibleSize.width / sizeHpBar.width * .15F, visibleSize.height / sizeHpBar.height * .012F);

	_hpPlayerBar->setType(kCCProgressTimerTypeBar);
	_hpPlayerBar->setMidpoint(ccp(0, 0));
	_hpPlayerBar->setBarChangeRate(ccp(1, 0));
	auto hp = UserDefault::sharedUserDefault()->getIntegerForKey("hpPlayer");
	_hpPlayerBar->setPercentage(hp); // player -> hp
	_hpPlayerBar->setPosition(Size(_bgStatusBar->getPosition().x + 50, _bgStatusBar->getPosition().y + 28));
	addChild(_hpPlayerBar, 10);
	_mpBar = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Player/bar-mp.png"));
	auto sizeMp = _mpBar->getContentSize();
	_mpBar->setScale(visibleSize.width / sizeMp.width * .102F, visibleSize.height / sizeMp.height * .012F);

	_mpBar->setType(kCCProgressTimerTypeBar);
	_mpBar->setMidpoint(ccp(0, 0));
	_mpBar->setBarChangeRate(ccp(1, 0));
	_mpBar->setPercentage(100); // player -> mp
	_mpBar->setPosition(Size(_bgStatusBar->getPosition().x + 80, _bgStatusBar->getPosition().y + 2.75F));
	addChild(_mpBar, 10);
	defaulitemHp = _bgStatusBar->getPosition();
#pragma region Spawn sprite item HP

	// item HP
	auto distance = 0;
	auto getData = UserDefault::sharedUserDefault();
	auto countItemHP = getData->getIntegerForKey("itemhp");

	while (itemHP.size() < countItemHP)
	{
		_sprHP1 = Sprite::create("Sprites/UI/StatusBar/Player/item-hp.png");
		auto sizeHp = _sprHP1->getContentSize();
		_sprHP1->setScale(visibleSize.width / sizeHp.width * .0175F, visibleSize.height / sizeHp.height * .06F);
		_sprHP1->setPosition(_bgStatusBar->getPosition().x + distance, _bgStatusBar->getPosition().y - 35);
		this->addChild(_sprHP1, 5);
		itemHP.pushBack(_sprHP1);
		distance += 35;
	}

#pragma endregion
}

void UI::UpdateStatusHPBarPlayer(EventCustom* hp) {
	DataEvent* _hp = static_cast<DataEvent*>(hp->getUserData());
	_hpPlayerBar->setPercentage(_hp->hp); //player -> hp
}

void UI::UpdateStatusMPBarPlayer(EventCustom* mp) {
	DataEvent* _mp = static_cast<DataEvent*>(mp->getUserData());
	_mpBar->setPercentage(_mp->mp); //player -> mp
}

void UI::CreateStatusBarBoss() {

	auto indexMap = UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap");
	nodeStatusBoss = Node::create();
	this->addChild(nodeStatusBoss);

	if (indexMap == 6) nodeStatusBoss->setVisible(true);
	else nodeStatusBoss->setVisible(false);

	_bgStatusBar = Sprite::create("Sprites/UI/StatusBar/Boss/bar-bg.png");
	auto sizeBgBoss = _bgStatusBar->getContentSize();
	_bgStatusBar->setScale(visibleSize.width / sizeBgBoss.width * .4F, visibleSize.height / sizeBgBoss.height * .05F);
	_bgStatusBar->setPosition(visibleSize.width / 2, visibleSize.height / 18);
	nodeStatusBoss->addChild(_bgStatusBar, 9);

	_hpBossBuffaloBar = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Boss/bar-hp.png"));
	auto sizeHpBoss = _hpBossBuffaloBar->getContentSize();
	_hpBossBuffaloBar->setScale(visibleSize.width / sizeHpBoss.width * .335F, visibleSize.height / sizeHpBoss.height * .015F);
	_hpBossBuffaloBar->setType(kCCProgressTimerTypeBar);
	_hpBossBuffaloBar->setMidpoint(ccp(0, 0));
	_hpBossBuffaloBar->setBarChangeRate(ccp(1, 0));
	_hpBossBuffaloBar->setPercentage(100); //boss -> hp
	_hpBossBuffaloBar->setPosition(Size(_bgStatusBar->getPosition().x, _bgStatusBar->getPosition().y - 0.5F));
	nodeStatusBoss->addChild(_hpBossBuffaloBar, 10);
}

void UI::UpdateStatusHPBarBossBuffalo(EventCustom* hp) {

	DataEvent* _hp = static_cast<DataEvent*>(hp->getUserData());
	_hpBossBuffaloBar->setPercentage(_hp->hp / 20); //boss -> hp

	if (_hp->hp <= 0) {
		countDead += 1;
		if (countDead == 2)
			removeChild(nodeStatusBoss);
	}
}

void UI::removeItemHP()
{
	player->countItemHp -= 1;
	countHP = player->countItemHp;

	for (int i = 0; i < itemHP.size(); i++)
	{
		if (itemHP.at(i) == itemHP.back())
		{
			itemHP.at(i)->removeFromParent();
			itemHP.erase(i);
		}
	}
}

void UI::addItemHP()
{
	if (itemHP.size() <= 10) {

		if (!itemHP.empty())
		{
			player->countItemHp += 1;
			countHP = player->countItemHp;

			_sprHP1 = Sprite::create("Sprites/UI/StatusBar/Player/item-hp.png");
			auto sizeHp = _sprHP1->getContentSize();
			_sprHP1->setScale(visibleSize.width / sizeHp.width * .0175F, visibleSize.height / sizeHp.height * .06F);
			_sprHP1->setPosition(itemHP.back()->getPositionX() + 35, itemHP.back()->getPositionY());
			this->addChild(_sprHP1, 5);
			itemHP.pushBack(_sprHP1);
		}
		else if (itemHP.size() <= 10 && itemHP.empty())
		{
			player->countItemHp += 1;
			countHP = player->countItemHp;

			_sprHP1 = Sprite::create("Sprites/UI/StatusBar/Player/item-hp.png");
			auto sizeHp = _sprHP1->getContentSize();
			_sprHP1->setScale(visibleSize.width / sizeHp.width * .0175F, visibleSize.height / sizeHp.height * .06F);
			_sprHP1->setPosition(defaulitemHp.x, defaulitemHp.y - 30);
			this->addChild(_sprHP1, 5);
			itemHP.pushBack(_sprHP1);
		}
	}
}

bool UI::onTouchBegan(Touch* touch, Event* event) {

	if (isTouch == 0) {
		auto touchPoint = touch->getLocation();

		if (moveLeftBtn->getBoundingBox().containsPoint(touchPoint))
		{
			DataEvent* data = new DataEvent();
			data->isMoveLeft = true;
			EventCustom event("eventMoveLeft");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}

		if (moveRightBtn->getBoundingBox().containsPoint(touchPoint))
		{
			DataEvent* data = new DataEvent();
			data->isMoveRight = true;
			EventCustom event("eventMoveRight");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}

		if (attackBtn->getBoundingBox().containsPoint(touchPoint))
		{
			DataEvent* data = new DataEvent();
			data->canAttack = true;
			EventCustom event("eventAttack");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}
		else if (jumpBtn->getBoundingBox().containsPoint(touchPoint))
		{
			DataEvent* data = new DataEvent();
			data->canJump = true;
			EventCustom event("eventJump");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}
		else if (rollBtn->getBoundingBox().containsPoint(touchPoint))
		{
			DataEvent* data = new DataEvent();
			data->canRoll = true;
			EventCustom event("eventRoll");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}
		else if (recHPBtn->getBoundingBox().containsPoint(touchPoint))
		{
			if (player->hp < 100 && player->hp > 0 && player->isLand)
			{
				DataEvent* data = new DataEvent();
				data->recHP = true;
				removeItemHP();
				EventCustom event("eventRecHP");
				event.setUserData(data);
				_eventDispatcher->dispatchEvent(&event);
			}
		}
	}
	return true;
}

bool UI::onTouchMove(Touch* touch, Event* event)
{
	if (isTouch == 0) {
		auto touchPoint = touch->getLocation();

		if (moveLeftBtn->getBoundingBox().containsPoint(touchPoint) && playerIsMoveLeft != true)
		{
			playerIsMoveLeft = true;
			playerIsMoveRight = false;

			DataEvent* data = new DataEvent();
			data->isMoveLeft = true;
			EventCustom event("eventMoveLeft");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}

		if (moveRightBtn->getBoundingBox().containsPoint(touchPoint) && playerIsMoveRight != true)
		{
			playerIsMoveRight = true;
			playerIsMoveLeft = false;
			DataEvent* data = new DataEvent();
			data->isMoveRight = true;

			EventCustom event("eventMoveRight");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}

		if (!moveRightBtn->getBoundingBox().containsPoint(touchPoint) && !moveLeftBtn->getBoundingBox().containsPoint(touchPoint))
		{
			log("vao checkl");
			playerIsMoveRight = false;
			playerIsMoveLeft = false;
			DataEvent* data = new DataEvent();
			data->moveDir = 0;

			EventCustom event("eventEndMove");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}
	}
	return true;
}

void UI::onTouchEnded(Touch* touch, Event* event) {

	if (isTouch == 0) {
		auto touchPoint = touch->getLocation();

		if (btnSound->getBoundingBox().containsPoint(touchPoint))
		{
			log("btnsoundend");

			DataEvent* data = new DataEvent();
			data->offSound = true;
			EventCustom event("eventSound");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}

		if (moveLeftBtn->getBoundingBox().containsPoint(touchPoint))
		{
			DataEvent* data = new DataEvent();
			data->isMoveLeft = false;

			EventCustom event("eventMoveLeft");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}


		if (moveRightBtn->getBoundingBox().containsPoint(touchPoint))
		{
			DataEvent* data = new DataEvent();
			data->isMoveRight = false;

			EventCustom event("eventMoveRight");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}

		if ((!moveRightBtn->getBoundingBox().containsPoint(touchPoint)
			|| !moveLeftBtn->getBoundingBox().containsPoint(touchPoint))
			&& (!recHPBtn->getBoundingBox().containsPoint(touchPoint)
				/*&& !rollBtn->getBoundingBox().containsPoint(touchPoint)*/))
		{
			DataEvent* data = new DataEvent();
			data->moveDir = 0;

			EventCustom event("eventEndMove");
			event.setUserData(data);
			_eventDispatcher->dispatchEvent(&event);
		}
	}
}

void UI::CreateButtonPause() {

	btnPause = createButton(btnPause, "Sprites/UI/Buttons/btn-Pause.png", .05F, .075F, 1.075F, 1.1F, 10, this);

	// create tbable and button Pause
	nodeButtonPause = Node::create();
	nodeButtonPause->setPosition(visibleOrigin.x + visibleSize.width / 2, visibleOrigin.y + visibleSize.height / 2);
	this->addChild(nodeButtonPause);

	tablePause = Sprite::create("Sprites/UI/Buttons/table-pause.png");
	auto sizeTP = tablePause->getContentSize();
	tablePause->setScale(visibleSize.width / sizeTP.width, visibleSize.height / sizeTP.height);
	nodeButtonPause->addChild(tablePause, 11);
	nodeButtonPause->setVisible(false);

	auto nodeButtonTable = Node::create();
	nodeButtonPause->addChild(nodeButtonTable);

	btnResume = createButton(btnResume, "Sprites/UI/Buttons/bg-button.png", 0.2F, 0.125F, 2, 1.85F, 12, nodeButtonTable);
	//btnSetting = createButton(btnResume, "Sprites/UI/Buttons/bg-button.png", 0.2F, 0.125F, 2, 2.75F, 12, nodeButtonTable);
	btnQuit = createButton(btnQuit, "Sprites/UI/Buttons/bg-button.png", 0.2F, 0.125F, 2, 2.75F, 12, nodeButtonTable);
}

void UI::createButtonInfomationPlayer()
{
	btnInfo = createButton(btnInfo, "Sprites/Information/button-info.png", 0.055F, 0.0975F, 12, 1.125F, 12, this);

	nodeButtonInfo = Node::create();
	this->addChild(nodeButtonInfo);
	nodeButtonInfo->setVisible(false);

	tableInformation = Sprite::create("Sprites/Information/infomation.png");
	auto sizeTB = tableInformation->getContentSize();
	tableInformation->setPosition(visibleSize.width / 2, visibleSize.height / 2);
	tableInformation->setScale(visibleSize.width / sizeTB.width * 0.3F,
		visibleSize.height / sizeTB.height * 0.75F);
	nodeButtonInfo->addChild(tableInformation, 12);

	//create data infor player
	levelPlayer = ShowInfoPlayer(levelPlayer, "LevelPlayer", "%d", 75, nodeButtonInfo);
	expPlayer = ShowInfoPlayer(expPlayer, "expPlayer", "%d", 25, nodeButtonInfo);
	HP = ShowInfoPlayer(HP, "hpPlayer", "%d", -25, nodeButtonInfo);
	MP = ShowInfoPlayer(MP, "mpPlayer", "%d", -75, nodeButtonInfo);
	Damage = ShowInfoPlayer(Damage, "damagePlayer", "%d", -125, nodeButtonInfo);
	speed = ShowInfoPlayer(speed, "speedPlayer", "%d", -175, nodeButtonInfo);
	nodeButtonInfo->getScheduler();
}

bool UI::onTouchBeganPause(Touch* touch, Event* event) {

	auto touchPoint = touch->getLocation();

	if (btnPause->getBoundingBox().containsPoint(touchPoint)) {
		nodeButtonPlayer->setVisible(false);
		nodeButtonPause->setVisible(true);
		isTouch = 2;
	}
	if (isTouch == 2) {
		if (btnResume->getBoundingBox().containsPoint(touchPoint)) {
			isTouch = 0;
			nodeButtonPlayer->setVisible(true);
			nodeButtonPause->setVisible(false);
		}
		//else if (btnSetting->getBoundingBox().containsPoint(touchPoint)) {
		//	log("ON btnSetting");
		//	//this->removeChild(tablePause);
		//}
		else if (btnQuit->getBoundingBox().containsPoint(touchPoint)) {

			EventCustom eventQit("eventQuit");
			_eventDispatcher->dispatchEvent(&eventQit);
			Director::getInstance()->replaceScene(MenuScene::create());


		}
	}
	return true;
}

bool UI::onTouchBeganInfor(Touch* touch, Event* event)
{
	auto touchPoint = touch->getLocation();

	if (btnInfo->getBoundingBox().containsPoint(touchPoint)) {
		nodeButtonPlayer->setVisible(false);
		nodeButtonInfo->setVisible(true);
		updateInforPlayer();
	}
	else
	{
		nodeButtonPlayer->setVisible(true);
		nodeButtonInfo->setVisible(false);
	}
	return true;
}

void UI::updateInforPlayer()
{
	levelPlayer->setString(StringUtils::format("Level        : %d", player->level));
	expPlayer->setString(StringUtils::format("Exp           : %d/%d", player->currentExp, player->totalExp));
	HP->setString(StringUtils::format("HP            : %d", player->hp));
	MP->setString(StringUtils::format("Mp            : %.0f", player->mp));
	Damage->setString(StringUtils::format("Damage    : %d", player->damage));
	speed->setString(StringUtils::format("Speed       : %.2f", player->moveForce));
}

Sprite* UI::createButton(Sprite* sprBnt, const char* path, float scaleX, float scaleY, float posX, float posY, int oderInLayer, Node* node) {

	visibleSize = Director::getInstance()->getVisibleSize();
	visibleOrigin = Director::getInstance()->getVisibleOrigin();
	sprBnt = Sprite::create(path);
	auto size = sprBnt->getContentSize();
	sprBnt->setScale(visibleSize.width / size.width * scaleX, visibleSize.height / size.height * scaleY);
	sprBnt->setPosition(visibleSize.width / posX, visibleSize.height / posY);
	node->addChild(sprBnt, oderInLayer);
	return sprBnt;
}

Label* UI::ShowInfoPlayer(Label* labelName, const char* nameData, const char* showData, float discance, Node* node) {

	stringInfo = StringUtils::format(showData, UserDefault::sharedUserDefault()->getIntegerForKey(nameData));
	labelName = Label::createWithSystemFont(stringInfo, "fonts/pixel.ttf", 27);
	labelName->setAnchorPoint(Vec2(0, .5F));
	labelName->setPosition(visibleSize.width / 2.5F, visibleSize.height / 2 + discance);
	node->addChild(labelName, 18);
	return labelName;
}