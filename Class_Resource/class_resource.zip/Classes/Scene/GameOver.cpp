#include "GameOver.h"
#include "MenuScene.h"
#include "SimpleAudioEngine.h"
#include "cocos/ui/UIButton.h"
#include "ui/CocosGUI.h"
#include "Scene/LoadingScene.h"

USING_NS_CC;

bool GameOver::init()
{
	if (!Scene::init()) return false;

	auto visibleSize = Director::getInstance()->getVisibleSize();

	auto audio = CocosDenshion::SimpleAudioEngine::getInstance();
	audio->playEffect("Sounds/Theme/themeDeath.mp3", false, 1.0f, 1.0f, 1.0f);

	buttonBackMenu = Sprite::create("Sprites/Map/BG/you-die.png");
	auto size = buttonBackMenu->getContentSize();
	buttonBackMenu->setScale(visibleSize.width / size.width, visibleSize.height / size.height);
	buttonBackMenu->setPosition(visibleSize.width / 2, visibleSize.height / 2);
	this->addChild(buttonBackMenu);
	buttonBackMenu->setOpacity(0);

	this->schedule(schedule_selector(GameOver::update));
	return true;
}

void GameOver::update(float dt) {
	if (Opacity <= 200) {
		Opacity += 1;
		buttonBackMenu->setOpacity((int)Opacity);

		auto touchListener = EventListenerTouchOneByOne::create();
		touchListener->onTouchBegan = CC_CALLBACK_2(GameOver::onClickBackMenu, this);
		_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);
	}
}

void GameOver::menuCloseCallback(Ref* pSender, cocos2d::ui::Widget::TouchEventType type)
{
	Director::getInstance()->end();
}

bool GameOver::onClickBackMenu(Touch* touch, Event* event)
{
	auto touchPoint = touch->getLocation();
	if (buttonBackMenu->getBoundingBox().containsPoint(touchPoint))
	{
		this->runAction(Sequence::create(DelayTime::create(2), 
			CallFunc::create([&]() {
			Director::getInstance()->replaceScene(LoadingScene::create());
			}), nullptr));
	}
	return true;
}
