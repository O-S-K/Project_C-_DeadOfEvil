#include "SimpleAudioEngine.h"
#include "LoadingScene.h"
#include "Scene/Game.h"

using namespace cocos2d;
using namespace CocosDenshion;


bool LoadingScene::init()
{
	if (!Scene::init()) return false;

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 visibleOrigin = Director::getInstance()->getVisibleOrigin();

	int hpPlayer = 100;
	UserDefault* defHP = UserDefault::sharedUserDefault();
	defHP->setIntegerForKey("hpPlayer", hpPlayer);
	defHP->flush();
	defHP->getIntegerForKey("hpPlayer", hpPlayer);

	auto sprBG = Sprite::create("Sprites/Map/BG/bg-loading.png");
	auto sizeBG = sprBG->getContentSize();
	sprBG->setScale(visibleSize.width / sizeBG.width,
		visibleSize.height / sizeBG.height);
	sprBG->setAnchorPoint(Vec2(0, 0));
	this->addChild(sprBG);

	Sprite* progressBG = Sprite::create("Sprites/UI/Loading/bgloading.png");
	auto sizePrs = progressBG->getContentSize();
	progressBG->setContentSize(Size(sizePrs.width / 2, sizePrs.height / 4.25F));
	progressBG->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 20));
	this->addChild(progressBG);

	loadProgress = ProgressTimer::create(Sprite::create("Sprites/UI/Loading/loading.png"));
	loadProgress->setColor(Color3B::RED);
	loadProgress->setBarChangeRate(Vec2(1, 0));
	loadProgress->setType(ProgressTimer::Type::BAR);
	loadProgress->setMidpoint(Vec2(0, 1));

	Size progressSize = loadProgress->getContentSize();
	auto sizeLoad = loadProgress->getContentSize();

	loadProgress->setContentSize(Size(sizeLoad.width /2, sizeLoad.height / 8));
	loadProgress->setPosition(progressBG->getPosition().x, progressBG->getPosition().y - 6.5F);
	loadProgress->setPercentage(0.1f);
	this->addChild(loadProgress);

	totalNum = 200;
	loadedNum = 0;

	loadPreAudio();
	this->schedule(schedule_selector(Game::update));
	return true;
}

void LoadingScene::update(float dt) {

	if (loadedNum < totalNum) {
		loadedNum += 1;
		loadProgress->setPercentage(((float)loadedNum) / totalNum * 50);
	}
	else if (loadedNum >= totalNum)
	{
		TransitionScene* transition = TransitionFade::create(1.0f, Game::createScene());
		Director::getInstance()->replaceScene(transition);
	}
}

void LoadingScene::loadPreAudio() {

	auto audioFX = SimpleAudioEngine::getInstance();
	audioFX->preloadEffect("Sounds/SFX/Player/jump3.wav");
	audioFX->preloadEffect("Sounds/SFX/Player/attack1.wav");
	audioFX->preloadEffect("Sounds/SFX/Player/roll1.wav");
	audioFX->preloadEffect("Sounds/SFX/Player/recHp1.wav");
	audioFX->preloadEffect("Sounds/SFX/Player/takedamage.wav");
	audioFX->preloadEffect("Sounds/SFX/Player/dead1.wav");
}