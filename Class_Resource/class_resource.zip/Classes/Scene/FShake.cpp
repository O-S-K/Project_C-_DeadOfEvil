#include "FShake.h"

FShake::FShake() : _strength_x(0), _strength_y(0), _displacement_x(0), _displacement_y(0) {}


FShake* FShake::create(float duration, float strength)
{
	return create(duration, strength, strength);
}

FShake* FShake::actionWithDuration(float duration, float strength)
{
	return create(duration, strength, strength);
}

FShake* FShake::actionWithDuration(float duration, float strength_x, float strength_y)
{
	return create(duration, strength_x, strength_y);
}

FShake* FShake::create(float duration, float strength_x, float strength_y)
{
	FShake* p_action = new FShake();
	p_action->initWithDuration(duration, strength_x, strength_y);
	p_action->autorelease();

	return p_action;
}

bool FShake::initWithDuration(float duration, float strength_x, float strength_y)
{
	if (cocos2d::ActionInterval::initWithDuration(duration))
	{
		_strength_x = strength_x;
		_strength_y = strength_y;
		return true;
	}

	return false;
}

float fgRangeRand(float min, float max)
{
	float random = ((float)rand() / (float)RAND_MAX);
	return random * (max - min) + min;
}

void FShake::update(float time)
{
	auto target = this->getTarget();
	if (!target) { return; }

	float rand_x = fgRangeRand(-_strength_x, _strength_x);
	float rand_y = fgRangeRand(-_strength_y, _strength_y);

	target->setPosition(
		target->getPosition().x - _displacement_x /*+ rand_x*/,
		target->getPosition().y - _displacement_y /*+ rand_y*/
	);

	_displacement_x = rand_x;
	_displacement_y = rand_y;
}

void FShake::stop(void)
{
	auto target = this->getTarget();
	if (target)
	{
		target->setPosition(target->getPosition().x - _displacement_x,
			target->getPosition().y - _displacement_y);
	}

	ActionInterval::stop();
}

FShake* FShake::clone()
{
	auto a = new (std::nothrow) FShake();
	a->initWithDuration(_duration, _strength_x, _strength_y);
	a->autorelease();
	return a;
}
