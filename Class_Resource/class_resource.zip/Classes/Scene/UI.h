#ifndef __UI_H__
#define __UI_H__

#include "cocos2d.h"
#include "cocos/ui/CocosGUI.h"
#include "cocos/ui/UIButton.h"
#include "Character/Player.h"
#include "Scene/MenuScene.h"


USING_NS_CC;

using namespace cocos2d::ui;
using namespace cocos2d;
using namespace std;

class UI : public Layer
{
public:
	static UI* createUI();
	virtual bool init();

	Size visibleSize;
	Point visibleOrigin;

	Node* nodeButtonPlayer;
	Node* nodeButtonInfo;
	Node* nodeButtonPause;
	Node* nodeStatusBoss;

	int countHP;
	int isTouch = 0;
	int countRecHP = 2;
	int countDead = 0;

	ProgressTimer* _hpPlayerBar;
	ProgressTimer* _mpBar;
	ProgressTimer* _hpBossBuffaloBar;

	Sprite* btnPause;
	Sprite* btnResume;
	Sprite* btnSetting;
	Sprite* btnQuit;
	Sprite* btnSound;

	Sprite* tablePause;
	Sprite* tableInformation;

	Sprite* _bgStatusBar;
	Sprite* _sprBGHP1;
	Sprite* _sprBGHP2;
	Sprite* _sprHP1;
	Sprite* _sprHP2;

	Sprite* moveLeftBtn;
	Sprite* moveRightBtn;

	Sprite* attackBtn;
	Sprite* jumpBtn;
	Sprite* rollBtn;
	Sprite* recHPBtn;
	Sprite* btnInfo;


	Player* player;
	Label* levelPlayer;
	Label* expPlayer;
	Label* HP;
	Label* MP;
	Label* Damage;
	Label* speed;
	string stringInfo;
	Vec2 defaulitemHp;

	bool playerIsMoveLeft;
	bool playerIsMoveRight;

	cocos2d::Vector<Sprite*> itemHP;

	void receiveEvent();
	void CreateButtonPlayer();
	void CreateStatusBarPlayer();
	void UpdateStatusHPBarPlayer(EventCustom* hp);
	void UpdateStatusMPBarPlayer(EventCustom* hp);
	void UpdateItemHPPlayer(EventCustom* itemhp);
	void removeItemHPPlayer(EventCustom* itemhp);

	void CreateStatusBarBoss();
	void UpdateStatusHPBarBossBuffalo(EventCustom* hp);
	void createButtonInfomationPlayer();
	void removeItemHP();
	void addItemHP();

	void CreateButtonPause();
	void updateInforPlayer();

	bool onTouchBegan(Touch* touch, Event* event);
	bool onTouchMove(Touch* touch, Event* event);
	bool onTouchBeganPause(Touch* touch, Event* event);
	void onTouchEnded(Touch* touch, Event* event);
	void onTouchCancel(Touch* touch, Event* event);
	bool onTouchBeganInfor(Touch* touch, Event* event);

	Label* ShowInfoPlayer(Label* labelName, const char* nameData, const char* showData, float discance, Node* node);
	Sprite* createButton(Sprite* sprBnt, const char* path, float scaleX, float scaleY, float posX, float posY, int oderInlayer, Node*);

	CREATE_FUNC(UI);
};

#endif // __UI_H__
