﻿#include "Game.h"
#include "Unit.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"
#include "Character/DataArchery.h"
#include "Character/Player.h"
#include "Character/Enemy/Enemy.h"
#include "State/TileMapGame.h"
#include "cocos/ui/UIButton.h"
#include "Scene/FShake.h"

using namespace std;
USING_NS_CC;

Scene* Game::createScene()
{
	return Game::create();
}

bool Game::init()
{
	if (!Scene::initWithPhysics()) return false;

	visibleSize = Director::getInstance()->getVisibleSize();
	 _physicsWorld->setGravity(Vec2(0, -981));
	turnOnSound = UserDefault::sharedUserDefault()->getBoolForKey("turnOnSound");

	logic = new Logic();
	player = new Player();
	buffalo = new Buffalo();

	uiCavas = UI::createUI();
	this->addChild(uiCavas, 10);

	tileMapGame = TileMapGame::createTileMapGame();
	this->addChild(tileMapGame);

	player = tileMapGame->player;
	uiCavas->player = player;
	

	logic = tileMapGame->logic;
	logic->player = player;

	buffalo = tileMapGame->buffalo;
	logic->buffalo = buffalo;

	door = tileMapGame->door;
	logic->door = door;

	target = tileMapGame->target;

	receiveEvent();
	createSound();
	createBackGround();

	this->schedule(schedule_selector(Game::update));
	return true;
}

void Game::update(float dt)
{
	Follow();
	logic->Move(dt);
	Pause();
	if (logic->checkStatePlayer() == true)
	{
		this->pauseSchedulerAndActions();
		removeChild(uiCavas);
		player->playerBody->removeFromWorld();
		player->dead();
	}
}

void Game::Pause()
{
	if (player->hp <= 0)
	{
		Camera::getDefaultCamera()->stopAllActions();
		musicBG->pauseBackgroundMusic();
		this->removeChild(uiCavas);
		this->pauseSchedulerAndActions();
	}
}

void Game::receiveEvent() {

	auto playerContactListener = EventListenerPhysicsContact::create();
	playerContactListener->onContactBegin = CC_CALLBACK_1(Game::onContactBeginPlayer, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(playerContactListener, this);

	auto enemyContactListener = EventListenerPhysicsContact::create();
	enemyContactListener->onContactBegin = CC_CALLBACK_1(Game::onContactBeginEnemy, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(enemyContactListener, this);

	auto obstanceContactListener = EventListenerPhysicsContact::create();
	obstanceContactListener->onContactBegin = CC_CALLBACK_1(Game::onContactObstancle, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(obstanceContactListener, this);

	auto eventCustom = EventListenerCustom::create("DullnessShoot", CC_CALLBACK_1(Game::shootEnemy, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventCustom, this);

	auto eventWinzardShoot = EventListenerCustom::create("WinzardShoot", CC_CALLBACK_1(Game::shootWinzard, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventWinzardShoot, this);

	auto eventShootBuffalo = EventListenerCustom::create("BuffaloShoot", CC_CALLBACK_1(Game::shootBuffalo, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventShootBuffalo, this);


	auto eventSound = EventListenerCustom::create("eventSound", CC_CALLBACK_1(Game::onTurnSound, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventSound, this);


	auto eventBtnQuit = EventListenerCustom::create("eventQuit", CC_CALLBACK_1(Game::eventQuitMenuScene, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventBtnQuit, this);
}
void Game::eventQuitMenuScene(EventCustom* e)
{

	auto indexMap = UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap");
	UserDefault* def = UserDefault::sharedUserDefault();
	auto checkQuit = true;
	def->setIntegerForKey("IndexMap", indexMap );
	def->setIntegerForKey("LevelPlayer", player->level);
	def->setIntegerForKey("totalExpPlayer", player->totalExp);
	def->setIntegerForKey("expPlayer", player->currentExp);
	def->setIntegerForKey("hpPlayer", player->hp);
	def->setIntegerForKey("mpPlayer", player->mp);
	def->setIntegerForKey("damagePlayer", player->damage);
	def->setIntegerForKey("speedPlayer", player->moveForce);
	player->countItemHp = uiCavas->countHP;
	def->setIntegerForKey("itemhp", player->countItemHp);
	def->setBoolForKey("turnOnSound", turnOnSound);
	def->setBoolForKey("playerSound", player->playSound);
	def->setBoolForKey("checkQuit", checkQuit);
	def->flush();
}


void Game::onTurnSound(EventCustom* e)
{
	if (turnOnSound == true)
	{
		turnOnSound = false;
		player->playSound = false;
		UserDefault* def = UserDefault::sharedUserDefault();
		def->setBoolForKey("playerSound", player->playSound);
		musicBG = SimpleAudioEngine::getInstance();
		musicBG->pauseBackgroundMusic();
		/*player->audioFX = SimpleAudioEngine::getInstance();
		player->audioFX->pauseAllEffects();*/
	}
	else
	{
		player->playSound = true;
		UserDefault* def = UserDefault::sharedUserDefault();
		def->setBoolForKey("playerSound", player->playSound);
		turnOnSound = true;
		musicBG = SimpleAudioEngine::getInstance();
		musicBG->resumeBackgroundMusic();
		//player->audioFX = SimpleAudioEngine::getInstance();
		//player->audioFX->resumeAllEffects();
	}
}

void Game::Follow()
{
	// Camera Follow Player
	camera = Camera::getDefaultCamera();
	posCam = camera->getPosition();

	auto camTarget = Vec2(posCam.x, (posCam.y * 0.25f));
	auto setupPosCamera = ccpLerp(player->getPosition() + Vec2(0, 425), camTarget, 0.5F);

	if (player->state != STATE::DEAD) {
		//camera->setPosition(setupPosCamera);
		camera->setPosition3D(Vec3(setupPosCamera.x, setupPosCamera.y, 375));
	}

	//Cavas Follow Camera
	uiCavas->setPositionX(camera->getPositionX() - 640);
	uiCavas->setPositionY(camera->getPositionY() - 360);
	uiCavas->setPositionZ(player->getPositionZ() - 245);

	// BackGround Follow Player
	auto indexMap = UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap");

	if (indexMap == 1 || indexMap == 2 || indexMap == 3) {
		bgMap1->setPosition(Vec2(posCam.x, posCam.y));
	}
	else if (indexMap == 4) {
		bgMap6->setPosition(Vec2(posCam.x, posCam.y));
	}
	else if (indexMap == 5) {
		bgMap4->setPosition(Vec2(posCam.x, posCam.y));
	}
	else if (indexMap == 6) {
		bgMap5->setPosition(Vec2(posCam.x, posCam.y));
	}
}

void Game::createSound() {
	auto indexMap = UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap");
	musicBG = SimpleAudioEngine::getInstance();

	if (indexMap == 1) {
		musicBG->preloadBackgroundMusic("Sounds/Theme/Castlecall.mp3");
		musicBG->playBackgroundMusic("Sounds/Theme/Castlecall.mp3", true);
	}
	else if (indexMap == 2) {
		musicBG->preloadBackgroundMusic("Sounds/Theme/lv2.mp3");
		musicBG->playBackgroundMusic("Sounds/Theme/lv2.mp3", true);
	}
	else if (indexMap == 3) {
		musicBG->preloadBackgroundMusic("Sounds/Theme/lv3.mp3");
		musicBG->playBackgroundMusic("Sounds/Theme/lv3.mp3", true);
	}
	else if (indexMap == 4) {
		musicBG->preloadBackgroundMusic("Sounds/Theme/lv4.mp3");
		musicBG->playBackgroundMusic("Sounds/Theme/lv4.mp3", true);
	}
	else if (indexMap == 6) {
		musicBG->preloadBackgroundMusic("Sounds/Theme/boss.mp3");
		musicBG->playBackgroundMusic("Sounds/Theme/boss.mp3", true);
	}
}

void Game::createBackGround()
{
	auto indexMap = UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap");

	bgMap1 = Sprite::create("Sprites/Map/BG/map1.png");
	this->addChild(bgMap1, -5);
	bgMap1->setVisible(false);

	bgMap4 = Sprite::create("Sprites/Map/BG/map4.png");
	this->addChild(bgMap4, -5);
	bgMap4->setVisible(false);

	bgMap5 = Sprite::create("Sprites/Map/BG/map5.png");
	this->addChild(bgMap5, -5);
	bgMap5->setVisible(false);

	bgMap6 = Sprite::create("Sprites/Map/BG/map6.png");
	this->addChild(bgMap6, -5);
	bgMap6->setVisible(false);

	if (indexMap == 1 || indexMap == 2 || indexMap == 3) {
		bgMap1->setVisible(true);
	}
	else if (indexMap == 4) {
		bgMap6->setVisible(true);
		bgMap1->setVisible(false);
	}
	else if (indexMap == 5) {
		bgMap4->setVisible(true);
		bgMap1->setVisible(false);
		bgMap6->setVisible(false);
	}
	else if (indexMap == 6) {
		bgMap5->setVisible(true);
		bgMap1->setVisible(false);
		bgMap6->setVisible(false);
		bgMap4->setVisible(false);

		auto particle = ParticleRain::create();
		particle->setPosition(visibleSize.width / 2, visibleSize.height);
		addChild(particle, -10);
	}
}

void Game::shootEnemy(EventCustom* e)
{
	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto data = static_cast<DataArchery*>(e->getUserData());

	archery = Archery::create("Sprites/Gameplay/Enemy/EnemyOnland/DullnessShoot/archery/archery.png");
	auto size = archery->spr->getContentSize();

	archery->setPosition(data->m_posbullet);
	archery->setRotation(data->m_dirbullet);
	archery->setScale(visibleSize.width / size.width * .02f, visibleSize.height / size.height * .015f);
	logic->listArchery.pushBack(archery);
	this->addChild(archery, 5);
}
void Game::shootWinzard(EventCustom* e)
{
	auto visibleSize = Director::getInstance()->getVisibleSize();

	auto data = static_cast<DataShootWinzard*>(e->getUserData());
	shoot = Shoot::create("Sprites/Object/Bullet/bullet (4).png",
		data->positionPlayer, data->positionShoot, logic->winzardSize);
	shoot->setPosition(data->positionShoot);
	logic->listShootWinzard.pushBack(shoot);
	this->addChild(shoot, 5);
}
void Game::shootBuffalo(EventCustom* eventBuffalo)
{
	auto dataFireball = static_cast<DataFireball*>(eventBuffalo->getUserData());
	auto visibleSize = Director::getInstance()->getVisibleSize();

	for (int i = 0; i < 2; i++)
	{
		fireball = Fireball::create("Sprites/Gameplay/Enemy/Boss/Buffalo/Shoot/Fireball (1).png");
		fireball->setScale(visibleSize.width / fireball->spr->getContentSize().width * .125f,
			visibleSize.height / fireball->spr->getContentSize().height * .04);
		if (i == 0)
		{
			fireball->setPosition(dataFireball->positionLeftFireball);
			fireball->isLeft = true;
			fireball->spr->setFlippedX(false);
			fireball->boydShoot->setPositionOffset(Vec2(20, 0));
		}
		else
		{
			fireball->spr->setFlippedX(true);
			fireball->boydShoot->setPositionOffset(Vec2(110, 0));
			fireball->setPosition(dataFireball->positionRightFireball);
			fireball->isLeft = false;
		}
		logic->listFireball.pushBack(fireball);
		this->addChild(fireball, 5);
	}
}

bool Game::onContactBeginPlayer(const cocos2d::PhysicsContact& contact)
{
	auto ShapeA = contact.getShapeA()->getBody()->getNode();
	auto ShapeB = contact.getShapeB()->getBody()->getNode();

#pragma region Enemy
	// check weapon-player vs enemy skeleton
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_ENEMY_SKELETON) ||
		(ShapeA->getTag() == SET_TAG_ENEMY_SKELETON && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_ENEMY_SKELETON) node = ShapeB;
		if (node->getTag() == SET_TAG_ENEMY_SKELETON) {

			auto nodeEnemy = static_cast<SkeletonEnemy*> (node);
			nodeEnemy->takeDamge(player->damage, nodeEnemy->hp, nodeEnemy->barHP, nodeEnemy->spr,
				nodeEnemy->_bgHPBar, "dead-ED1 (%d).png", 4, 40, player->currentExp, nodeEnemy->exp);
		}
	}
	// check weapon-player vs enemy dullness
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_ENEMY_SHOOT) ||
		(ShapeA->getTag() == SET_TAG_ENEMY_SHOOT && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_ENEMY_SHOOT) node = ShapeB;
		if (node->getTag() == SET_TAG_ENEMY_SHOOT) {

			auto nodeEnemy = static_cast<DullnessShoot*> (node);
			nodeEnemy->takeDamge(player->damage, nodeEnemy->hp, nodeEnemy->barHP, nodeEnemy->spr,
				nodeEnemy->_bgHPBar, "dead-%d.png", 4, 35, player->currentExp, nodeEnemy->exp);
		}
	}
	// check weapon-player vs enemy treehurt
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_ENEMY_TREE_HURT) ||
		(ShapeA->getTag() == SET_TAG_ENEMY_TREE_HURT && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_ENEMY_TREE_HURT) node = ShapeB;
		if (node->getTag() == SET_TAG_ENEMY_TREE_HURT) {

			auto nodeEnemy = static_cast<TreeHurt*> (node);
			nodeEnemy->takeDamge(player->damage, nodeEnemy->hp, nodeEnemy->barHP, nodeEnemy->spr,
				nodeEnemy->_bgHPBar, "Enemy_TH_dead-1 (%d).png", 4, 10, player->currentExp, nodeEnemy->exp);
		}
	}
	// check weapon-player vs batEnemy
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_BAT_ENEMY) ||
		(ShapeA->getTag() == SET_TAG_BAT_ENEMY && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_BAT_ENEMY) node = ShapeB;
		if (node->getTag() == SET_TAG_BAT_ENEMY) {

			auto nodeEnemy = static_cast<BatEnemy*> (node);
			nodeEnemy->takeDamge(player->damage, nodeEnemy->hp, nodeEnemy->barHP, nodeEnemy->spr,
				nodeEnemy->_bgHPBar, "BatDie_0%d.png", 5, 0, player->currentExp, nodeEnemy->exp);
		}
	}
	// check weapon-player vs bubbleEnemy
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_ENEMY_BUBBLE) ||
		(ShapeA->getTag() == SET_TAG_ENEMY_BUBBLE && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_ENEMY_BUBBLE) node = ShapeB;
		if (node->getTag() == SET_TAG_ENEMY_BUBBLE) {

			/*auto nodeEnemy = static_cast<BubbleEnemy*> (node);
			nodeEnemy->takeDamge(player->damage, nodeEnemy->hp, nodeEnemy->barHP, nodeEnemy->spr,
				nodeEnemy->_bgHPBar, "sl_dead (%d).png", 4, 30, player->currentExp, nodeEnemy->exp);*/
		}
	}
	// check weapon-player vs lothricKnight
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT) ||
		(ShapeA->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_ENEMY_LOTHRICKNIGHT) node = ShapeB;
		if (node->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT) {

			auto nodeEnemy = static_cast<LothricKnight*> (node);
			nodeEnemy->takeDamge(player->damage, nodeEnemy->hp, nodeEnemy->barHP, nodeEnemy->spr,
				nodeEnemy->_bgHPBar, "LothricKnight_dead (%d).png", 4, 0, player->currentExp, nodeEnemy->exp);
		}
	}
	// check weapon-player vs SoldierGuard
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_ENEMY_SOLDIERGUARD) ||
		(ShapeA->getTag() == SET_TAG_ENEMY_SOLDIERGUARD && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_ENEMY_SOLDIERGUARD) node = ShapeB;
		if (node->getTag() == SET_TAG_ENEMY_SOLDIERGUARD) {

			auto nodeEnemy = static_cast<SoldierGuard*> (node);
			nodeEnemy->takeDamge(player->damage, nodeEnemy->hp, nodeEnemy->barHP, nodeEnemy->spr,
				nodeEnemy->_bgHPBar, "soldierguard_dead  (%d).png", 4, 0, player->currentExp, nodeEnemy->exp);
		}
	}
	// check weapon-player vs winzard
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_ENEMY_WINZARD) ||
		(ShapeA->getTag() == SET_TAG_ENEMY_WINZARD && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_ENEMY_WINZARD) node = ShapeB;
		if (node->getTag() == SET_TAG_ENEMY_WINZARD) {

			auto nodeEnemy = static_cast<Winzard*> (node);
			nodeEnemy->takeDamge(player->damage, nodeEnemy->hp, nodeEnemy->barHP, nodeEnemy->spr,
				nodeEnemy->_bgHPBar, "wizard-death (%d).png", 9, 40, player->currentExp, nodeEnemy->exp);
		}
	}

#pragma endregion

#pragma region Boss

	// kiểm tra weapon vs boss
	if ((ShapeA->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getTag() == SET_TAG_BUFFALO) ||
		(ShapeA->getTag() == SET_TAG_BUFFALO && ShapeB->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_BUFFALO) node = ShapeB;
		if (node->getTag() == SET_TAG_BUFFALO) {

			if (buffalo->state != STATE::DEAD)
			{
				//buffalo->spr->runAction(buffalo->CreateAnimation("Buffalo_HitA (%d).png", 3, 0.1F));
				buffalo->takeDamge(player->damage, buffalo->hp, "TakeDamgeHPBossBuffalo",
					buffalo->spr, "buffalo_Dead (%d).png", 6);

				if (buffalo->hp <= 0) {
					countDead += 1;
					if (countDead == 2) {
						musicBG->pauseBackgroundMusic();
						tileMapGame->nodebody->setPositionY(10000);
						door->spr->runAction(door->CreateAnimation("doorEnd (%d).png", 4, .5F));
					}
				}
			}
		}
	}
#pragma endregion

#pragma region Object

	//player vs Target
	if (ShapeA->getTag() == SET_TAG_PLAYER && ShapeB->getTag() == SET_TAG_CONG_CHUA)
	{
		uiCavas->isTouch = 10;
		player->spr->stopAllActions();
		uiCavas->nodeButtonPlayer->setVisible(false);
		player->spr->runAction(RepeatForever::create(player->CreateAnimation("PlayerIdle (%d).png", 11, .1F)));

		player->runAction(Sequence::create(
			CallFunc::create([&]() {
				player->spr->setFlippedX(true);
				target->spr->setFlippedX(false);

				player->direction = Vec2(0, 0);
				getEventDispatcher()->removeEventListener(player->keyboardEvent);

				auto sprReady = Sprite::create("Sprites/UI/StatusBar/talk/Princess-talk.png");
				auto size = sprReady->getContentSize();
				sprReady->setScale(visibleSize.width / size.width * .065F, visibleSize.height / size.height * .085F);
				sprReady->setPosition(target->getPositionX(), target->getPositionY() + 75);
				this->addChild(sprReady, 3);
				}), DelayTime::create(3), CallFunc::create([&]()
					{
						auto sprEndGame = Sprite::create("Sprites/Map/BG/End-game.png");
						sprEndGame->setOpacity(0);
						sprEndGame->runAction(FadeIn::create(1));
						auto size = sprEndGame->getContentSize();
						sprEndGame->setScale(visibleSize.width / size.width, visibleSize.height / size.height);
						sprEndGame->setPosition(player->getPosition());
						this->addChild(sprEndGame, 100);
					}), DelayTime::create(10), CallFunc::create([&]() {
						Director::getInstance()->replaceScene(MenuScene::create());
							}), nullptr));

	}

	//player vs door start
	/*if (ShapeA->getTag() == SET_TAG_PLAYER && ShapeB->getTag() == SET_TAG_DOOR_START) {
		log("DOOR START");
		UserDefault* def = UserDefault::sharedUserDefault();

		if (def == nullptr)  log("map start null");
		if (UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap") > 1) {
			def->setIntegerForKey("IndexMap", UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap") - 1);
			def->flush();
			Director::getInstance()->replaceScene(Game::create());
		}
	}*/

	//player vs door end
	if (ShapeA->getTag() == SET_TAG_PLAYER && ShapeB->getTag() == SET_TAG_DOOR_END) {
		auto indexMap = UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap");
		UserDefault* def = UserDefault::sharedUserDefault();

		def->setIntegerForKey("IndexMap", indexMap + 1);
		def->setIntegerForKey("LevelPlayer", player->level);
		def->setIntegerForKey("totalExpPlayer", player->totalExp);
		def->setIntegerForKey("expPlayer", player->currentExp);
		def->setIntegerForKey("hpPlayer", player->hp);
		def->setIntegerForKey("mpPlayer", player->mp);
		def->setIntegerForKey("damagePlayer", player->damage);
		def->setIntegerForKey("speedPlayer", player->moveForce);
		player->countItemHp = uiCavas->countHP;
		def->setIntegerForKey("itemhp", player->countItemHp);
		def->setBoolForKey("turnOnSound", turnOnSound);
		def->setBoolForKey("playerSound", player->playSound);

		def->flush();

		this->runAction(Sequence::create(DelayTime::create(0.2F),
			CallFunc::create([&]() {
				player->spr->setVisible(false);
				}), DelayTime::create(0.1F),
					CallFunc::create([&]() {
					Director::getInstance()->replaceScene(Game::create());
						}), nullptr));
	}

	////player vs dead
	if ((ShapeA->getTag() == SET_TAG_PLAYER && ShapeB->getTag() == SET_TAG_DEAD) ||
		(ShapeA->getTag() == SET_TAG_DEAD && ShapeB->getTag() == SET_TAG_PLAYER)) {

		auto node = ShapeA;
		if (node->getTag() != SET_TAG_DEAD) node = ShapeB;
		if (node->getTag() == SET_TAG_DEAD) {
			this->pauseSchedulerAndActions();
			removeChild(uiCavas);
			player->playerBody->removeFromWorld();
			player->dead();
		}
	}

#pragma endregion

	return true;
}

bool Game::onContactBeginEnemy(const cocos2d::PhysicsContact& contact)
{
	auto ShapeA = contact.getShapeA()->getBody();
	auto ShapeB = contact.getShapeB()->getBody();

	Vec2 dirPos = player->getPosition() + player->direction;
	Size playerSize = player->spr->getContentSize();

#pragma region Object

	// va cham voi Bonfire
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_BONFIRE) ||
		(ShapeA->getNode()->getTag() == SET_TAG_BONFIRE && ShapeB->getNode()->getTag() == SET_TAG_PLAYER)) {

		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_BONFIRE) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_BONFIRE)
		{
			UserDefault* def = UserDefault::sharedUserDefault();
			player->hp = 100;
			def->setIntegerForKey("hpPlayer", player->hp);
			def->flush();

			DataEvent* dataHP = new DataEvent();
			dataHP->hp = def->getIntegerForKey("hpPlayer");
			EventCustom eventHP("TakeDamgeHPPlayer");
			eventHP.setUserData(dataHP);
			_eventDispatcher->dispatchEvent(&eventHP);

			this->runAction(Sequence::create(
				CallFunc::create([&]() {
					player->moveDirection = 0;
					player->caseState();
					}), DelayTime::create(2)
						, nullptr));
		}
	}

	// va cham voi NPC
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_NPC) ||
		(ShapeA->getNode()->getTag() == SET_TAG_NPC && ShapeB->getNode()->getTag() == SET_TAG_PLAYER)) {

		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_NPC) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_NPC)
		{
			auto nodeNPC = static_cast<NPC*>(node->getNode());
			nodeNPC->npcBody->removeFromWorld();

			this->runAction(Sequence::create(
				CallFunc::create([&]() {
					player->moveDirection = 0;
					player->caseState();
					uiCavas->setVisible(false);
					}), DelayTime::create(3), CallFunc::create([&]() {
						uiCavas->setVisible(true);
						}), nullptr));


			auto sprReady = Sprite::create("Sprites/UI/StatusBar/talk/king-talk.png");
			auto size = sprReady->getContentSize();
			sprReady->setScale(visibleSize.width / size.width * .065F, visibleSize.height / size.height * .1F);
			sprReady->setPosition(nodeNPC->getPosition().x, nodeNPC->getPositionY() + 75);
			this->addChild(sprReady, 3);
		}
	}

	// va cham voi Chest
	if ((ShapeA->getNode()->getTag() == SET_TAG_WEAPON_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_CHEST) ||
		(ShapeA->getNode()->getTag() == SET_TAG_CHEST && ShapeB->getNode()->getTag() == SET_TAG_WEAPON_PLAYER)) {

		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_CHEST) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_CHEST)
		{
			auto nodeChest = static_cast<Chest*>(node->getNode());
			if (nodeChest->hasOpened != true)
			{
				nodeChest->hasOpened = true;
				nodeChest->spr->runAction(nodeChest->CreateAnimation("chest_0%d.png", 4, 0.1f));

				itemhp = ItemHP::create("Sprites/UI/StatusBar/Player/item-hp.png");
				itemhp->spr->setOpacity(0);
				itemhp->spr->runAction(FadeIn::create(1));

				auto size = itemhp->spr->getContentSize();
				itemhp->setScale(visibleSize.width / size.width * .012F, visibleSize.height / size.height * .04F);
				itemhp->setPosition(nodeChest->getPosition().x, nodeChest->getPositionY());
				logic->listItemHP.pushBack(itemhp);
				this->addChild(itemhp, 5);

			}
		}
	}

#pragma endregion

#pragma region Skeleton
	//kiểm tra Skeleton vs player
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_SKELETON) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_SKELETON && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;

		if (node->getNode()->getTag() != SET_TAG_ENEMY_SKELETON) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_SKELETON) {

			auto nodeEnemy = static_cast<SkeletonEnemy*> (node->getNode());
			nodeEnemy->canAttack = true;
			Vec2 posEnemy = nodeEnemy->getPosition();
			Size sizeEnemy = nodeEnemy->spr->getContentSize();

			if (dirPos.x + playerSize.width / 2 > posEnemy.x) nodeEnemy->playerDir = 2;
			else if (dirPos.x - playerSize.width / 2 < posEnemy.x + sizeEnemy.width) nodeEnemy->playerDir = 1;

			nodeEnemy->attack("attack-ED1 (%d).png", 8, 0.1f);
			player->takeDamge(nodeEnemy->damage);
		}
	}
	//kiểm tra Skeleton chạm đất
	if ((ShapeA->getNode()->getTag() == SET_TAG_TILEMAP_GROUND && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_SKELETON) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_SKELETON && ShapeB->getNode()->getTag() == SET_TAG_TILEMAP_GROUND))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_SKELETON) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_SKELETON)
		{
			static_cast<SkeletonEnemy*>(node->getNode())->isLand = true;
		}
	}

	//kiểm tra Skeleton va chạm điểm collision
	if ((ShapeA->getNode()->getTag() == SET_TAG_OBJECT_MAP && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_SKELETON) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_SKELETON && ShapeB->getNode()->getTag() == SET_TAG_OBJECT_MAP))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_SKELETON) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_SKELETON)
		{
			auto enemy_move = static_cast<SkeletonEnemy*>(node->getNode());
			enemy_move->isCollision = true;

			if (enemy_move->direction == Vec2(-1, 0)) enemy_move->randomDir = 2;
			else if (enemy_move->direction == Vec2(1, 0)) enemy_move->randomDir = 1;
		}
	}
#pragma endregion

#pragma region DullnessShoot
	//kiem tra cham dat
	if ((ShapeA->getNode()->getTag() == SET_TAG_TILEMAP_GROUND && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_SHOOT) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_SHOOT && ShapeB->getNode()->getTag() == SET_TAG_TILEMAP_GROUND))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_SHOOT) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_SHOOT)
		{
			static_cast<DullnessShoot*>(node->getNode())->isLand = true;
		}
	}

	//kiem tra cung vs titlemap
	if ((ShapeA->getNode()->getTag() == SET_TAG_TILEMAP_GROUND && ShapeB->getNode()->getTag() == SET_TAG_ARCHERY) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ARCHERY && ShapeB->getNode()->getTag() == SET_TAG_TILEMAP_GROUND))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ARCHERY) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ARCHERY)
		{
			static_cast<Archery*>(node->getNode())->setName("remove");
			static_cast<Archery*>(node->getNode())->removeFromParent();
		}
	}

	//kiem tra cung vs player
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_ARCHERY) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ARCHERY && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ARCHERY) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ARCHERY)
		{
			auto nodeEnemy = static_cast<Archery*>(node->getNode());
			nodeEnemy->setName("remove");
			nodeEnemy->removeFromParent();
			player->takeDamge(nodeEnemy->damage);
		}
	}
#pragma endregion

#pragma region Enemy_tree_hurt
	//kiem tra vs player
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_TREE_HURT) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_TREE_HURT && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_TREE_HURT) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_TREE_HURT)
		{
			auto nodeEnemy = static_cast<TreeHurt*>(node->getNode());
			nodeEnemy->attack("tree_attack (%d).png", 11, 0.1f);
			player->takeDamge(nodeEnemy->damage);
		}
	}
#pragma endregion

#pragma region Spikes
	//kiểm tra enemy chạm đất
	if ((ShapeA->getNode()->getTag() == SET_TAG_TILEMAP_GROUND && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE && ShapeB->getNode()->getTag() == SET_TAG_TILEMAP_GROUND))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_BUBBLE) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE)
		{
			static_cast<BubbleEnemy*>(node->getNode())->isLand = true;
		}
	}

	//kiểm tra enemy va chạm điểm collision
	if ((ShapeA->getNode()->getTag() == SET_TAG_OBJECT_MAP && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE && ShapeB->getNode()->getTag() == SET_TAG_OBJECT_MAP))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_BUBBLE) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE)
		{
			auto enemy_move = static_cast<BubbleEnemy*>(node->getNode());
			enemy_move->isCollision = true;

			if (enemy_move->direction == Vec2(-1, 0)) enemy_move->randomDir = 2;
			else if (enemy_move->direction == Vec2(1, 0)) enemy_move->randomDir = 1;
		}
	}

	// kiểm tra Spikes vs player
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_BUBBLE) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_BUBBLE)
		{
			auto nodeEnemy = static_cast<BubbleEnemy*>(node->getNode());
			nodeEnemy->canAttack = true;
			Vec2 epos = nodeEnemy->getPosition();
			Size Esize = nodeEnemy->spr->getContentSize();

			if (epos.x + Esize.width / 2 > dirPos.x) nodeEnemy->playerDir = 1;
			else if (epos.x - Esize.width / 2 < dirPos.x + playerSize.width) nodeEnemy->playerDir = 2;

			//nodeEnemy->attack("sl_Attack (%d).png", 5, 0.1f);
			player->takeDamge(nodeEnemy->damage);
		}
	}
#pragma endregion

#pragma region BatEnemy

	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_BAT_ENEMY) ||
		(ShapeA->getNode()->getTag() == SET_TAG_BAT_ENEMY && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_BAT_ENEMY) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_BAT_ENEMY)
		{
			auto nodeEnemy = static_cast<BatEnemy*>(node->getNode());
			player->takeDamge(nodeEnemy->damage);
		}
	}

#pragma endregion

#pragma region LothricKnight
	//kiểm tra enemy vs player
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_LOTHRICKNIGHT) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT) {

			auto nodeEnemy = static_cast<LothricKnight*> (node->getNode());
			nodeEnemy->canAttack = true;

			Vec2 posEnemy = nodeEnemy->getPosition();
			Size sizeEnemy = nodeEnemy->spr->getContentSize();

			if (dirPos.x + playerSize.width / 2 > posEnemy.x) nodeEnemy->playerDir = 2;
			else if (dirPos.x - playerSize.width / 2 < posEnemy.x + sizeEnemy.width) nodeEnemy->playerDir = 1;

			nodeEnemy->attack("LothricKnight_attack(%d).png", 7, 0.1f);
			player->takeDamge(nodeEnemy->damage);
		}
	}

	//kiểm tra enemy chạm đất
	if ((ShapeA->getNode()->getTag() == SET_TAG_TILEMAP_GROUND && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT && ShapeB->getNode()->getTag() == SET_TAG_TILEMAP_GROUND))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_LOTHRICKNIGHT) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT) static_cast<LothricKnight*>(node->getNode())->isLand = true;
	}

	//kiểm tra enemy va chạm điểm collision
	if ((ShapeA->getNode()->getTag() == SET_TAG_OBJECT_MAP && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT && ShapeB->getNode()->getTag() == SET_TAG_OBJECT_MAP))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_LOTHRICKNIGHT) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_LOTHRICKNIGHT)
		{
			auto enemy_move = static_cast<LothricKnight*>(node->getNode());
			enemy_move->isCollision = true;
			if (enemy_move->direction == Vec2(-1, 0)) enemy_move->randomDir = 2;
			else if (enemy_move->direction == Vec2(1, 0)) enemy_move->randomDir = 1;
		}
	}
#pragma endregion

#pragma region SoldierGuard
	//kiểm tra enemy vs player
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_SOLDIERGUARD) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_SOLDIERGUARD && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;

		if (node->getNode()->getTag() != SET_TAG_ENEMY_SOLDIERGUARD) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_SOLDIERGUARD) {
			auto nodeEnemy = static_cast<SoldierGuard*> (node->getNode());

			nodeEnemy->canAttack = true;
			Vec2 posEnemy = nodeEnemy->getPosition();
			Size sizeEnemy = nodeEnemy->spr->getContentSize();

			if (dirPos.x + playerSize.width / 2 > posEnemy.x) nodeEnemy->playerDir = 2;
			else if (dirPos.x - playerSize.width / 2 < posEnemy.x + sizeEnemy.width) nodeEnemy->playerDir = 1;

			nodeEnemy->attack("soldierguard_attack-A (%d).png", 6, 0.1f);
			player->takeDamge(nodeEnemy->damage);
		}
	}

	//kiểm tra enemy chạm đất
	if ((ShapeA->getNode()->getTag() == SET_TAG_TILEMAP_GROUND && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_SOLDIERGUARD) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_SOLDIERGUARD && ShapeB->getNode()->getTag() == SET_TAG_TILEMAP_GROUND))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_SOLDIERGUARD) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_SOLDIERGUARD)
		{
			static_cast<SoldierGuard*>(node->getNode())->isLand = true;
		}
	}
#pragma endregion

#pragma region Winzard
	//kiểm tra enemy chạm đất
	if ((ShapeA->getNode()->getTag() == SET_TAG_TILEMAP_GROUND && ShapeB->getNode()->getTag() == SET_TAG_ENEMY_WINZARD) ||
		(ShapeA->getNode()->getTag() == SET_TAG_ENEMY_WINZARD && ShapeB->getNode()->getTag() == SET_TAG_TILEMAP_GROUND))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_ENEMY_WINZARD) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_ENEMY_WINZARD) static_cast<Winzard*>(node->getNode())->isLand = true;
	}

	//kiểm tra đạn với player
	if ((ShapeA->getNode()->getTag() == SET_TAG_SHOOT && ShapeB->getNode()->getTag() == SET_TAG_PLAYER) ||
		(ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_SHOOT))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_SHOOT) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_SHOOT)
		{
			auto nodeEnemy = static_cast<Shoot*>(node->getNode());
			nodeEnemy->setName("remove");
			nodeEnemy->removeFromParent();
			player->takeDamge(nodeEnemy->damage);
		}
	}

	//kiểm tra đạn chạm đất
	if ((ShapeA->getNode()->getTag() == SET_TAG_TILEMAP_GROUND && ShapeB->getNode()->getTag() == SET_TAG_SHOOT) ||
		(ShapeA->getNode()->getTag() == SET_TAG_SHOOT && ShapeB->getNode()->getTag() == SET_TAG_TILEMAP_GROUND))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_SHOOT) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_SHOOT)
		{
			auto nodeEnemy = static_cast<Shoot*>(node->getNode());
			nodeEnemy->setName("remove");
			nodeEnemy->removeFromParent();
		}
	}

#pragma endregion

#pragma region bossbuffalo
	// kiểm tra weapon boss vs player
	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_WEAPON_BUFFALO) ||
		(ShapeA->getNode()->getTag() == SET_TAG_WEAPON_BUFFALO && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_WEAPON_BUFFALO) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_WEAPON_BUFFALO) player->takeDamge(buffalo->damage);
	}

	// kiểm tra boss vs colision
	if ((ShapeA->getNode()->getTag() == SET_TAG_BUFFALO && ShapeB->getNode()->getTag() == SET_TAG_OBJECT_MAP) ||
		(ShapeA->getNode()->getTag() == SET_TAG_OBJECT_MAP && ShapeB->getNode()->getTag() == SET_TAG_BUFFALO))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_BUFFALO) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_BUFFALO)
		{
			auto enemy_move = static_cast<Buffalo*>(node->getNode());
			enemy_move->isCollision = true;
		}
	}

	// kiểm tra Fireball vs player
	if ((ShapeA->getNode()->getTag() == SET_TAG_FIREBALL && ShapeB->getNode()->getTag() == SET_TAG_PLAYER) ||
		(ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_FIREBALL))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_FIREBALL) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_FIREBALL)
		{
			auto nodeEnemy = static_cast<Fireball*>(node->getNode());
			nodeEnemy->setName("remove");
			nodeEnemy->removeFromParent();
			player->takeDamge(nodeEnemy->damage);
		}
	}
#pragma endregion

	return true;
}

bool Game::onContactObstancle(const cocos2d::PhysicsContact& contact)
{
	auto ShapeA = contact.getShapeA()->getBody();
	auto ShapeB = contact.getShapeB()->getBody();

	if ((ShapeA->getNode()->getTag() == SET_TAG_PLAYER && ShapeB->getNode()->getTag() == SET_TAG_OBSTANCLE) ||
		(ShapeA->getNode()->getTag() == SET_TAG_OBSTANCLE && ShapeB->getNode()->getTag() == SET_TAG_PLAYER))
	{
		auto node = ShapeA;
		if (node->getNode()->getTag() != SET_TAG_OBSTANCLE) node = ShapeB;
		if (node->getNode()->getTag() == SET_TAG_OBSTANCLE)
		{
			auto nodeTraps = static_cast<Traps*>(node->getNode());
			player->takeDamge(nodeTraps->damage);
		}
	}
	return true;
}