#ifndef __GAMEOVER_H__
#define __GAMEOVER_H__

#include "cocos2d.h"
#include "cocos/ui/UIButton.h"
#include "cocos/ui/CocosGUI.h"

USING_NS_CC;
using namespace std;

class GameOver : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
	float Opacity = 0;
	Sprite* buttonBackMenu;
    void menuCloseCallback(Ref* pSender, cocos2d::ui::Widget::TouchEventType type);
    bool onClickBackMenu(Touch* touch, Event* event);
	void update(float);
    CREATE_FUNC(GameOver);
};

#endif // __GAMEOVER_H__
