#ifndef __SHAKE_H__
#define __SHAKE_H__

#include "2d/CCActionInterval.h"

class FShake : public cocos2d::ActionInterval
{
public:
	FShake();

	CC_DEPRECATED_ATTRIBUTE static FShake* actionWithDuration(float d, float strength);
	static FShake* create(float d, float strength);

	CC_DEPRECATED_ATTRIBUTE static FShake* actionWithDuration(float d, float strength_x, float strength_y);
	static FShake* create(float d, float strength_x, float strength_y);

	bool initWithDuration(float d, float strength_x, float strength_y);

	virtual void update(float time);
	virtual void stop(void);
	virtual FShake* clone();


protected:
	float _displacement_x, _displacement_y;
	float _strength_x, _strength_y;
};

#endif //__SHAKE_H__
