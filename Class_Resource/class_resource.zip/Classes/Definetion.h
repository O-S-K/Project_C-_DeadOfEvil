#ifndef _DEFINETION_H_
#define _DEFINETION_H_

#pragma region setTag
//--------------- SET TAG ---------------------- //
#define SET_TAG_PLAYER			                 0
#define SET_TAG_WEAPON_PLAYER					 1
#define SET_TAG_OBJECT_MAP                       2
#define SET_TAG_TILEMAP_GROUND                   3
#define SET_TAG_ENEMY_SKELETON   		         4
#define SET_TAG_ENEMY_SNAKE         	         5
#define SET_TAG_ENEMY_WINZARD					 6
#define SET_TAG_ENEMY_FLY				         7
#define SET_TAG_ENEMY_SHOOT				         8
#define SET_TAG_ARCHERY                          9
#define SET_TAG_ENEMY_TREE_HURT                  10
#define SET_TAG_BAT_ENEMY                        11
#define SET_TAG_ENEMY_BUBBLE                     12
#define SET_TAG_ENEMY_SLIME                      13
#define SET_TAG_SHOOT                            14
#define SET_TAG_ENEMY_LOTHRICKNIGHT		         15
#define SET_TAG_ENEMY_SOLDIERGUARD		         16
#define SET_TAG_BUFFALO  						 20
#define SET_TAG_DEAD                             21
#define SET_TAG_WEAPON_BUFFALO                   22
#define SET_TAG_FIREBALL                         23
#define SET_TAG_CLIMB                            24
#define SET_TAG_OBSTANCLE						 98
#define SET_TAG_CONG_CHUA						 99
#define SET_TAG_DOOR_START						 100
#define SET_TAG_DOOR_END					     101
#define SET_TAG_NPC								 102
#define SET_TAG_CHEST						     103
#define SET_TAG_ITEMHP						     104
#define SET_TAG_BONFIRE						     105

#pragma endregion

#pragma region setCollision
// ------------ SET setCollision -------------------//

#define PLAYER_COLLISION_BITTMASK                0x10000001
#define WEPON_PLAYER_COLLISION_BITTMASK          0x00000000
#define TITLEMAP_GROUND_COLLISION_BITTMASK       0x00000111
#define OBJECT_TITLE_MAP_COLLITION               0x00000111
#define OBJECT_DEAD_COLLITION                    0x00000111
#define OBJECT_CLIMB                             0x00011111
#define BUFFALO_COLLISION_BITMASK                0x01000000
#define WEPON_BUFFALO_COLLISION_BITTMASK         0x01110000

#define ENEMY_BUBBLE_COLLISION_BITMASK           0x10000000
#define ENEMY_DULLNESSSHOOT_COLLISION_BITMASK    0x01000000
#define ENEMY_LOTHRICKNIGHT_COLLISION_BITMASK    0X01000000
#define ENEMY_SKELETON_COLLISION_BITMASK         0x00101000
#define ENEMY_SNAKE_COLLISION_BITMASK            0x00010000
#define ENEMY_SOLDIERGUARD_COLLISION_BITMASK     0x00100000
#define ENEMY_TREEHURT_COLLISION_BITMASK         0X01000000
#define ENEMY_SLIME_COLLISION_BITMASK            0x00010000
#define ENEMY_BAT_COLLISION_BITMASK              0x00001000
#define ENEMY_WINZARD_COLLISION_BITMASK          0x00000100

#pragma endregion

#define ARCHERY_COLLISION_BITMASK                0x1100
#define SHOOT_COLLISION_BITMASK                  0x1100
#define FIREBALL_COLLISION_BITMASK               0x1100
#define OBJECT_TITLE_MAP_COLLITION   			 0x1111

#define DOOR_START_COLLISION_BITTMASK 		     0x0001
#define DOOR_END_COLLISION_BITTMASK 		     0x0010
#define TARGET_COLLISION_BITTMASK 		         0x1111
#define NPC_COLLISION_BITTMASK 		             0x0011
#define BONFIRE_COLLISION_BITTMASK 		         0x0011


#pragma region setCategory
// ------------ SET setCategory -------------------//

#define PLAYER_CATEGORY_BITTMASK                 0x00000011
#define WEAPON_PLAYER_CATEGORY_BITTMASK          0x11111111
#define OBJECT_MAP_CATEGORY_BITTMASK             0x11111111
#define WEPON_BUFFALO_CATEGORY_BITTMASK          0x11111111

#define BUFFALO_CATEGORY_BITTMASK                0x00000001
#define ENEMY_BUBBLE_CATEGORY_BITTMASK           0x10000001
#define ENEMY_DULLNESSSHOOT_CATEGORY_BITTMASK    0x01000001
#define ENEMY_LOTHRICKNIGHT_CATEGORY_BITTMASK    0X00100001
#define ENEMY_SKELETON_CATEGORY_BITTMASK         0x00010001
#define ENEMY_SNAKE_CATEGORY_BITTMASK            0x00100001
#define ENEMY_SOLDIERGUARD_CATEGORY_BITTMASK     0x10000001
#define ENEMY_TREEHURT_CATEGORY_BITTMASK         0X00100001
#define ENEMY_SLIME_CATEGORY_BITTMASK            0x00010001
#define ENEMY_BAT_CATEGORY_BITTMASK              0x00001001
#define ENEMY_WINZARD_CATEGORY_BITTMASK          0x00000101

//#define ARCHERY_COLLISION_BITMASK 
//#define SHOOT_COLLISION_BITMASK

#pragma endregion


// ------------ SET ATTRIBUTES -------------------//

#define SPEED_ANIMATION_ENEMY					0.15f

class DataEvent {
public:
	float hp;
	float mp;
	int level;
	int damage;
	int speed;
	int moveDir;
	bool isMoveLeft;
	bool isMoveRight;
	bool offSound;

	bool canAttack;
	bool canRoll;
	bool canJump;
	bool recHP;

	int currentLevel;
	int totalLevel;
	int levelPlayer;
};


#endif // _DEFINETION_H_