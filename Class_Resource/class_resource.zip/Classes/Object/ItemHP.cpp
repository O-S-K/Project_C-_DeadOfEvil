#include "ItemHP.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"

USING_NS_CC;
using namespace std;
 
ItemHP* ItemHP::create(string str)
{
	auto object = ItemHP::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 3);
	return object;
}

bool ItemHP::init()
{
	if (!Node::init()) return false;

	this->setTag(SET_TAG_ITEMHP);
	return true;
}

void ItemHP::attributesData()
{
	auto sizeBody = Size(spr->getContentSize());
	auto itemBody = PhysicsBody::createBox(sizeBody);
	itemBody->setCollisionBitmask(0x00000111);
	itemBody->setContactTestBitmask(0x00000111);
	this->setPhysicsBody(itemBody);
}