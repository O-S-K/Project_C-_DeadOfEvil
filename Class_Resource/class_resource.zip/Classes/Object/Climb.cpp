#include "Object/Climb.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"

USING_NS_CC;

using namespace std;

Climb* Climb::createClimb(string str)
{
	auto object = Climb::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 5);
	object->attributesData();
	return object;
}
bool Climb::init()
{
	if (!Node::init()) return false;
	randomDir = random(1, 2);
	this->setTag(SET_TAG_CLIMB);
	return true;
}

void Climb::attributesData()
{
	auto Body = PhysicsBody::createBox(spr->getContentSize());
	Body->setRotationEnable(false);
	Body->setDynamic(false);
	Body->setCollisionBitmask(OBJECT_CLIMB);
	//Body->setCategoryBitmask(0x0001);
	Body->setContactTestBitmask(OBJECT_CLIMB);
	setPhysicsBody(Body);
}
void Climb::move()
{
	if (randomDir == 1) direction = Vec2(0, -1);
	else if (randomDir == 2) direction = Vec2(0, 1);

	this->setPosition(this->getPosition() + direction);
}

