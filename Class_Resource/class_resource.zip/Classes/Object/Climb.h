#ifndef __CLIMB_H__
#define __CLIMB_H__

#include "cocos2d.h"
#include "Unit.h"

class Climb : public Unit
{
public:
	virtual bool init();
	static Climb* createClimb(string);

	float maxUp;
	float maxDown;
	int randomDir;

	virtual void attributesData();
	void move();

	CREATE_FUNC(Climb);
};

#endif // __DOOR_H__
