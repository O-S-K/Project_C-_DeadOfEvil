#ifndef __ITEMHP_H__
#define __ITEMHP_H__

#include "cocos2d.h"
#include "Unit.h"
USING_NS_CC;

class ItemHP : public Unit
{
public:
	static ItemHP* create(string);
	virtual bool init();
	virtual void attributesData();

	bool check = false;
	CREATE_FUNC(ItemHP);
};

#endif // __ITEMHP_H__
