#include "Traps.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"

USING_NS_CC;

using namespace std;

Traps* Traps::create(string str)
{
	auto object = Traps::create();
	object->spr = Sprite::create(str);
	object->spr->setAnchorPoint(Vec2(0.5F, .25F));
	object->addChild(object->spr, 5);
	object->attributesData();
	return object;
}

bool Traps::init()
{
	if (!Node::init()) return false;
	damage = 50;
	this->setTag(SET_TAG_OBSTANCLE);
	return true;
}

void Traps::attributesData()
{
	auto size = spr->getContentSize();
	auto sizeBody = Size(size.width / 1.1F, size.height / 2);
	auto sprTrapBody = PhysicsBody::createBox(sizeBody);
	sprTrapBody->setRotationEnable(false);
	sprTrapBody->setContactTestBitmask(true);
	sprTrapBody->setDynamic(false);
	setPhysicsBody(sprTrapBody);
}



