#ifndef __TRAPS_H__
#define __TRAPS_H__

#include "cocos2d.h"
#include "Unit.h"

class Traps : public Unit
{
public:
	virtual bool init();
	static Traps* create(string);
	Node* node;

	void attributesData();
	CREATE_FUNC(Traps);
};

#endif // __TRAPS_H__
