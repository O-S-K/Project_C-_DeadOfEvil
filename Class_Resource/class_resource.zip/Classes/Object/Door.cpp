#include "Object/Door.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"

USING_NS_CC;

using namespace std;

Door* Door::createSprDoorStart(string str)
{
	auto object = Door::create();
	object->spr = Sprite::create(str);
	object->spr->setAnchorPoint(Vec2(0.5f, 0));
	object->spr->setPositionY(-object->spr->getContentSize().height / 2);
	object->addChild(object->spr, 5);
	object->createDoorStart();
	return object;
}

Door* Door::createSprDoorEnd(string str)
{
	auto object = Door::create();
	object->spr = Sprite::create(str);
	object->spr->setAnchorPoint(Vec2(0.5f, 0));
	object->spr->setPositionY(-object->spr->getContentSize().height / 2);
	object->addChild(object->spr, 5);
	object->createDoorEnd();
	return object;
}

Door* Door::createSprDoorEndGame(string str)
{
	auto object = Door::create();
	object->spr = Sprite::create(str);
	object->spr->setAnchorPoint(Vec2(0, 0));
	object->spr->setPositionY(-object->spr->getContentSize().height / 2);
	object->addChild(object->spr, 5);
	return object;
}

bool Door::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Door/DoorEnd.plist");
	return true;
}

void Door::createDoorStart()
{
	node = Node::create();
	this->addChild(node);

	auto doorStartBody = PhysicsBody::createBox(spr->getContentSize());
	doorStartBody->setRotationEnable(false);
	doorStartBody->setCollisionBitmask(DOOR_START_COLLISION_BITTMASK);
	doorStartBody->setContactTestBitmask(true);
	doorStartBody->setDynamic(false);
	node->setTag(SET_TAG_DOOR_START);
	node->setPhysicsBody(doorStartBody);
}

void Door::createDoorEnd()
{
	node = Node::create();
	this->addChild(node);

	setTag(SET_TAG_DOOR_END);
	auto doorEndtBody = PhysicsBody::createBox(spr->getContentSize());
	doorEndtBody->setRotationEnable(false);
	doorEndtBody->setContactTestBitmask(true);
	doorEndtBody->setCollisionBitmask(DOOR_END_COLLISION_BITTMASK);
	doorEndtBody->setDynamic(false);
	node->setTag(SET_TAG_DOOR_END);
	node->setPhysicsBody(doorEndtBody);
}

