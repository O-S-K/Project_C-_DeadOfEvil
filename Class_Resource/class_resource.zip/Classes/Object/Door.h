#ifndef __DOOR_H__
#define __DOOR_H__

#include "cocos2d.h"
#include "Unit.h"

class Door : public Unit
{
public:
	virtual bool init();
	static Door* createSprDoorStart(string);
	static Door* createSprDoorEnd(string);
	static Door* createSprDoorEndGame(string);

	Node* node;
	Node* nodeD;

	void createDoorStart();
	void createDoorEnd();
	CREATE_FUNC(Door);
};

#endif // __DOOR_H__
