#include "Chest.h"
#include "SimpleAudioEngine.h"

#include "Definetion.h"

USING_NS_CC;
using namespace std;
using namespace CocosDenshion;


Chest* Chest::create(string str)
{
	auto object = Chest::create();
	object->spr = Sprite::create(str);
	object->spr->setFlippedX(true);
	object->addChild(object->spr, 3);
	object->attributesData();
	return object;
}

bool Chest::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Chest/Chest.plist");
	this->setTag(SET_TAG_CHEST);
	return true;
}

void Chest::attributesData()
{
	auto sizeBody = Size(spr->getContentSize().width, spr->getContentSize().height);
	auto npcBody = PhysicsBody::createBox(sizeBody);
	npcBody->setRotationEnable(false);
	npcBody->setCollisionBitmask(NPC_COLLISION_BITTMASK);
	npcBody->setCategoryBitmask(0x00010001);
	npcBody->setContactTestBitmask(NPC_COLLISION_BITTMASK);
	setPhysicsBody(npcBody);
}