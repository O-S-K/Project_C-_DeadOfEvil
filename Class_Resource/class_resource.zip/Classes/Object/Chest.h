#ifndef __CHEST_H__
#define __CHEST_H__

#include "cocos2d.h"
#include "Unit.h"

USING_NS_CC;

class Chest : public Unit
{
public:
	static Chest* create(string);
	virtual bool init();
	virtual void attributesData();
	bool hasOpened = false;
	CREATE_FUNC(Chest);
};

#endif // __IGOBJECT_H__
