#include "NPC.h"
#include "SimpleAudioEngine.h"

#include "Definetion.h"

USING_NS_CC;
using namespace std;
using namespace CocosDenshion;


NPC* NPC::create(string str)
{
	auto object = NPC::create();
	object->spr = Sprite::create(str); 
	object->spr->setFlippedX(true);
	object->addChild(object->spr, 3);
	object->attributesData();
	return object;
}

NPC* NPC::createFireborn(string str)
{
	auto object = NPC::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 3);
	object->attributesDataBonfire();
	return object;
}

bool NPC::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Object/bonfires/bonfireData.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Object/king/kingIdle/Kingdata.plist");

	return true;
}

void NPC::attributesData()
{
	this->setTag(SET_TAG_NPC);
	spr->runAction(RepeatForever::create(CreateAnimation("king (%d).png", 18, 0.1f)));

	npcBody = PhysicsBody::createBox(spr->getContentSize());
	npcBody->setRotationEnable(false);
	npcBody->setCollisionBitmask(NPC_COLLISION_BITTMASK);
	npcBody->setCategoryBitmask(0x00100001);
	npcBody->setContactTestBitmask(NPC_COLLISION_BITTMASK);
	setPhysicsBody(npcBody);
}

void NPC::attributesDataBonfire()
{
	this->setTag(SET_TAG_BONFIRE);
	spr->runAction(RepeatForever::create(CreateAnimation("bonfire (%d).png", 9, 0.1f)));

	auto size = spr->getContentSize();
	auto sizeBody = Size(size.width, size.height / 1.4F);
	auto bfBody = PhysicsBody::createBox(sizeBody);
	bfBody->setRotationEnable(false);
	bfBody->setCollisionBitmask(BONFIRE_COLLISION_BITTMASK);
	bfBody->setCategoryBitmask(0x00100001);
	bfBody->setContactTestBitmask(BONFIRE_COLLISION_BITTMASK);
	setPhysicsBody(bfBody);
}