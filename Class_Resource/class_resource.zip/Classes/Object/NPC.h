#ifndef __NPC_H__
#define __NPC_H__

#include "cocos2d.h"
#include "Unit.h"

USING_NS_CC;

class NPC : public Unit
{
public:
	static NPC* create(string);
	static NPC* createFireborn(string);

	PhysicsBody* npcBody;
	virtual bool init();
	virtual void attributesData();
	void attributesDataBonfire();

	CREATE_FUNC(NPC);
};

#endif // __NPC_H__
