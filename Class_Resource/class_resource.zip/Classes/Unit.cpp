#include "Unit.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

bool Unit::init()
{
	if (!Node::init()) return false;
	return true;
}

Animate* Unit::CreateAnimation(const char* spriteIndex, int countFrame, float speedFamre) {

	Vector<SpriteFrame*>  vSpriteFrame(countFrame);

	for (int i = 1; i <= countFrame; i++)
	{
		vSpriteFrame.pushBack(SpriteFrameCache::getInstance()->getSpriteFrameByName(StringUtils::format(spriteIndex, i).c_str()));
	}
	animation = Animation::createWithSpriteFrames(vSpriteFrame, speedFamre);
	animate = Animate::create(animation);
	return animate;
}