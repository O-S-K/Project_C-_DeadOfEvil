#ifndef __UNIT_H__
#define __UNIT_H__

#include "cocos2d.h"
#include "IGObject.h"
#include "cocos/ui/UIButton.h"
#include "cocos/ui/CocosGUI.h"

USING_NS_CC;
using namespace std;
enum STATE {
	WALK,
	IDLE,
	STAND,
	SPLASH,
	RECHP,
	ATTACK,
	SHIELD,
	DEAD
};

class Unit : public IGObject
{
public:
	virtual bool init();

	Vec2 direction;
	Animate* animate;
	Animation* animation;
	PhysicsBody* bodyWeapon;

	int hp;
	int exp;
	int damage;
	float speed;
	int isEnemy = 0;
	int faceBoss = 1;
	bool isDead = false;
	
	bool isLand;
	bool moveLeft;
	bool moveRight;
	bool canAttack = true;

	void idle();
	void move();
	void attack();
	void shield();
	void takeDamge(int);
	void dead();

	Animate* CreateAnimation(const char*, int, float);
	CREATE_FUNC(Unit);
};
#endif // __UNIT_H__