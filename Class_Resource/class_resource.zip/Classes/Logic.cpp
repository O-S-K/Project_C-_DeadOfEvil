﻿#include "Logic.h"
#include "SimpleAudioEngine.h"
#include "Character/DataArchery.h"

USING_NS_CC;
using namespace std;

void Logic::Move(float s)
{
	MoveEnemy(s);
	MovePlayer(s);
	MoveBullet();
	CheckItemHP();
	if (buffalo != NULL) MoveBossBuffalo();
}
bool Logic::checkStatePlayer()
{
	if (player->state == STATE::SPLASH)
	{
		dirPos = player->getPosition();
		playerSize = player->spr->getContentSize();
		if ((dirPos.x + playerSize.width /2 > posObjectDead.x - sizeObjectDead.width/2 && dirPos.x - playerSize.width / 2 < posObjectDead.x + sizeObjectDead.width / 2)
			&& (dirPos.y + playerSize.height/2 >= posObjectDead.y - sizeObjectDead.height/2 && dirPos.y - playerSize.height/2 <= posObjectDead.y/2 + sizeObjectDead.height / 2))
		{
			return true;	
		}
	}
	return false;
}


void Logic::CheckItemHP()
{
	dirPos = player->getPosition() + player->direction;
	playerSize = player->spr->getContentSize();

	for (int i = 0; i < listItemHP.size(); i++)
	{
		Vec2 posItem = listItemHP.at(i)->getPosition();
		Size sizeItem = listItemHP.at(i)->spr->getContentSize();

		if (((dirPos.x >= posItem.x - sizeItem.width / 2 && dirPos.x <= posItem.x + sizeItem.width / 2)
			&& (dirPos.y >= posItem.y - sizeItem.height / 2 && dirPos.y <= posItem.y + sizeItem.height / 2)))
		{
			if (listItemHP.at(i)->check != true)
			{
				listItemHP.at(i)->check = true;
				EventCustom eventItem("addItem");
				_eventDispatcher->dispatchEvent(&eventItem);
				listItemHP.at(i)->removeFromParent();
				listItemHP.erase(i);
			}
		}
	}
}

void Logic::MovePlayer(float s)
{
	if (player->state == STATE::DEAD) return;

	x = player->direction.x;
	player->timeJump += s;

	// gravity of the game
	y = player->heightJump - 20 * (player->timeJump * player->timeJump);

	////player Splash
	//if (player->canSplash) {
	//	if (!player->isLookLeft) {
	//		x = 4;
	//	}
	//	else if (player->isLookLeft) {
	//		x = -4;
	//	}
	//}

	// check colision player vs block (ground) Map
	for (int i = 0; i < listTitleMap.size(); i++)
	{
		Vec2 objPos = listTitleMap.at(i)->getPosition();
		Size objSize = listTitleMap.at(i)->getContentSize();

		int objLeft = objPos.x;
		int objRight = objPos.x + objSize.width;
		int objTop = objPos.y + objSize.height;
		int objBot = objPos.y;

		if (player->GetBot() < objTop && player->GetTop() > objBot)
		{
			if (x > 0)
			{
				if (player->GetRight() <= objLeft && player->GetRight() + x > objLeft)
				{
					player->setPositionX(objLeft - player->defaultSize.width / 2);
					x = 0;
				}
			}
			else if (x < 0)
			{
				if (player->GetLeft() >= objRight && player->GetLeft() + x < objRight)
				{
					player->setPositionX(objRight + player->defaultSize.width / 2);
					x = 0;
				}
			}

			if (player->GetLeft() + x < objRight && player->GetRight() + x > objLeft)
			{
				if (y > 0)
				{
					if (player->GetTop() <= objBot && player->GetTop() + y > objBot)
					{
						player->setPositionY(objBot - player->defaultSize.height / 2);
						SetPlayerInLand();
					}
				}
				else if (y < 0)
				{
					if (player->GetBot() >= objTop && player->GetBot() + y < objTop)
					{
						player->setPositionY(objTop + player->defaultSize.height / 2);
						SetPlayerInLand();
					}
				}
			}
		}

		if (player->GetLeft() < objRight && player->GetRight() > objLeft)
		{
			if (y > 0)
			{
				if (player->GetTop() <= objBot && player->GetTop() + y > objBot)
				{
					player->setPositionY(objBot - player->defaultSize.height / 2);
					y = 0;
					player->timeJump = 0;
					player->heightJump = 0;
				}
			}
			else if (y < 0)
			{
				if (player->GetBot() >= objTop && player->GetBot() + y < objTop)
				{
					player->setPositionY(objTop + player->defaultSize.height / 2);
					SetPlayerInLand();
				}
			}
		}
	}

	//if (player->state != STATE::WALK && player->state != STATE::SPLASH) x = 0;
	if (player->state == STATE::ATTACK && player->isLand) x = 0;
	player->setPosition(player->getPosition() + Vec2(x, y));
}

void Logic::SetPlayerInLand() {
	y = 0;
	player->isLand = true;
	player->timeJump = 0;
	player->heightJump = 0;
}

void Logic::MoveBullet() {

	for (int i = 0; i < listArchery.size(); i++)
	{
		if (listArchery.at(i)->getName() == "remove")
		{
			listArchery.erase(i);
			i--;
			continue;
		}
	}
	for (int i = 0; i < listFireball.size(); i++)
	{
		if (listFireball.at(i)->getName() == "remove")
		{
			listFireball.erase(i);
			i--;
			continue;
		}
	}
	for (int i = 0; i < listShootWinzard.size(); i++)
	{
		auto shootWinzard = listShootWinzard.at(i);
		if (shootWinzard->getName() == "remove")
		{
			listShootWinzard.erase(i);
			i--;
			continue;
		}
	}
}

void Logic::MoveEnemy(float dt)
{
	dirPos = player->getPosition() + player->direction;
	playerSize = player->spr->getContentSize();

	//enemy skeleton
	for (int i = 0; i < listEnemyOnLandMove.size(); i++)
	{
		Vec2 positionEnemy = listEnemyOnLandMove.at(i)->getPosition() + listEnemyOnLandMove.at(i)->direction;
		Size sizeEnemy = listEnemyOnLandMove.at(i)->spr->getContentSize();
		// remove enemy
		if (listEnemyOnLandMove.at(i)->getName() == "remove")
		{
			listEnemyOnLandMove.erase(i);
			i--;
			continue;
		}
		else listEnemyOnLandMove.at(i)->AI();

	}

	//enemy dullnessShoot
	for (int i = 0; i < listEnemyDullnessShoot.size(); i++)
	{
		Vec2 epos = listEnemyDullnessShoot.at(i)->getPosition() + listEnemyDullnessShoot.at(i)->direction;

		EnemyDullness = listEnemyDullnessShoot.at(i);
		if (listEnemyDullnessShoot.at(i)->getName() == "remove")
		{
			listEnemyDullnessShoot.erase(i);
			i--;
			continue;
		}
		if (EnemyDullness->isLand)
		{
			// check distance shoot left
			if (((dirPos.x >= epos.x - 400 && dirPos.x <= listEnemyDullnessShoot.at(i)->getPosition().x)
				&& (dirPos.y >= epos.y - 32 && dirPos.y <= epos.y + 32)))
			{
				EnemyDullness->spr->setFlippedX(true);
				listEnemyDullnessShoot.at(i)->attack("attack-A%d.png", 6, 0.15f);
				delaycount += dt;
				if (delaycount >= delay)
				{
					auto data = new DataArchery();
					data->m_dirbullet = -180;
					data->m_posbullet = Vec2(EnemyDullness->getPositionX(), EnemyDullness->getPositionY() + 10);
					EventCustom eventShoot("DullnessShoot");
					eventShoot.setUserData(data);
					_eventDispatcher->dispatchEvent(&eventShoot);
					delaycount = 0;
				}
			}

			// check distance shoot right
			if (((dirPos.x <= epos.x + 400 && dirPos.x >= listEnemyDullnessShoot.at(i)->getPosition().x)
				&& (dirPos.y >= epos.y - 32 && dirPos.y <= epos.y + 32)))
			{
				EnemyDullness->spr->setFlippedX(false);
				listEnemyDullnessShoot.at(i)->attack("attack-A%d.png", 6, 0.15f);
				delaycount += dt;
				if (delaycount >= delay)
				{
					EnemyDullness = listEnemyDullnessShoot.at(i);
					auto data = new DataArchery();
					data->m_dirbullet = 0;
					data->m_posbullet = Vec2(EnemyDullness->getPositionX(), EnemyDullness->getPositionY() + 10);
					EventCustom eventShoot("DullnessShoot");
					eventShoot.setUserData(data);
					_eventDispatcher->dispatchEvent(&eventShoot);
					delaycount = 0;
				}
			}
		}
	}

	//enemy Winzard
	for (int i = 0; i < listEnemyWinzard.size(); i++)
	{
		Vec2 epos = listEnemyWinzard.at(i)->getPosition() + listEnemyWinzard.at(i)->direction;
		Vec2 dirPos = player->getPosition() + player->direction;
		auto enemyWinzard = listEnemyWinzard.at(i);

		//if (listEnemyWinzard.at(i)->getName() == "remove")
		//{
		//	listEnemyWinzard.erase(i);
		//	i--;
		//	continue;
		//}
		if (enemyWinzard->isLand)
		{
			// check distance shoot left
			if (((dirPos.x >= epos.x - 400 && dirPos.x <= listEnemyWinzard.at(i)->getPosition().x)
				&& (dirPos.y >= epos.y - 100 && dirPos.y <= epos.y + 100)))
			{
				enemyWinzard->spr->setFlippedX(false);
				enemyWinzard->attack("winzard-shoot (%d).png", 6, 0.15f);
				delaycount += dt;
				if (delaycount >= delay)
				{
					auto data = new DataShootWinzard();
					data->positionPlayer.x = player->getPosition().x - 40;
					data->positionPlayer.y = player->getPosition().y;

					data->positionShoot = Vec2(enemyWinzard->getPosition().x, enemyWinzard->getPosition().y);
					EventCustom eventShootWinzard("WinzardShoot");
					eventShootWinzard.setUserData(data);
					_eventDispatcher->dispatchEvent(&eventShootWinzard);
					delaycount = 0;
				}

			}
			else {
				enemyWinzard->spr->runAction(RepeatForever::create(enemyWinzard->CreateAnimation("winzard_Idle (%d).png", 5, 0.15f)));

			}
			// check distance shoot right
			if (((dirPos.x <= epos.x + 400 && dirPos.x >= listEnemyWinzard.at(i)->getPosition().x)
				&& (dirPos.y >= epos.y - 100 && dirPos.y <= epos.y + 100)))
			{
				enemyWinzard->spr->setFlippedX(true);
				enemyWinzard->attack("winzard-shoot (%d).png", 6, 0.15f);
				delaycount += dt;
				if (delaycount >= delay)
				{
					auto data = new DataShootWinzard();
					data->positionPlayer.x = player->getPosition().x + 40;
					data->positionPlayer.y = player->getPosition().y;
					data->positionShoot = Vec2(enemyWinzard->getPosition().x, enemyWinzard->getPosition().y);
					EventCustom eventShootWinzard("WinzardShoot");
					eventShootWinzard.setUserData(data);
					_eventDispatcher->dispatchEvent(&eventShootWinzard);
					delaycount = 0;
				}
			}
			else {
				enemyWinzard->spr->runAction(RepeatForever::create(enemyWinzard->CreateAnimation("winzard_Idle (%d).png", 5, 0.15f)));

			}
		}
	}

	// enemy Batman
	for (int i = 0; i < listBatEnemy.size(); i++)
	{
		if (listBatEnemy.at(i)->getName() == "remove")
		{
			listBatEnemy.erase(i);
			i--;
			continue;
		}
		else if (listBatEnemy.at(i)->getPositionY() > listBatEnemy.at(i)->maxUp)
		{
			listBatEnemy.at(i)->randomDir = 1;
			listBatEnemy.at(i)->AI();
		}
		else if (listBatEnemy.at(i)->getPositionY() < listBatEnemy.at(i)->maxDown)
		{
			listBatEnemy.at(i)->randomDir = 2;
			listBatEnemy.at(i)->AI();
		}
		else listBatEnemy.at(i)->AI();
	}

	//enemy Bubble
	for (int i = 0; i < listEnemyBubble.size(); i++)
	{
		/*	Vec2 positionEnemy = lisEnemyBubble.at(i)->getPosition() + lisEnemyBubble.at(i)->direction;
			Size sizeEnemy = lisEnemyBubble.at(i)->spr->getContentSize();*/
		if (listEnemyBubble.at(i)->getName() == "remove")
		{
			listEnemyBubble.erase(i);
			i--;
			continue;
		}
		else listEnemyBubble.at(i)->AI();
	}

	//enemy LothricKnight
	for (int i = 0; i < listEnemyLothricKnight.size(); i++)
	{
		/*Vec2 positionEnemy = listEnemyLothricKnight.at(i)->getPosition() + listEnemyLothricKnight.at(i)->direction;
		Size sizeEnemy = listEnemyLothricKnight.at(i)->spr->getContentSize();*/

		if (listEnemyLothricKnight.at(i)->getName() == "remove")
		{
			listEnemyLothricKnight.erase(i);
			i--;
			continue;
		}
		else listEnemyLothricKnight.at(i)->AI();
	}

	////Climb
	//	// enemy Batman
	//for (int i = 0; i < lisClimb.size(); i++)
	//{

	//	if (lisClimb.at(i)->getPositionY() > lisClimb.at(i)->maxUp)
	//	{
	//		lisClimb.at(i)->randomDir = 1;
	//		lisClimb.at(i)->move();
	//	}
	//	else if (lisClimb.at(i)->getPositionY() < lisClimb.at(i)->maxDown)
	//	{
	//		lisClimb.at(i)->randomDir = 2;
	//		lisClimb.at(i)->move();
	//	}
	//	else lisClimb.at(i)->move();
	//}

}

void Logic::MoveBossBuffalo()
{
	// face 1 of the boss
	if (buffalo->state != STATE::DEAD && buffalo->hp > 0
		&& buffalo->state != STATE::ATTACK)
	{
		dirPos = player->getPosition() + player->direction;
		playerSize = player->spr->getContentSize();
		boss = buffalo->getPosition();
		bossSize = buffalo->spr->getContentSize();
		//check player có trong khoảng cách ko
		if (((dirPos.x > boss.x - 1000 && dirPos.x < boss.x - bossSize.width / 2) ||
			(dirPos.x > boss.x + bossSize.width / 2 && dirPos.x < boss.x + 1000)) &&
			((dirPos.y > boss.y - bossSize.height / 2) || (dirPos.y < boss.y + bossSize.height / 2)))
		{
			if (!buffalo->isDead) {
				buffalo->state = STATE::WALK;
				buffalo->AI();
			}
		}
		// distance  attack
		if (((dirPos.x > boss.x - bossSize.width && dirPos.x < boss.x - bossSize.width / 2) ||
			(dirPos.x > boss.x + bossSize.width / 2 && dirPos.x < boss.x + bossSize.width)) &&
			((dirPos.y > boss.y - bossSize.height / 2) && (dirPos.y < boss.y + bossSize.height / 2))
			&& buffalo->state == STATE::WALK && buffalo->canAttack)
		{
			AttackBossBuffalo();
		}
	}
	// check distance move and attack
	if (buffalo->state == STATE::WALK && buffalo->state != STATE::DEAD)
	{
		buffalo->AI();
		Size sizeCollision = listCollision.at(0)->getContentSize();
		Vec2 posCollsionFirst = listCollision.at(0)->getPosition();
		Vec2 posCollisionLast = listCollision.at(1)->getPosition();
		//check player có trong physic ko và va chạm với điểm collision đầu tiên
		if (boss.x + bossSize.width / 2 >= posCollsionFirst.x - sizeCollision.width / 2 && boss.x - bossSize.width / 2 < posCollsionFirst.x + sizeCollision.width / 2
			&& boss.y + bossSize.height / 2 > posCollsionFirst.y&& boss.y - bossSize.height / 2 < posCollsionFirst.y + sizeCollision.height && !buffalo->isCollision)
		{
			buffalo->isCollision = true;
			//bên trong physic ben trái
			if ((dirPos.x >= buffalo->getPosition().x - bossSize.width / 2 && dirPos.x < buffalo->getPosition().x)
				&& (dirPos.y > boss.y - bossSize.height / 2 && dirPos.y < boss.y + bossSize.height / 2) && buffalo->isCollision)
			{
				buffalo->direction.x = buffalo->speedDistanceAttack;
				buffalo->spr->setFlippedX(true);
				buffalo->isLookLeft = true;
			}
			//bên trong physic bên phải
			else if ((dirPos.x <= buffalo->getPosition().x + bossSize.width / 2 && dirPos.x > buffalo->getPosition().x)
				&& (dirPos.y > boss.y - bossSize.height / 2 && dirPos.y < boss.y + bossSize.height / 2) && buffalo->isCollision)
			{
				buffalo->direction.x = buffalo->speedDistanceAttack;
				buffalo->spr->setFlippedX(false);
				buffalo->isLookLeft = false;
			}
		}
		//check player có trong physic ko và va chạm với điểm collision cuối
		else if (boss.x + bossSize.width / 2 >= posCollisionLast.x - sizeCollision.width / 2 && boss.x - bossSize.width / 2 < posCollisionLast.x + sizeCollision.width / 2
			&& boss.y + bossSize.height / 2 > posCollisionLast.y&& boss.y - bossSize.height / 2 < posCollisionLast.y + sizeCollision.height && !buffalo->isCollision)
		{
			buffalo->isCollision = true;
			//bên trong physic ben trái
			if ((dirPos.x >= buffalo->getPosition().x - bossSize.width / 2 && dirPos.x < buffalo->getPosition().x)
				&& (dirPos.y > boss.y - bossSize.height / 2 && dirPos.y < boss.y + bossSize.height / 2) && buffalo->isCollision)
			{
				buffalo->direction.x = -buffalo->speedDistanceAttack;
				buffalo->spr->setFlippedX(true);
				buffalo->isLookLeft = true;
			}
			//bên trong physic bên phải
			else if ((dirPos.x <= buffalo->getPosition().x + bossSize.width / 2 && dirPos.x > buffalo->getPosition().x)
				&& (dirPos.y > boss.y - bossSize.height / 2 && dirPos.y < boss.y + bossSize.height / 2) && buffalo->isCollision)
			{
				buffalo->direction.x = -buffalo->speedDistanceAttack;
				buffalo->spr->setFlippedX(true);
				buffalo->isLookLeft = true;
			}
		}
		//check player có trong physic hay ko và ko va cham với collision nào
		else
		{
			//bên trong physic ben trái
			if ((dirPos.x > buffalo->getPosition().x - bossSize.width / 2 && dirPos.x < buffalo->getPosition().x)
				&& (dirPos.y > boss.y - bossSize.height / 2 && dirPos.y < boss.y + bossSize.height / 2) && !buffalo->isCollision)
			{
				buffalo->isCollision = false;
				buffalo->direction.x = buffalo->speedDistanceAttack;
				buffalo->spr->setFlippedX(false);
				buffalo->isLookLeft = false;
			}
			//bên trong physic bên phải
			else if ((dirPos.x < buffalo->getPosition().x + bossSize.width / 2 && dirPos.x > buffalo->getPosition().x)
				&& (dirPos.y > boss.y - bossSize.height / 2 && (dirPos.y < boss.y + bossSize.height / 2) && !buffalo->isCollision))
			{
				buffalo->isCollision = false;
				buffalo->direction.x = -buffalo->speedDistanceAttack;
				buffalo->spr->setFlippedX(true);
				buffalo->isLookLeft = true;
			}
		}
		// Phía bên trái boss ko trong physic
		if ((dirPos.x > buffalo->getPosition().x - buffalo->distanceAttack
			&& dirPos.x < buffalo->getPosition().x - bossSize.width))
		{
			buffalo->isCollision = false;
			buffalo->direction.x = -buffalo->speed;
			buffalo->spr->setFlippedX(false);
			buffalo->isLookLeft = false;
		}
		// Phía bên phải boss ko trong physic
		else if ((dirPos.x > buffalo->getPosition().x + bossSize.width
			&& dirPos.x < buffalo->getPosition().x + buffalo->distanceAttack))
		{
			buffalo->isCollision = false;
			buffalo->direction.x = buffalo->speed;
			buffalo->spr->setFlippedX(true);
			buffalo->isLookLeft = true;
		}
	}
	// check dead boss
	if (buffalo->state == STATE::DEAD)
	{
		DeadBossBuffalo();
	}
	else {

		buffalo->setPosition(buffalo->getPosition() + buffalo->direction);
	}
}

void Logic::AttackBossBuffalo() {

	buffalo->state = STATE::ATTACK;
	// random %hp boss type attack			
	if (buffalo->hp >= (buffalo->defaulHP * 7) / 10) {
		randomTypeAttack = 1;
	}
	else if (buffalo->hp >= (buffalo->defaulHP * 4) / 10
		&& buffalo->hp < (buffalo->defaulHP * 7) / 10) {
		randomTypeAttack = rand() % 4 + 1;
	}
	else if (buffalo->hp < (buffalo->defaulHP * 4) / 10) {
		randomTypeAttack = random(3, 5);
	}
	else if (buffalo->hp <= 0) randomTypeAttack = 0;

	if (randomTypeAttack == 3 || randomTypeAttack == 5)
	{
		// perform a weapon attack B
		buffalo->stopAllActions();
		buffalo->runAction(Sequence::create(CallFunc::create([&]() {
			buffalo->direction = Vec2(0, 0);
			buffalo->attackB();
			}), DelayTime::create(0.2f), CallFunc::create([&]() {

				randomTypeAttack = rand() % 4 + 1;
				if (randomTypeAttack != 3)
				{
					randomTypeAttack = 3;
				}
				}), nullptr));

		// perform a weapon fireball
		buffalo->runAction(Sequence::create(DelayTime::create(0.25f), CallFunc::create([&]() {
			buffalo->direction = Vec2(0, 0);
			bossSize = buffalo->spr->getContentSize();

			DataFireball* dataFireball = new DataFireball();
			EventCustom event("BuffaloShoot");
			dataFireball->positionLeftFireball = Vec2(buffalo->getPosition().x - bossSize.width, buffalo->getPosition().y - bossSize.height + 75);
			dataFireball->positionRightFireball = Vec2(buffalo->getPosition().x, buffalo->getPosition().y - bossSize.height + 75);
			event.setUserData(dataFireball);
			_eventDispatcher->dispatchEvent(&event);

			}), nullptr));
	}
	// Delete boss components when switching to face 2
	else if (randomTypeAttack == 0)
	{
		buffalo->stopAllActions();
		buffalo->bodyWeapon->removeFromWorld();
		buffalo->direction = Vec2(0, 0);
		buffalo->state = STATE::DEAD;
	}
	// perform a weapon attack A
	else if (buffalo->state != STATE::DEAD)
	{
		auto randomAttack = random(1, 3);
		buffalo->stopAllActions();
		buffalo->runAction(Sequence::create(
			CallFunc::create([&]() {
				buffalo->direction = Vec2(0, 0);
				buffalo->attackA(); }), nullptr));
	}
	buffalo->setPosition(buffalo->getPosition() + buffalo->direction);
}

void Logic::DeadBossBuffalo()
{
	// Switch to face 2
	buffalo->direction = Vec2(0, 0);
	if (buffalo->faceBoss == 2) {
		buffalo->Respon();
	}
	// dead boss
	else if (buffalo->faceBoss == 3) {
		buffalo->isDead = true;
		buffalo->spr->setColor(Color3B::WHITE);
		Camera::getDefaultCamera()->stopAllActions();
	}
}