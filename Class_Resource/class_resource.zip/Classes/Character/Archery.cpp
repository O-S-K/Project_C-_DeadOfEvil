#include "Archery.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"

USING_NS_CC;

using namespace std;

Archery* Archery::create(string str)
{
	auto object = Archery::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 3);
	object->attributesData();
	return object;
}

bool Archery::init()
{
	if (!Node::init()) return false;

	damage = 10;
	this->setTag(SET_TAG_ARCHERY);
	this->setName("Setup");
	this->schedule(schedule_selector(Archery::update));
	return true;
}

void Archery::attributesData()
{
	auto AcheryPhysic = PhysicsBody::createBox(this->spr->getContentSize());
	AcheryPhysic->setCollisionBitmask(ARCHERY_COLLISION_BITMASK);
	AcheryPhysic->setContactTestBitmask(true);
	AcheryPhysic->setDynamic(false);
	setPhysicsBody(AcheryPhysic);
}

void Archery::update(float dt)
{
	Vec2 pos = this->getPosition();
	float robullet = this->getRotation();
	if (robullet == -180) pos.x -= speed;
	else if (robullet == 0) pos.x += speed;
	this->setPosition(pos);
}


