#ifndef __ARCHERY_H__
#define __ARCHERY_H__

#include "cocos2d.h"
#include "Unit.h"

class Archery : public Unit
{
public:
	virtual bool init();
	static Archery* create(string);
	Node* node;
	float speed = 2;
	void attributesData();
	void update(float);
	CREATE_FUNC(Archery);
};

#endif // __ARCHERY_H__
