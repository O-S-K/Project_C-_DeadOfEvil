﻿#include "Player.h"
#include "cocos/ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"
#include "Scene/FShake.h"

USING_NS_CC;
using namespace std;
using namespace CocosDenshion;


Player* Player::create(string str)
{
	auto object = Player::create();
	object->spr = Sprite::create(str);
	auto size = Vec2(object->spr->getContentSize().width * 1.05F,
		object->spr->getContentSize().height * 1.3F);
	object->defaultSize = size;
	object->spr->setAnchorPoint(Vec2(0.5f, 0));
	object->spr->setPositionY(-object->spr->getContentSize().height / 2);
	object->addChild(object->spr, 5);

	object->sprBlood = Sprite::create();
	object->addChild(object->sprBlood, 10);
	object->attributesData();
	return object;
}

bool Player::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/Idle/Player_Idle.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/Attack/Player_Attack.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/Dead/Player_Dead.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/Jump/Player_Jump.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/Roll/Player_Roll.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/Splash/Player_Splash.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/Run/Player_Run.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/Shield/Player_Shield.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Player/RecHP/Player_RecHP.plist");

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Blood/Blood.plist");


	this->setTag(SET_TAG_PLAYER);
	audioFX = SimpleAudioEngine::getInstance();

	/*smokeParticle = ParticleSystemQuad::create("Effects/particle_texture.plist");
	smokeParticle->setPosition(visibleSize.width / 2, visibleSize.height / 2 - 12.5F);
	smokeParticle->start();
	smokeParticle->setAutoRemoveOnFinish(false);
	this->addChild(smokeParticle);*/

	GetUserData();
	receiveEvent();

	return true;
}

void Player::GetUserData()
{
	auto getData = UserDefault::sharedUserDefault();
	this->level = getData->getIntegerForKey("LevelPlayer");
	this->totalExp = getData->getIntegerForKey("totalExpPlayer");
	this->currentExp = getData->getIntegerForKey("expPlayer");
	this->damage = getData->getIntegerForKey("damagePlayer");
	this->hp = getData->getIntegerForKey("hpPlayer");
	this->mp = getData->getIntegerForKey("mpPlayer");
	this->moveForce = getData->getIntegerForKey("speedPlayer");
	this->countItemHp = getData->getIntegerForKey("itemhp");
}

void Player::receiveEvent() {

	auto eventMoveLeft = EventListenerCustom::create("eventMoveLeft", CC_CALLBACK_1(Player::TouchMoveLeft, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventMoveLeft, this);

	auto eventMoveRight = EventListenerCustom::create("eventMoveRight", CC_CALLBACK_1(Player::TouchMoveRight, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventMoveRight, this);

	auto eventAttack = EventListenerCustom::create("eventAttack", CC_CALLBACK_1(Player::TouchAttack, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventAttack, this);

	auto eventJump = EventListenerCustom::create("eventJump", CC_CALLBACK_1(Player::TouchJump, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventJump, this);

	auto eventRoll = EventListenerCustom::create("eventRoll", CC_CALLBACK_1(Player::TouchSplash, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventRoll, this);

	auto eventEndMove = EventListenerCustom::create("eventEndMove", CC_CALLBACK_1(Player::EndMove, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventEndMove, this);

	auto eventRecHP = EventListenerCustom::create("eventRecHP", CC_CALLBACK_1(Player::TouchRecHP, this));
	_eventDispatcher->addEventListenerWithSceneGraphPriority(eventRecHP, this);
}

void Player::attributesData()
{
	auto sizeSpr = spr->getContentSize();
	auto sizeBody = Size(sizeSpr.width / 1.75f, sizeSpr.height);
	playerBody = PhysicsBody::createBox(sizeBody);
	playerBody->setRotationEnable(false);
	playerBody->setGravityEnable(false);
	playerBody->setCollisionBitmask(0);
	playerBody->setContactTestBitmask(PLAYER_COLLISION_BITTMASK);
	setPhysicsBody(playerBody);

	keyboardEvent = EventListenerKeyboard::create();
	keyboardEvent->onKeyPressed = CC_CALLBACK_2(Player::onKeyDown, this);
	keyboardEvent->onKeyReleased = CC_CALLBACK_2(Player::onKeyUp, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(keyboardEvent, this);
	this->schedule(schedule_selector(Player::update));
}
void Player::onKeyDown(EventKeyboard::KeyCode keyCode, Event* e)
{
	if (keyCode == EventKeyboard::KeyCode::KEY_A)
	{
		moveLeft = true;
		isLookLeft = true;
		moveDirection = -1;
		if (state == STATE::WALK) caseState();
	}
	if (keyCode == EventKeyboard::KeyCode::KEY_D)
	{
		moveRight = true;
		isLookLeft = false;
		moveDirection = 1;
		if (state == STATE::WALK) caseState();
	}

	if (keyCode == EventKeyboard::KeyCode::KEY_SPACE)   jump();
	if (keyCode == EventKeyboard::KeyCode::KEY_J)		attack();
	if (keyCode == EventKeyboard::KeyCode::KEY_SHIFT)   splash();
	if (keyCode == EventKeyboard::KeyCode::KEY_L)		shield();
	if (keyCode == EventKeyboard::KeyCode::KEY_R) {
		EventCustom eventItem("removeItem");
		_eventDispatcher->dispatchEvent(&eventItem);
		recuperateHP();
	}
}
void Player::onKeyUp(EventKeyboard::KeyCode keyCode, Event* e)
{
	if (keyCode == EventKeyboard::KeyCode::KEY_A || keyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW)
	{
		moveLeft = false;
		if (moveRight) {
			moveDirection = 1;
			isLookLeft = false;
		}
		else moveDirection = 0;
		caseState();
	}
	if (keyCode == EventKeyboard::KeyCode::KEY_D || keyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW)
	{
		moveRight = false;
		if (moveLeft) {
			moveDirection = -1;
			isLookLeft = true;
		}
		else moveDirection = 0;
		caseState();
	}
}

void Player::TouchMoveLeft(EventCustom* Left)
{
	moveLeft = true;
	touchLeft = static_cast<DataEvent*>(Left->getUserData());
	if (touchLeft->isMoveLeft) {
		isLookLeft = true;
		moveDirection = -1;
		if (state != STATE::WALK) return;
		caseState();
	}
	else {
		moveLeft = false;
		moveDirection = 0;
		caseState();
	}
}
void Player::TouchMoveRight(EventCustom* Right)
{
	moveRight = true;
	touchRight = static_cast<DataEvent*>(Right->getUserData());
	if (touchRight->isMoveRight) {
		isLookLeft = false;
		moveDirection = 1;
		if (state != STATE::WALK) return;
		caseState();
	}
	else {
		moveRight = false;
		moveDirection = 0;
		caseState();
	}
}

void Player::TouchAttack(EventCustom* canAttack) {
	DataEvent* _attack = static_cast<DataEvent*>(canAttack->getUserData());
	if (_attack) attack();
}
void Player::TouchJump(EventCustom* canJump) {
	DataEvent* _jump = static_cast<DataEvent*>(canJump->getUserData());
	if (_jump) jump();
}
void Player::TouchSplash(EventCustom* canSplash) {
	DataEvent* _splash = static_cast<DataEvent*>(canSplash->getUserData());
	if (_splash) splash();
}

void Player::EndMove(EventCustom* end) {
	DataEvent* _endTouch = static_cast<DataEvent*>(end->getUserData());

	if (_endTouch->moveDir == 0)
	{
		moveLeft = false;
		moveRight = false;
		if (isLand && !moveLeft && !moveRight)
		{
			if (state == STATE::ATTACK || state == STATE::SPLASH || state == STATE::RECHP)  return;
			else moveDirection = 0;
		}
		caseState();
	}
}
void Player::TouchRecHP(EventCustom* recHP) {
	DataEvent* _recHP = static_cast<DataEvent*>(recHP->getUserData());
	if (_recHP) recuperateHP();
}

void Player::update(float dt)
{
	recuperateMP(dt);
	if (currentExp >= totalExp) upLevel();
	if (state == STATE::WALK && state != STATE::DEAD) move();

}

void Player::upLevel()
{
	auto MAX_LEVEL = 10;
	if (level < MAX_LEVEL) {
		level += 1;
		damage += 9;
		moveForce += 0.15F;
		totalExp += totalExp;
	}
}

void Player::move()
{
	direction = Vec2(moveForce * moveDirection, 0);
	if (moveDirection != 0) spr->setScaleX(moveDirection);
}

void Player::caseState()
{
	if (state == STATE::ATTACK || state == STATE::SPLASH ||
		state == STATE::RECHP || !isLand) return;
	if (moveDirection != 0)
	{
		state = STATE::WALK;
		spr->stopAllActions();
		spr->runAction(RepeatForever::create(CreateAnimation("PlayerRun (%d).png", 8, .09F)));
	}
	else if (moveDirection == 0)
	{
		state = STATE::WALK;
		spr->stopAllActions();
		spr->runAction(RepeatForever::create(CreateAnimation("PlayerIdle (%d).png", 11, .1F)));
	}
}

void Player::jump()
{
	if (state == STATE::SPLASH || state == STATE::RECHP) return;
	if (isLand && canAttack && !canSplash && mp > 30) {

		mp -= 30;
		delayMp = 0;

		timeJump = 0;
		heightJump = 4.5f;

		isLand = false;
		canJump = true;
	   playSound = UserDefault::sharedUserDefault()->getBoolForKey("playerSound");
	   if (playSound == true)
	   {
		   audioFX->playEffect("Sounds/SFX/Player/jump3.wav");
	   }

		DataEvent* dataMP = new DataEvent();
		dataMP->mp = this->mp;

		EventCustom event("FitnessMPPlayer");
		event.setUserData(dataMP);
		_eventDispatcher->dispatchEvent(&event);

		spr->stopAllActions();
		spr->runAction(Sequence::create(CreateAnimation("PlayerJump (%d).png", 12, .075F),
			CallFunc::create([&]() {
				state = STATE::WALK;
				caseState();
				}), nullptr));
	}
}

void Player::attack()
{
	if (state == STATE::SPLASH || state == STATE::DEAD || state == STATE::RECHP) return;
	if (canAttack && mp > 20)
	{
		mp -= 20;
		delayMp = 0;

		DataEvent* dataMP = new DataEvent();
		dataMP->mp = this->mp;

		EventCustom event("FitnessMPPlayer");
		event.setUserData(dataMP);
		_eventDispatcher->dispatchEvent(&event);

		playSound = UserDefault::sharedUserDefault()->getBoolForKey("playerSound");
		if (playSound == true)
		{
			audioFX->playEffect("Sounds/SFX/Player/attack1.wav");
		}

		canAttack = false;
		state = STATE::ATTACK;
		node = Node::create();
		this->addChild(node);

		bodyWeapon = PhysicsBody::createBox(Size(30, 20));
		bodyWeapon->setRotationEnable(false);
		bodyWeapon->setDynamic(false);
		bodyWeapon->setCollisionBitmask(WEPON_PLAYER_COLLISION_BITTMASK);
		bodyWeapon->setCategoryBitmask(WEAPON_PLAYER_CATEGORY_BITTMASK);
		bodyWeapon->setContactTestBitmask(true);
		node->setTag(SET_TAG_WEAPON_PLAYER);

		if (isLookLeft)  bodyWeapon->setPositionOffset(Vec2(-20, 0));
		if (!isLookLeft) bodyWeapon->setPositionOffset(Vec2(20, 0));
		node->setPhysicsBody(bodyWeapon);

		spr->stopAllActions();
		spr->runAction(Sequence::create(CreateAnimation("PlayerAttack (%d).png", 10, .05F),
			CallFunc::create([&]() {
				canAttack = true;
				bodyWeapon->removeFromWorld();
				state = STATE::WALK;
				caseState();
				}), nullptr));
	}
}

void Player::splash()
{
	if (state == STATE::ATTACK || state == STATE::RECHP) return;
	if (!canSplash && isLand && mp > 45 && (moveLeft || moveRight))
	{
		mp -= 45;
		delayMp = 0;

		isLand = false;
		canSplash = true;

		DataEvent* dataMP = new DataEvent();
		dataMP->mp = this->mp;
		EventCustom event("FitnessMPPlayer");
		event.setUserData(dataMP);
		_eventDispatcher->dispatchEvent(&event);

		playSound = UserDefault::sharedUserDefault()->getBoolForKey("playerSound");
		if (playSound == true)
		{
			audioFX->playEffect("Sounds/SFX/Player/roll1.wav");
		}

		state = STATE::SPLASH;

		auto sizeSpr = spr->getContentSize();
		auto sizeBody = Size(sizeSpr.width / 1.75f, sizeSpr.height / 3);
		playerBody = PhysicsBody::createBox(sizeBody);
		playerBody->setPositionOffset(Vec2(0, -15));
		playerBody->setRotationEnable(false);
		playerBody->setGravityEnable(false);
		playerBody->setCollisionBitmask(0);
		setPhysicsBody(playerBody);

		spr->stopAllActions();
		spr->runAction(Sequence::create(CreateAnimation("PlayerRoll (%d).png", 15, .05F),
			CallFunc::create([&]() {

				playerBody->removeFromWorld();
				auto sizeSpr = spr->getContentSize();
				auto sizeBody = Size(sizeSpr.width / 1.75f, sizeSpr.height);
				playerBody = PhysicsBody::createBox(sizeBody);
				playerBody->setRotationEnable(false);
				playerBody->setGravityEnable(false);
				playerBody->setCollisionBitmask(0);
				playerBody->setContactTestBitmask(PLAYER_COLLISION_BITTMASK);
				setPhysicsBody(playerBody);
				//this->setTag(SET_TAG_PLAYER);
				isLand = true;
				canSplash = false;
				state = STATE::WALK;
				caseState();
				}), nullptr));
	}
}

void Player::shield()
{
	if (isLand) {
		direction = Vec2(0, 0);
		state = STATE::SHIELD;
		spr->stopAllActions();
		spr->runAction(Sequence::create(CreateAnimation("PlayerShield (%d).png", 6, .05F),
			CallFunc::create([&]() {
				state = STATE::WALK;
				moveDirection = 0;
				if (moveLeft || moveRight || canSplash) {
					isLand = true;
					caseState();
				}
				}), nullptr));
	}
}

void Player::recuperateHP()
{
	if (isLand && (this->hp < 100 && this->hp > 0) && countItemHp >= 0 && mp > 15)
	{
		delayMp = 0;
		this->mp -= 15;
		isLand = false;

		playSound = UserDefault::sharedUserDefault()->getBoolForKey("playerSound");
		if (playSound == true)
		{
			audioFX->playEffect("Sounds/SFX/Player/recHp1.wav");
		}

		UserDefault* def = UserDefault::sharedUserDefault();
		if (hp <= 50) def->setIntegerForKey("hpPlayer", this->hp += 50);
		else if (hp > 50) def->setIntegerForKey("hpPlayer", this->hp += (100 - hp));
		def->flush();

		DataEvent* dataHP = new DataEvent();
		dataHP->hp = def->getIntegerForKey("hpPlayer");
		EventCustom eventHP("TakeDamgeHPPlayer");
		eventHP.setUserData(dataHP);
		_eventDispatcher->dispatchEvent(&eventHP);

		DataEvent* dataMP = new DataEvent();
		dataMP->mp = this->mp;
		EventCustom eventMP("FitnessMPPlayer");
		eventMP.setUserData(dataMP);
		_eventDispatcher->dispatchEvent(&eventMP);

		state = STATE::RECHP;
		direction = Vec2(0, 0);
		spr->stopAllActions();
		spr->runAction(Sequence::create(CreateAnimation("PlayerRecHP (%d).png", 5, .15F),
			CallFunc::create([&]() {
				state = STATE::WALK;
				isLand = true;
				caseState();
				}), nullptr));
	}
}

void Player::recuperateMP(float dt)
{
	if (mp < 100 && mp > 0)
	{
		delayMp += 2;
		if (delayMp >= 100) mp += 0.5F;
		if (mp >= 100) delayMp = 0;

		DataEvent* dataMP = new DataEvent();
		dataMP->mp = this->mp;
		EventCustom event("FitnessMPPlayer");
		event.setUserData(dataMP);
		_eventDispatcher->dispatchEvent(&event);
	}
}

void Player::takeDamge(int damage)
{
	playSound = UserDefault::sharedUserDefault()->getBoolForKey("playerSound");
	if (playSound == true)
	{
		audioFX->playEffect("Sounds/SFX/Player/takedamage.wav");
	}

	this->runAction(Sequence::create(DelayTime::create(.25F),
		CallFunc::create([&]() {
			FShake* shake = FShake::create(.1F, 30);
			Camera::getDefaultCamera()->runAction(shake);
			}), nullptr));

	UserDefault* def = UserDefault::sharedUserDefault();
	def->setIntegerForKey("hpPlayer", hp -= damage);
	def->flush();

	DataEvent* data = new DataEvent();
	data->hp = def->getIntegerForKey("hpPlayer");
	EventCustom event("TakeDamgeHPPlayer");
	event.setUserData(data);
	_eventDispatcher->dispatchEvent(&event);

	this->sprBlood->setVisible(true);
	sprBlood->runAction(Sequence::create(DelayTime::create(.25F),
		CreateAnimation("effectBlood_0%d.png", 7, .075f),
		CallFunc::create([&]() {
			this->sprBlood->setVisible(false);
			}), nullptr));
	if (hp <= 0) dead();
}

void Player::dead()
{
	state = STATE::DEAD;
	playSound = UserDefault::sharedUserDefault()->getBoolForKey("playerSound");
	if (playSound == true)
	{
		audioFX->playEffect("Sounds/SFX/Player/dead1.wav");
	}

	auto indexMap = UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap");
	UserDefault* def = UserDefault::sharedUserDefault();

	def->setIntegerForKey("IndexMap", indexMap);
	def->setIntegerForKey("LevelPlayer", level);
	def->setIntegerForKey("totalExpPlayer", totalExp);
	def->setIntegerForKey("expPlayer", currentExp);
	def->setIntegerForKey("hpPlayer", hp);
	def->setIntegerForKey("mpPlayer", mp);
	def->setIntegerForKey("damagePlayer", damage);
	def->setIntegerForKey("speedPlayer", moveForce);
	countItemHp = 2;
	def->setIntegerForKey("itemhp", countItemHp);
	def->flush();

	playerBody->setGravityEnable(true);
	playerBody->setCollisionBitmask(PLAYER_COLLISION_BITTMASK);
	playerBody->setCategoryBitmask(PLAYER_CATEGORY_BITTMASK);
	playerBody->setContactTestBitmask(PLAYER_COLLISION_BITTMASK);
	this->getEventDispatcher()->removeEventListener(keyboardEvent);

	this->spr->stopAllActions();
	this->spr->runAction(CreateAnimation("Player_Dead (%d).png", 12, .075F));

	this->runAction(Sequence::create(DelayTime::create(2),
		CallFunc::create([&]() {
			Director::getInstance()->replaceScene(GameOver::create());
			}), nullptr));
}

int Player::GetLeft()
{
	left = getPosition().x - defaultSize.width / 2;
	return left;
}
int Player::GetRight()
{
	right = getPosition().x + defaultSize.width / 2;
	return right;
}
int Player::GetTop()
{
	top = getPosition().y + defaultSize.height / 2;
	return top;
}
int Player::GetBot()
{
	bot = getPosition().y - defaultSize.height / 2;
	return bot;
}