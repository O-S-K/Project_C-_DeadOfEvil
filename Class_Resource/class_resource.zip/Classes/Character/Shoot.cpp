#include "Shoot.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"
#include <math.h>

USING_NS_CC;
using namespace std;

Shoot* Shoot::create(string str, Vec2 _positionplayer, Vec2 _positionShoot, Size range)
{
	auto object = Shoot::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 5);
	object->attributesData();
	object->checkPlayer(_positionplayer, _positionShoot, range);

	return object;
}

bool Shoot::init()
{
	if (!Node::init()) return false;

	damage = 10;
	this->setTag(SET_TAG_SHOOT);
	this->setName("Setup");
	//checkPlayer();
	this->schedule(schedule_selector(Shoot::update));
	return true;
}

void Shoot::attributesData()
{
	auto boydShoot = PhysicsBody::createBox(this->spr->getContentSize());
	boydShoot->setCollisionBitmask(SHOOT_COLLISION_BITMASK);
	boydShoot->setContactTestBitmask(true);
	boydShoot->setDynamic(false);
	this->setPhysicsBody(boydShoot);
}


void Shoot::checkPlayer(Vec2 _posplayer, Vec2 _positionShoot, Size _rangeShoot)
{
	positionPlayer = _posplayer;
	positionShoot = _positionShoot;
	rangeShoot = _rangeShoot;

	xE = std::sqrtf((positionShoot.x * positionShoot.x) + (positionShoot.y * positionShoot.y));
	yE = std::sqrtf((positionPlayer.x * positionPlayer.x) + (positionPlayer.y * positionPlayer.y));
	total = ((positionShoot.x * positionShoot.y) + (positionPlayer.x * positionPlayer.y)) / (std::fabsf(xE) * std::fabsf(yE));

}

void Shoot::update(float dt)
{
	//ben trai
	if (positionShoot.x > positionPlayer.x)
	{
		x = this->getPosition().x - 3;
	}
	//ben phai
	else if (positionShoot.x < positionPlayer.x)
	{
		x = this->getPosition().x + 3;
	}
	//ben tren
	if (positionShoot.y + rangeShoot.height / 2 < positionPlayer.y)
	{
		y = this->getPosition().y + (total);
	}
	//ben duoi
	else if (positionShoot.y - rangeShoot.height / 2 > positionPlayer.y)
	{
		y = this->getPosition().y + (-total);
	}
	else if ((positionShoot.y <= positionPlayer.y + rangeShoot.height / 2) && (positionShoot.y >= positionPlayer.y - rangeShoot.width / 2))
	{
		y = this->getPosition().y;
	}

	this->setPosition(Vec2(x, y));
}