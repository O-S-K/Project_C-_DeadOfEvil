#ifndef __TARGET_H__
#define __TARGET_H__

#include "cocos2d.h"
#include "Unit.h"

class Target : public Unit
{
public:
	virtual bool init();
	static Target* create(string);
	Node* node;

	void attributesData();
	CREATE_FUNC(Target);
};

#endif // __TARGET_H__
