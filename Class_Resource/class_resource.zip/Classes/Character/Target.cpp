#include "Target.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"

USING_NS_CC;

using namespace std;

Target* Target::create(string str)
{
	auto object = Target::create();
	object->spr = Sprite::create(str);
	object->spr->setFlippedX(true);
	object->addChild(object->spr, 5);
	object->attributesData();
	return object;
}

bool Target::init()
{
	if (!Node::init()) return false;

	this->setTag(SET_TAG_CONG_CHUA);
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Object/CongChua/CongChuaIdle.plist");

	return true;
}

void Target::attributesData()
{
	spr->runAction(RepeatForever::create(CreateAnimation("CongChuaIdle (%d).png", 4, 0.1f)));
	auto sprTargetBody = PhysicsBody::createBox(spr->getContentSize());
	sprTargetBody->setRotationEnable(false);
	sprTargetBody->setCollisionBitmask(TARGET_COLLISION_BITTMASK);
	sprTargetBody->setContactTestBitmask(TARGET_COLLISION_BITTMASK);
	sprTargetBody->setCategoryBitmask(TARGET_COLLISION_BITTMASK);
	sprTargetBody->setDynamic(false);
	setPhysicsBody(sprTargetBody);
}



