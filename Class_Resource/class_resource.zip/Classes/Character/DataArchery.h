#ifndef __DATAARCHERY_H__
#define __DATAARCHERY_H__

#include "cocos2d.h"

USING_NS_CC;

class DataArchery
{
public:

	float m_dirbullet;
	cocos2d::Vec2 m_posbullet;
};
class DataFireball {
public:
	cocos2d::Vec2 positionLeftFireball;
	cocos2d::Vec2 positionRightFireball;

};
class DataShootWinzard
{
public:
	cocos2d::Vec2 positionShoot;
	cocos2d::Vec2 positionPlayer;
};
#endif //__DATAARCHERY_H__
