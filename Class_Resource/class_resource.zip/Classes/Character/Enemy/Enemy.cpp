#include "Enemy.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"
#include "Scene/FShake.h"

USING_NS_CC;
using namespace std;

void Enemy::move()
{
	if (isEnemyMove)
	{
		if (randomDir == 1)
		{
			direction = Vec2(-1, 0);
			this->spr->setFlippedX(true);
		}
		else if (randomDir == 2)
		{
			direction = Vec2(1, 0);
			this->spr->setFlippedX(false);
		}

		if (state == STATE::WALK && isLand) {
			this->spr->runAction(Sequence::create(DelayTime::create(1.25F),
				CallFunc::create([&]() {
					thisEnemy();
					}), nullptr));
		}
	}
	else if (isEnemyFly)
	{
		//direction = (randomDir == 1) ? Vec2(0, -1) : Vec2(0, 1);
		if (randomDir == 1) direction = Vec2(0, -1);
		else if (randomDir == 2) direction = Vec2(0, 1);
	}
	this->setPosition(this->getPosition() + direction);
}

void Enemy::attack(const char* spriteFrame, int countFrame, float speedAnimation)
{
	this->spr->setColor(Color3B::WHITE);
	if (playerDir == 1) this->spr->setFlippedX(true);
	else if (playerDir == 2) this->spr->setFlippedX(false);

	isLand = false;
	spr->stopAllActions();
	spr->runAction(Sequence::create(CreateAnimation(spriteFrame, countFrame, speedAnimation),
		DelayTime::create(1),
		CallFunc::create([&]() {
			canAttack = false;
			isLand = true;
			thisEnemy();
			}), nullptr));
}

void Enemy::thisEnemy()
{
	if (isEnemy == 1) { // skeleton
		this->spr->stopAllActions();
		this->spr->runAction(CreateAnimation("walk-ED1 (%d).png", 6, .25F));
	}
	else if (isEnemy == 2) { // LothricKnight
		this->spr->stopAllActions();
		this->spr->runAction(CreateAnimation("LothricKnight_walk (%d).png", 6, .25F));
	}
	else if (isEnemy == 3) { // bubble
		/*this->spr->stopAllActions();
		this->spr->runAction(CreateAnimation("sl_walk (%d).png", 4, .075F));*/
	}
}
// enemy
void Enemy::takeDamge(int& damage, int& hp, ProgressTimer* barHP, Sprite* spr, Sprite* bgBar, const char* spriteFrame, int countFarm, int posDeadAnimation, int& currenexp, int& exp)
{
	hp -= damage;
	barHP->setPercentage(hp);
	blood();

	FShake* shake = FShake::create(.075F, 30);
	Camera::getDefaultCamera()->runAction(shake);

	if (hp <= 0) {
		this->setName("remove");
		currenexp += exp;
		dead(spr, bgBar, spriteFrame, countFarm, posDeadAnimation);
	}
}
// boss
void Enemy::takeDamge(int& damage, int& hp, const char* nameBoss, Sprite* spr, const char* spriteFrame, int countFarm)
{
	hp -= damage;
	DataEvent* data = new DataEvent();
	data->hp = hp;
	EventCustom event(nameBoss);
	event.setUserData(data);
	_eventDispatcher->dispatchEvent(&event);

	blood();

	/*spr->setColor(Color3B::RED);
	spr->runAction(Sequence::create(DelayTime::create(0.25F),
		CallFunc::create([&]() {
			this->spr->setColor(Color3B::WHITE);
			}), nullptr));*/

	if (hp <= 0)  deadBoss(spriteFrame, countFarm, spr);
}
// enemy
void Enemy::dead(Sprite* spr, Sprite* bgBar, const char* spriteFrame, int countFarm, int posDeadAnimation)
{
	this->spr->setColor(Color3B::WHITE);
	bgBar->removeFromParent();
	getPhysicsBody()->removeFromWorld();
	spr->setAnchorPoint(Vec2(0.5F, 0));
	spr->setPositionY(spr->getPositionY() - posDeadAnimation);

	spr->stopAllActions();
	spr->runAction(Sequence::create(
		CreateAnimation(spriteFrame, countFarm, SPEED_ANIMATION_ENEMY),
		DelayTime::create(1),
		CallFunc::create([&]() {
			this->removeFromParent();
			}), nullptr));
}
//boss
void Enemy::deadBoss(const char* spriteFrame, int countFarm, Sprite* spriteEnemy)
{
	this->faceBoss += 1;
	this->state = STATE::DEAD;
	this->setName("Dead");
	this->bodyWeapon->removeFromWorld();
	getPhysicsBody()->removeFromWorld();

	spriteEnemy->setAnchorPoint(Vec2(0.5F, .525F));
	spriteEnemy->stopAllActions();
	spriteEnemy->runAction(Sequence::create(
		CreateAnimation(spriteFrame, countFarm, 0.25F),
		DelayTime::create(3), nullptr));

}

void Enemy::blood() {
	this->sprBlood->setVisible(true);
	sprBlood->runAction(Sequence::create(
		CreateAnimation("effectBlood_0%d.png", 7, .075f),
		CallFunc::create([&]() {
			this->sprBlood->setVisible(false);
			}), nullptr));
}


