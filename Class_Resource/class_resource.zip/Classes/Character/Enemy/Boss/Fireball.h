#ifndef __FIREBALL_H__
#define __FIREBALL_H__

#include "cocos2d.h"
#include "Unit.h"

class Fireball : public Unit
{
public:
	virtual bool init();
	static Fireball* create(string);
	Node* node;
	float x, y;
	bool isLeft;
	PhysicsBody* boydShoot;
	float randomSpeed;
	void update(float);
	void attributesData();
	CREATE_FUNC(Fireball);
};

#endif // __SHOOT_H__
