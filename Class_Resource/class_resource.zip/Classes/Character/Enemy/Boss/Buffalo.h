#ifndef __BUFALO_H__
#define __BUFALO_H__

#include "cocos2d.h"
#include "Character/Enemy/Enemy.h"
#include "Character/Enemy/Boss/Fireball.h"

class Buffalo : public Enemy
{
public:
	static Buffalo* create(std::string);
	virtual bool init();

	Node* node;
	Fireball* fireball;

	int updateDamage = 0;
	bool isLookLeft;
	int defaulHP;
	float distanceAttack = 1000;
	float speedDistanceAttack = 1.5f;

	void Respon();
	void attackA();
	void attackB();
	virtual void AI();
	void ShootFireball();
	void checkPositionPlayer();
	virtual void attributesData();

	CREATE_FUNC(Buffalo);
};

#endif // __BUFALO_H__
