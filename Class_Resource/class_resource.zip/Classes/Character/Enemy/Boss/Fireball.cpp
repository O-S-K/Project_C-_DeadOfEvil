#include "Fireball.h"
#include "SimpleAudioEngine.h"
#include "Definetion.h"

USING_NS_CC;

using namespace std;

Fireball* Fireball::create(string str)
{
	auto object = Fireball::create();
	object->spr = Sprite::create(str);
	object->spr->setPositionX(object->spr->getContentSize().width / 2.5f);
	object->addChild(object->spr, 5);
	object->attributesData();
	return object;
}

bool Fireball::init()
{
	if (!Node::init()) return false;
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/Shoot/Fireball.plist");
	damage = 10;

	this->setTag(SET_TAG_FIREBALL);
	this->setName("Setup");
	return true;
}

void Fireball::attributesData()
{
	spr->runAction(RepeatForever::create(CreateAnimation("Fireball (%d).png", 6, 0.1f)));
	auto size = spr->getContentSize();
	auto sizeBody = Size(size.width / 3.5F, size.height);
	boydShoot = PhysicsBody::createBox(sizeBody);
	boydShoot->setCollisionBitmask(FIREBALL_COLLISION_BITMASK);
	boydShoot->setContactTestBitmask(true);
	boydShoot->setDynamic(false);
	setPhysicsBody(boydShoot);
}

void Fireball::update(float dt)
{
	randomSpeed = random(2, 4);
	if (isLeft) x = this->getPosition().x - randomSpeed;
	else x = this->getPosition().x + randomSpeed;
	y = this->getPosition().y;
	this->setPosition(Vec2(x, y));
}