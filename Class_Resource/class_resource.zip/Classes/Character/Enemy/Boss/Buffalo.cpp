#include "Definetion.h"
#include "SimpleAudioEngine.h"
#include "Character/Enemy/Boss/Buffalo.h"
#include "Scene/FShake.h"

USING_NS_CC;

Buffalo* Buffalo::create(string str)
{
	auto object = Buffalo::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 5);

	object->sprBlood = Sprite::create();
	object->addChild(object->sprBlood, 10);
	object->attributesData();
	return object;
}
bool Buffalo::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/AttackA/Buffalo_AttackA.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/AttackB/Buffalo_AttackB.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/AttackC/Buffalo_AttackC.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/Dead/Buffalo_Dead.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/Idle/Buffalo_Idle.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/Move/Buffalo_Move.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/Stand/Buffalo_Stand.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/Taunt/Buffalo_Taunt.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/HitA/Buffalo_HitA.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/HitB/Buffalo_HitB.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/Boss/Buffalo/Respon/Buffalo_Respon.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Blood/Blood.plist");

	exp = 100;
	speed = 1;
	isEnemyMove = true;
	randomDir = random(1, 2);

	return true;
}

void Buffalo::Respon()
{
	speed = 2.5F;
	updateDamage = 5;
	state = STATE::IDLE;
	speedDistanceAttack = 2;

	this->spr->stopAllActions();
	this->spr->runAction(Sequence::create(DelayTime::create(1),
		CreateAnimation("buffalo_Respon (%d).png", 6, 0.75f),
		DelayTime::create(1),
		CreateAnimation("Stand (%d).png", 6, 0.2f), DelayTime::create(1.1F),
		CallFunc::create([&]() {
			attributesData();
			state = STATE::WALK;
			this->spr->setColor(Color3B::RED);
			this->spr->runAction(CreateAnimation("Buffalo_Move (%d).png", 8, 0.1F));
			}), nullptr));
}

void Buffalo::attributesData()
{
	FShake* shake = FShake::create(1000, 3);
	Camera::getDefaultCamera()->runAction(shake);

	this->hp = 2000;
	this->defaulHP = hp;

	DataEvent* data = new DataEvent();
	data->hp = hp;
	EventCustom event("TakeDamgeHPBossBuffalo");
	event.setUserData(data);
	_eventDispatcher->dispatchEvent(&event);

	this->setTag(SET_TAG_BUFFALO);

	auto size = spr->getContentSize();
	auto sizeBody = Size(size.width / 3, size.height / 2.5F);
	auto enemyBody = PhysicsBody::createBox(sizeBody);

	enemyBody->setRotationEnable(false);
	enemyBody->setCollisionBitmask(BUFFALO_COLLISION_BITMASK);
	enemyBody->setCategoryBitmask(BUFFALO_CATEGORY_BITTMASK);
	enemyBody->setContactTestBitmask(BUFFALO_COLLISION_BITMASK);
	enemyBody->setPositionOffset(Vec2(0, 2));
	this->setPhysicsBody(enemyBody);
}

void Buffalo::attackA()
{
	if (state == STATE::ATTACK && state != STATE::DEAD) 
	{
		direction = Vec2(0, 0);
		this->damage = 10 + updateDamage;
		canAttack = false;

		node = Node::create();
		this->addChild(node);

		bodyWeapon = PhysicsBody::createBox(Size(20, 47));
		bodyWeapon->setRotationEnable(false);
		bodyWeapon->setDynamic(false);
		bodyWeapon->setCollisionBitmask(WEPON_BUFFALO_COLLISION_BITTMASK);
		bodyWeapon->setCategoryBitmask(WEPON_BUFFALO_CATEGORY_BITTMASK);
		bodyWeapon->setContactTestBitmask(WEPON_BUFFALO_COLLISION_BITTMASK);
		node->setTag(SET_TAG_WEAPON_BUFFALO);

		if (isLookLeft)  bodyWeapon->setPositionOffset(Vec2(100, 0));
		if (!isLookLeft) bodyWeapon->setPositionOffset(Vec2(-100, 0));
		node->setPhysicsBody(bodyWeapon);

		float randomAttack = random(0.75F, 1.5F);
		spr->stopAllActions();
		spr->runAction(Sequence::create(CreateAnimation("Buffalo_AttackA (%d).png", 9, .125F),
			CallFunc::create([&]() {
				bodyWeapon->removeFromWorld();
				}), DelayTime::create(randomAttack),
					CallFunc::create([&]() {
					canAttack = true;
					state = STATE::WALK;
					this->spr->runAction(CreateAnimation("Buffalo_Move (%d).png", 8, 0.1F));
						}), nullptr));
	}
}

void Buffalo::attackB()
{
	if (state == STATE::ATTACK && state != STATE::DEAD) 
	{
		direction = Vec2(0, 0);
		canAttack = false;
		this->damage = 15 + updateDamage;
		node = Node::create();
		this->addChild(node);

		bodyWeapon = PhysicsBody::createBox(Size(75, 10));
		bodyWeapon->setRotationEnable(false);
		bodyWeapon->setDynamic(false);
		bodyWeapon->setCollisionBitmask(WEPON_BUFFALO_COLLISION_BITTMASK);
		bodyWeapon->setCategoryBitmask(WEPON_BUFFALO_CATEGORY_BITTMASK);
		bodyWeapon->setContactTestBitmask(WEPON_BUFFALO_COLLISION_BITTMASK);
		bodyWeapon->setPositionOffset(Vec2(0, -50));

		node->setTag(SET_TAG_WEAPON_BUFFALO);
		node->setPhysicsBody(bodyWeapon);

		float randomAttack = random(1.5F, 2.5F);
		spr->stopAllActions();
		spr->runAction(Sequence::create(CreateAnimation("Buffalo_AttackC (%d).png", 9, .1F),
			CallFunc::create([&]() {
				bodyWeapon->removeFromWorld();
				}), DelayTime::create(randomAttack),
					CallFunc::create([&]() {
					canAttack = true;
					state = STATE::WALK;
					this->spr->runAction(CreateAnimation("Buffalo_Move (%d).png", 8, 0.1F));
						}), nullptr));
	}
}

void Buffalo::AI()
{
	if (state != STATE::DEAD && state != STATE::ATTACK)
	{
		this->spr->runAction(Sequence::create(DelayTime::create(0.8F),
			CallFunc::create([&]() {
				if (!this->isDead) {
					canAttack = true;
					this->spr->stopAllActions();
					this->spr->runAction(CreateAnimation("Buffalo_Move (%d).png", 8, 0.1F));
				}
				}), nullptr));
	}
}
