#include "Winzard.h"
#include "Definetion.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;


Winzard* Winzard::create(string str)
{
	auto object = Winzard::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 5);
	object->spr->setFlippedX(true);

	object->sprBlood = Sprite::create();
	object->addChild(object->sprBlood, 10);
	object->attributesData();
	return object;
}

bool Winzard::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyFly/Winzard/Shoot/winzard-shoot.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyFly/Winzard/Dead/wizard-death.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyFly/Winzard/Idle/winzard_Idle.plist");


	exp = 50;
	hp = 75; 
	this->setTag(SET_TAG_ENEMY_WINZARD);

	_bgHPBar = Sprite::create("Sprites/UI/StatusBar/Enemy/bg-bar.png");
	_bgHPBar->setPosition(this->getPosition().x, this->getPosition().y + 50);
	this->addChild(_bgHPBar, 5);

	barHP = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Enemy/hp-Bar.png"));
	barHP->setType(kCCProgressTimerTypeBar);
	barHP->setMidpoint(ccp(0, 0));
	barHP->setBarChangeRate(ccp(1, 0));
	barHP->setPercentage(hp + 25);
	barHP->setPosition(Size(this->getPosition().x, this->getPosition().y + 50));
	addChild(barHP, 5);

	return true;
}

void Winzard::attributesData()
{
	auto enemyBody = PhysicsBody::createBox(spr->getContentSize());
	enemyBody->setRotationEnable(false);
	enemyBody->setCollisionBitmask(ENEMY_WINZARD_COLLISION_BITMASK);
	enemyBody->setCategoryBitmask(ENEMY_WINZARD_CATEGORY_BITTMASK);
	enemyBody->setContactTestBitmask(ENEMY_WINZARD_COLLISION_BITMASK);
	setPhysicsBody(enemyBody);
}

