﻿#ifndef __BATENEMY_H__
#define __BATENEMY_H__

#include "cocos2d.h"
#include"Character/Enemy/Enemy.h"

class BatEnemy : public Enemy
{
public:
	static BatEnemy* create(std::string);
	virtual bool init();

	float maxUp;
	float maxDown;
	
	virtual void attributesData();
	void AI();
	CREATE_FUNC(BatEnemy);
   
};

#endif // __BATENEMY_H__
