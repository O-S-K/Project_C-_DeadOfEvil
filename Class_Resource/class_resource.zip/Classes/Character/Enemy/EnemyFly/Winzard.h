﻿#ifndef __WINZARD_H__
#define __WINZARD_H__

#include "cocos2d.h"
#include"Character/Enemy/Enemy.h"

class Winzard : public Enemy
{
public:
	static Winzard* create(std::string);
	float distanceShoot = 100;
	virtual bool init();
	virtual void attributesData();
	CREATE_FUNC(Winzard);
};

#endif // __WINZARD_H__
