#ifndef __ENEMY_H__
#define __ENEMY_H__

#include "cocos2d.h"
#include "Unit.h"

USING_NS_CC;

class Enemy : public Unit
{
public:

	STATE state;

	float moveForce;
	float delayAttack;
	int randomDir;
	int playerDir;

	Sprite* _bgHPBar;
	Sprite* _hpBar;
	ProgressTimer* barHP;

	bool isEnemyMove = false;
	bool isEnemyFly = false;

	bool isCollision = false;
	bool isRunAnimation = true;

	void attributesData();
	void AI();
	void blood();
	
	void thisEnemy();

	virtual void move();
	virtual void attack(const char* spriteFrame, int countFrame, float speedAnimation);
	virtual void dead(Sprite* player, Sprite* bgBar, const char* spriteFrame, int countFame, int posDead);
	void deadBoss(const char* spriteFrame, int countFarm, Sprite* spriteEnemy);
	virtual void takeDamge(int& damage, int& hp, ProgressTimer* barHP, Sprite* spr, Sprite* bgBar, const char* spriteFrame, int countFarm, int posDeadAnimation,int& currenexp,int& exp);
	virtual void takeDamge(int& damage, int& hp, const char* nameBoss, Sprite* spr, const char* spriteFrame, int countFarm);
};

#endif // __ENEMY_H__
