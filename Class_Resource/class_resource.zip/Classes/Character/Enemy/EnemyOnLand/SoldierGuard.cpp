#include "SimpleAudioEngine.h"
#include "Definetion.h"
#include "ui/CocosGUI.h"
#include "Character/Enemy/EnemyOnLand/SoldierGuard.h"


USING_NS_CC;

SoldierGuard* SoldierGuard::create(string str)
{
	auto object = SoldierGuard::create();
	object->spr = Sprite::create(str);
	object->spr->setAnchorPoint(Vec2(0.5F, 0));
	auto size = object->spr->getContentSize();
	object->spr->setPositionY(-size.height / 2);
	object->spr->setFlippedX(true);
	object->addChild(object->spr, 5);

	object->sprBlood = Sprite::create();
	object->addChild(object->sprBlood, 10);
	object->attributesData();
	return object;
}

bool SoldierGuard::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/SoldierGuard/Idle/soldierguard_idle.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/SoldierGuard/AttackA/soldierguard_attack.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/SoldierGuard/Dead/soldierguard_dead.plist");
	
	exp = 45;
	hp = 85;
	damage = 25;
	isEnemyMove = true;

	this->setScaleX(-1);
	this->setTag(SET_TAG_ENEMY_SOLDIERGUARD);

	_bgHPBar = Sprite::create("Sprites/UI/StatusBar/Enemy/bg-bar.png");
	_bgHPBar->setPosition(this->getPosition().x, this->getPosition().y + 50);
	this->addChild(_bgHPBar, 5);

	barHP = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Enemy/hp-Bar.png"));
	barHP->setType(kCCProgressTimerTypeBar);
	barHP->setMidpoint(ccp(0, 0));
	barHP->setBarChangeRate(ccp(1, 0));
	barHP->setPercentage(hp + 15);
	barHP->setPosition(Size(this->getPosition().x, this->getPosition().y + 50));
	addChild(barHP, 5);

	return true;
}

void SoldierGuard::attributesData()
{
	auto enemyBody = PhysicsBody::createBox(spr->getContentSize());
	enemyBody->setRotationEnable(false);
	enemyBody->setCollisionBitmask(ENEMY_SOLDIERGUARD_COLLISION_BITMASK);
	enemyBody->setCategoryBitmask(ENEMY_SOLDIERGUARD_CATEGORY_BITTMASK);
	enemyBody->setContactTestBitmask(ENEMY_SOLDIERGUARD_COLLISION_BITMASK);
	setPhysicsBody(enemyBody);
}

void SoldierGuard::AI()
{
	if (isLand && state != STATE::DEAD)
	{
		state == STATE::WALK;
		move();
	}
}

