#ifndef __DULLNESSSHOOT_H__
#define __DULLNESSSHOOT_H__

#include "cocos2d.h"
#include "Character/Enemy/Enemy.h"
#include "Character/DataArchery.h"

using namespace cocos2d;
class DullnessShoot : public Enemy
{
public:

	DataArchery* data;
	static DullnessShoot* create(std::string);
	virtual bool init();
	virtual void attributesData();
	CREATE_FUNC(DullnessShoot);
};

#endif // __DULLNESSSHOOT_H__
