#include "SimpleAudioEngine.h"
#include "Definetion.h"
#include "ui/CocosGUI.h"
#include "Character/Enemy/EnemyOnLand/LothricKnight.h"


USING_NS_CC;

LothricKnight* LothricKnight::create(string str)
{
	auto object = LothricKnight::create();
	object->spr = Sprite::create(str);
	object->spr->setAnchorPoint(Vec2(0.5F, 0));
	auto size = object->spr->getContentSize();
	object->spr->setPositionY(-size.height / 2);
	object->addChild(object->spr, 5);

	object->sprBlood = Sprite::create();
	object->addChild(object->sprBlood, 10);
	object->attributesData();
	return object;
}

bool LothricKnight::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/LothricKnight/Idle/LothricKnight_idle.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/LothricKnight/AttackB/LothricKnight_attackB.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/LothricKnight/Walk/LothricKnight_walk.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/LothricKnight/Dead/LothricKnight_dead.plist");
	
	exp = 50;
	hp = 150;
	damage = 15;
	isEnemyMove = true;
	randomDir = random(1, 2);
	this->setTag(SET_TAG_ENEMY_LOTHRICKNIGHT);

	_bgHPBar = Sprite::create("Sprites/UI/StatusBar/Enemy/bg-bar.png");
	_bgHPBar->setPosition(this->getPosition().x, this->getPosition().y + 50);
	this->addChild(_bgHPBar, 5);

	barHP = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Enemy/hp-Bar.png"));
	barHP->setType(kCCProgressTimerTypeBar);
	barHP->setMidpoint(ccp(0, 0));
	barHP->setBarChangeRate(ccp(1, 0));
	barHP->setPercentage(hp - 50);
	barHP->setPosition(Size(this->getPosition().x, this->getPosition().y + 50));
	addChild(barHP, 5);

	return true;
}

void LothricKnight::attributesData()
{
	auto enemyBody = PhysicsBody::createBox(spr->getContentSize());
	enemyBody->setRotationEnable(false);
	enemyBody->setCollisionBitmask(ENEMY_LOTHRICKNIGHT_COLLISION_BITMASK);
	enemyBody->setCategoryBitmask(ENEMY_LOTHRICKNIGHT_CATEGORY_BITTMASK);
	enemyBody->setContactTestBitmask(ENEMY_LOTHRICKNIGHT_COLLISION_BITMASK);
	setPhysicsBody(enemyBody);
}

void LothricKnight::AI()
{
	if (isLand && state != STATE::DEAD)
	{
		isEnemy = 2;
		state == STATE::WALK;
		move();
	}
}
