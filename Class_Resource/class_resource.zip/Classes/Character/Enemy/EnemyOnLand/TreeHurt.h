#ifndef __TREEHURT_H__
#define __TREEHURT_H__

#include "cocos2d.h"
#include "Character/Enemy/Enemy.h"

class TreeHurt : public Enemy
{
public:
	static TreeHurt* create(std::string);
	virtual bool init();
	virtual void attributesData();
    CREATE_FUNC(TreeHurt);
};

#endif // __TREEHURT_H__
