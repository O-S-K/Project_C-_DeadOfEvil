#include "BubbleEnemy.h"
#include "Definetion.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;


BubbleEnemy* BubbleEnemy::create(string str)
{
	auto object = BubbleEnemy::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 5);

	object->sprBlood = Sprite::create();
	object->addChild(object->sprBlood, 10);
	object->attributesData();
	return object;
}

bool BubbleEnemy::init()
{
	if (!Node::init()) return false;

	/*SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnLand/Bubble/Dead/bb_Dead.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnLand/Bubble/Walk/BB_Walk.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnLand/Bubble/Attack/bb_attack.plist");*/


	/*SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnLand/Slime/Dead/SL_Dead.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnLand/Slime/Walk/SL_Walk.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnLand/Slime/Attack/SL_Attack.plist");*/

	/*exp = 15;
	hp = 100;*/
	damage = 20;
	isEnemyMove = true;
	randomDir = random(1, 2);

	this->setTag(SET_TAG_ENEMY_BUBBLE);

	/*_bgHPBar = Sprite::create("Sprites/UI/StatusBar/Enemy/bg-bar.png");
	_bgHPBar->setPosition(this->getPosition().x, this->getPosition().y + 30);
	this->addChild(_bgHPBar, 5);

	barHP = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Enemy/hp-Bar.png"));
	barHP->setType(kCCProgressTimerTypeBar);
	barHP->setMidpoint(ccp(0, 0));
	barHP->setBarChangeRate(ccp(1, 0));
	barHP->setPercentage(hp);
	barHP->setPosition(Size(this->getPosition().x, this->getPosition().y + 30));
	addChild(barHP, 5);*/

	return true;
}

void BubbleEnemy::attributesData()
{
	auto size = Size(spr->getContentSize().width, spr->getContentSize().height / 2);
	auto enemyBody = PhysicsBody::createBox(size);
	enemyBody->setPositionOffset(Vec2(0, -12));
	enemyBody->setRotationEnable(false);
	enemyBody->setCollisionBitmask(ENEMY_BUBBLE_COLLISION_BITMASK);
	enemyBody->setCategoryBitmask(ENEMY_BUBBLE_CATEGORY_BITTMASK);
	enemyBody->setContactTestBitmask(ENEMY_BUBBLE_COLLISION_BITMASK);
	setPhysicsBody(enemyBody);
}

void BubbleEnemy::AI()
{
	if (isLand && state != STATE::DEAD)
	{
		isEnemy = 3;
		state == STATE::WALK;
		move();
	}
}

