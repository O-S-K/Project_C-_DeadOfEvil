#ifndef __SOLDIERGUARD_H__
#define __SOLDIERGUARD_H__

#include "cocos2d.h"
#include "Character/Enemy/Enemy.h"

class SoldierGuard : public Enemy
{
public:

	static SoldierGuard* create(std::string);
	
	virtual bool init();
	virtual void attributesData();
	virtual void AI();
	//virtual void dead();
	CREATE_FUNC(SoldierGuard);
};

#endif // __SOLDIERGUARD_H__
