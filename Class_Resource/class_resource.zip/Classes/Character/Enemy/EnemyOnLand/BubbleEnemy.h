﻿#ifndef __BUBBLEENEMY_H__
#define __BUBBLEENEMY_H__

#include "cocos2d.h"
#include "Character/Enemy/Enemy.h"

class BubbleEnemy : public Enemy
{
public:
	static BubbleEnemy* create(std::string);
	virtual bool init();
	virtual void attributesData();
	virtual void AI();
	CREATE_FUNC(BubbleEnemy);
};

#endif // __BUBBLEENEMY_H__
