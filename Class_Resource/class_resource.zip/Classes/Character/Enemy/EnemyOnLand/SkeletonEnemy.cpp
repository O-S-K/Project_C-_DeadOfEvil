#include "SimpleAudioEngine.h"
#include "Definetion.h"
#include "ui/CocosGUI.h"
#include "Character/Enemy/EnemyOnLand/SkeletonEnemy.h"


USING_NS_CC;

SkeletonEnemy* SkeletonEnemy::create(string str)
{
	auto object = SkeletonEnemy::create();
	object->spr = Sprite::create(str);
	object->spr->setAnchorPoint(Vec2(.5F, .35F));
	object->addChild(object->spr, 5);

	object->sprBlood = Sprite::create();
	object->addChild(object->sprBlood, 10);
	object->attributesData();
	return object;
}

bool SkeletonEnemy::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/Skeleton/Idle/Enemy_idleED1.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/Skeleton/AttackA/Enemy_attackED1.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/Skeleton/AttackB/Enemy_attackBED1.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/Skeleton/Walk/Enemy_walkED1.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/Skeleton/Dead/Enemy_deadED1.plist");

	exp = 40;
	hp = 100;
	damage = 15;
	isEnemyMove = true;
	randomDir = random(1, 2);
	this->setTag(SET_TAG_ENEMY_SKELETON);

	_bgHPBar = Sprite::create("Sprites/UI/StatusBar/Enemy/bg-bar.png");
	_bgHPBar->setPosition(this->getPosition().x, this->getPosition().y + 50);
	this->addChild(_bgHPBar, 5);

	barHP = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Enemy/hp-Bar.png"));
	barHP->setType(kCCProgressTimerTypeBar);
	barHP->setMidpoint(ccp(0, 0));
	barHP->setBarChangeRate(ccp(1, 0));
	barHP->setPercentage(hp);
	barHP->setPosition(Size(this->getPosition().x, this->getPosition().y + 50));
	addChild(barHP, 5);

	return true;
}

void SkeletonEnemy::attributesData()
{
	auto enemyBody = PhysicsBody::createBox(spr->getContentSize());
	enemyBody->setPositionOffset(Vec2(0, -5));
	enemyBody->setRotationEnable(false);
	enemyBody->setCollisionBitmask(ENEMY_SKELETON_COLLISION_BITMASK);
	enemyBody->setCategoryBitmask(ENEMY_SKELETON_CATEGORY_BITTMASK);
	enemyBody->setContactTestBitmask(ENEMY_SKELETON_COLLISION_BITMASK);
	setPhysicsBody(enemyBody);
}
void SkeletonEnemy::AI()
{
	if (isLand && state != STATE::DEAD)
	{
		isEnemy = 1;
		state == STATE::WALK;
		move();
	}
}
