#include "SimpleAudioEngine.h"
#include "Definetion.h"
#include "Character/Enemy/EnemyOnLand/DullnessShoot.h"

USING_NS_CC;


DullnessShoot* DullnessShoot::create(string str)
{
	auto object = DullnessShoot::create();
	object->spr = Sprite::create(str);
	object->addChild(object->spr, 5);
	object->spr->setFlippedX(true);
	object->sprBlood = Sprite::create();
	object->addChild(object->sprBlood, 10);
	object->attributesData();
	return object;
}

bool DullnessShoot::init()
{
	if (!Node::init()) return false;

	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/DullnessShoot/idle/Idle.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/DullnessShoot/attackA/Attack.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/DullnessShoot/attackB/AttackB.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Sprites/Gameplay/Enemy/EnemyOnland/DullnessShoot/dead/Dead.plist");

	exp = 35;
	hp = 70; 

	this->setTag(SET_TAG_ENEMY_SHOOT);

	_bgHPBar = Sprite::create("Sprites/UI/StatusBar/Enemy/bg-bar.png");
	_bgHPBar->setPosition(this->getPosition().x, this->getPosition().y + 50);
	this->addChild(_bgHPBar, 5);

	barHP = ProgressTimer::create(Sprite::create("Sprites/UI/StatusBar/Enemy/hp-Bar.png"));
	barHP->setType(kCCProgressTimerTypeBar);
	barHP->setMidpoint(ccp(0, 0));
	barHP->setBarChangeRate(ccp(1, 0));
	barHP->setPercentage(hp + 30);
	barHP->setPosition(Size(this->getPosition().x, this->getPosition().y + 50));
	addChild(barHP, 5);

	return true;
}

void DullnessShoot::attributesData()
{
	auto enemyBody = PhysicsBody::createBox(spr->getContentSize());
	enemyBody->setRotationEnable(false);
	enemyBody->setCollisionBitmask(ENEMY_DULLNESSSHOOT_COLLISION_BITMASK);
	enemyBody->setCategoryBitmask(ENEMY_DULLNESSSHOOT_CATEGORY_BITTMASK);
	enemyBody->setContactTestBitmask(ENEMY_DULLNESSSHOOT_COLLISION_BITMASK);
	setPhysicsBody(enemyBody);
}

