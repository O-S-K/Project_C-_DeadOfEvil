#ifndef __SKELETONENEMY_H__
#define __SKELETONENEMY_H__

#include "cocos2d.h"
#include "Character/Enemy/Enemy.h"

class SkeletonEnemy : public Enemy
{
public:
	static SkeletonEnemy* create(std::string);
	
	virtual bool init();
	virtual void attributesData();
	virtual void AI();
	//virtual void dead();

	CREATE_FUNC(SkeletonEnemy);
};

#endif // __SKELETONENEMY_H__
