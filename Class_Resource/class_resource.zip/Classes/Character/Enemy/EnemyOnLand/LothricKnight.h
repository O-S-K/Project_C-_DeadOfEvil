#ifndef __LOTHRICKNIGHT_H__
#define __LOTHRICKNIGHT_H__

#include "cocos2d.h"
#include "Character/Enemy/Enemy.h"

class LothricKnight : public Enemy
{
public:
	static LothricKnight* create(std::string);
	
	virtual bool init();
	virtual void attributesData();
	virtual void AI();

	CREATE_FUNC(LothricKnight);
};

#endif // __LOTHRICKNIGHT_H__
