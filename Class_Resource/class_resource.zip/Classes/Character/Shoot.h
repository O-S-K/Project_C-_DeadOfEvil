#ifndef __SHOOT_H__
#define __SHOOT_H__

#include "cocos2d.h"
#include "Unit.h"

class Shoot : public Unit
{
public:
	virtual bool init();
	static Shoot* create(string,Vec2,Vec2,Size);
	Node* node;
	Vec2 positionShoot;
	Vec2 positionPlayer;
	Size rangeShoot;
	float x, y, xE, yE, total;

	void checkPlayer(Vec2,Vec2,Size);
	void update(float);
	void attributesData();
	CREATE_FUNC(Shoot);
};

#endif // __SHOOT_H__
