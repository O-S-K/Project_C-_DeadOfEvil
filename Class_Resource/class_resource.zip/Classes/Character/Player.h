#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "cocos2d.h"
#include "Unit.h"
#include "Definetion.h"
#include "Scene/GameOver.h"
#include "SimpleAudioEngine.h"

using namespace std;
using namespace cocos2d;

class Player : public Unit
{
public:
	static Player* create(string);

	virtual bool init();
	Size visibleSize;
	Node* node;

	STATE state;
	Size defaultSize;
	PhysicsBody* playerBody;
	PhysicsBody* bodyWeapon;
	PhysicsBody* bodyShield;
	EventListenerKeyboard* keyboardEvent;
	ParticleSystemQuad* smokeParticle;
	CocosDenshion::SimpleAudioEngine* audioFX;

	DataEvent* touchLeft;
	DataEvent* touchRight;

	float mp;
	float delayMp = 0;
	int countItemHp = 0;
	int moveDirection = 0;
	float moveForce;
	float timeJump = 0;
	float heightJump = 0;
	float yP;

	int level;
	int totalExp;
	int currentExp;

	bool canSplash;
	bool canJump;
	bool isLookLeft;
	bool isMove = true;
	bool isClimb = false;
	bool playSound;

	float left;
	float right;
	float top;
	float bot;

	int GetLeft();
	int GetRight();
	int GetTop();
	int GetBot();

	void update(float);
	void attributesData();

	void receiveEvent();
	void GetUserData();


	void TouchMoveLeft(EventCustom* moveLeft);
	void TouchMoveRight(EventCustom* moveRight);
	void TouchEndMove(EventCustom* eventEnd);
	void TouchAttack(EventCustom* attack);
	void TouchJump(EventCustom* jump);
	void TouchSplash(EventCustom* splash);
	void EndMove(EventCustom* end);
	void TouchRecHP(EventCustom* recHP);

	void onKeyUp(EventKeyboard::KeyCode keyCode, Event* e);
	void onKeyDown(EventKeyboard::KeyCode keyCode, Event* e);

	void caseState();
	void jump();
	void splash();
	void recuperateHP();
	void recuperateMP(float dt);
	void upLevel();
	//void updateLevel();

	virtual void move();
	virtual void attack();
	virtual void dead();
	virtual void shield();
	virtual void takeDamge(int);

	CREATE_FUNC(Player);
};

#endif // __PLAYER_H__

