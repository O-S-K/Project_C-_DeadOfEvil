﻿#ifndef __LOGIC_H__
#define __LOGIC_H__

#include "cocos2d.h"
#include "Character/Player.h"
#include "Character/Archery.h"
#include "Object/Obstancle/Traps.h"
#include "Character/Enemy/EnemyFly/Winzard.h"
#include "Character/Enemy/EnemyFly/BatEnemy.h"
#include "Character/Enemy/EnemyOnLand/TreeHurt.h"
#include "Character/Enemy/EnemyOnLand/BubbleEnemy.h"
#include "Character/Enemy/EnemyOnLand/DullnessShoot.h"
#include "Character/Enemy/EnemyOnLand/SkeletonEnemy.h"
#include "Character/Enemy/EnemyOnLand/LothricKnight.h"
#include "Character/Enemy/EnemyOnLand/SoldierGuard.h"
#include "Character/Enemy/Boss/Buffalo.h"
#include "Character/Enemy/Boss/Fireball.h"
#include "Character/Shoot.h"
#include "Object/Door.h"
#include "Object/Climb.h"
#include "Object/Chest.h"
#include "Object/ItemHP.h"
USING_NS_CC;
class Logic : public cocos2d::Node
{
public:
	Player* player;
	Buffalo* buffalo;

	Vector<Traps*> listTraps;
	Vector<Node*> listTitleMap;
	Vector<Archery*> listArchery;
	Vector<BatEnemy*> listBatEnemy;
	Vector<Winzard*> listEnemyWinzard;
	Vector<TreeHurt*> listEnemyTreeHurt;
	Vector<BubbleEnemy*>  listEnemyBubble;
	Vector<SkeletonEnemy*> listEnemyOnLandMove;
	Vector<DullnessShoot*> listEnemyDullnessShoot;
	Vector<LothricKnight*>   listEnemyLothricKnight;
	Vector<SoldierGuard*>       listEnemySoldierGuard;
	Vector<Fireball*>           listFireball;
	Vector<Shoot*>               listShootWinzard;
	Vector<Climb*>               listClimb;
	Vector<Sprite*>              listCollision;
	Vector<Chest*>               listChest;
	Vector<ItemHP*>               listItemHP;

	float x;
	float y;
	float g;

	float randomeDelayShoot;
	int randomTypeAttack;

	float delayShoot = 0;
	float delayAttack;
	float countAttack;
	float delay;
	float delaycount = 0;

	Vec2 dirPos;
	Size playerSize;
	Vec2 boss;
	Size bossSize;
	Size winzardSize;
	DullnessShoot* EnemyDullness;
	Door* door;
	Size sizeObjectDead;
	Vec2 posObjectDead;
	int countDeadBoss = 0;

	void Move(float);
	void MovePlayer(float);
	void SetPlayerInLand();
	void MoveEnemy(float);
	void MoveBullet();
	void CheckItemHP();

	void ObjectMapCollision();
	void EnemyCollision();
	void PlayerCollison();
	void MoveBossBuffalo();
	void AttackBossBuffalo();
	void DeadBossBuffalo();
	bool checkStatePlayer();

	CREATE_FUNC(Logic);
};

#endif // __LOGIC_H__

