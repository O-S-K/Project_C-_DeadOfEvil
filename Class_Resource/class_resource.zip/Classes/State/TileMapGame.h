#ifndef __TILEMAPGAME_H__
#define __TILEMAPGAME_H__

#include "cocos2d.h"
#include "Logic.h"

#include "Character/Player.h"
#include "Character/Enemy/EnemyOnLand/DullnessShoot.h"
#include "Character/Enemy/EnemyOnLand/SkeletonEnemy.h"
#include "Character/Enemy/EnemyOnLand/TreeHurt.h"
#include "Character/Enemy/EnemyOnLand/DullnessShoot.h"
#include "Character/Enemy/EnemyOnLand/BubbleEnemy.h"
#include "Character/Enemy/EnemyFly/Winzard.h"
#include "Character/Enemy/EnemyOnLand/LothricKnight.h"
#include "Character/Enemy/EnemyOnLand/SoldierGuard.h"
#include "Character/Enemy/Boss/Buffalo.h"
#include "Character/Enemy/EnemyFly/BatEnemy.h"

#include "Object/Obstancle/Traps.h"
#include "Character/Target.h"
#include "Object/Door.h"
#include "Object/Climb.h"
#include "Object/NPC.h"
#include "Object/Chest.h"


using namespace cocos2d;
using namespace std;

class TileMapGame : public cocos2d::Node
{
public:
	static TileMapGame* createTileMapGame();
	virtual bool init();
	Node* nodebody;

	Logic* logic;
	Player* player;
	BatEnemy* batEnemy;
	TreeHurt* treehurt;
	SkeletonEnemy* skeletonEnemy;
	DullnessShoot* dullnessShoot;
	BubbleEnemy* bubbleEnemy;
	Winzard* winzard;
	LothricKnight* lothricknight;
	SoldierGuard* soldierguard;
	Buffalo* buffalo;

	Door* door;
	Target* target;
	Climb* climb;
	NPC* npc;
	Traps* traps;
	Chest* chest;

	TMXTiledMap* tileMap;
	TMXObjectGroup* objectGroup;

	void CreateTileMap(string);
	void InstantiateMap();
	void GetTileLayer();

	bool GetObjectPlayer();
	bool GetObjectEnemys();
	bool GetObjectObstancle();
	void GetObjectInTileMap();
	void GetObjectBuffalo();


	void GetObjectBlock();
	void GetObjectTarget();
	void GetObjectDoorStart();
	void GetObjectDoorEnd();
	void GetObjectDoorEndGame();
	bool GetObjectClimb();

	CREATE_FUNC(TileMapGame);
};

#endif // __TILEMAPGAME_H__
