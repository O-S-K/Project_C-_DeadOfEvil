﻿#include "TileMapGame.h"
#include "Character/Player.h" 
#include "SimpleAudioEngine.h"
#include "Definetion.h"

USING_NS_CC;

TileMapGame* TileMapGame::createTileMapGame()
{
	return TileMapGame::create();
}

bool TileMapGame::init()
{
	if (!Node::init()) return false;

	logic = new Logic();
	InstantiateMap();

	return true;
}

//  All objects need to spawn with the map
void TileMapGame::InstantiateMap() {
	// index save by UserDdefault
	auto index = UserDefault::sharedUserDefault()->getIntegerForKey("IndexMap");
	CreateTileMap(StringUtils::format("Sprites/DataTileMap/Map %d.tmx", index));
	GetObjectInTileMap();
}

void TileMapGame::CreateTileMap(string mapname) {
	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto nodeMap = Node::create();

	tileMap = TMXTiledMap::create(mapname);
	auto size = tileMap->getContentSize();
	Vec2 tileMapScale = Vec2(visibleSize.width / size.width, visibleSize.height / size.height);
	//tileMap->setScale(visibleSize.width / size.width * 1.5, visibleSize.height / size.height * 1.5);

	this->addChild(tileMap, 2);
}

void TileMapGame::GetObjectInTileMap() {
	GetTileLayer();
	GetObjectPlayer();
	GetObjectEnemys();
	GetObjectObstancle();
	GetObjectBuffalo();
	GetObjectBlock();
	//GetObjectClimb();
	GetObjectDoorEnd();
	GetObjectDoorEndGame();
	GetObjectTarget();
}
void TileMapGame::GetTileLayer() {

	auto layercollision = tileMap->getLayer("collision");
	if (layercollision == nullptr) {
		log("Not layer Collision Enemy in Tile Map");
		return;
	}
	else {
		layercollision->getLayerSize();
		for (unsigned int i = 0; i < layercollision->getLayerSize().width; i++)
		{
			for (unsigned int j = 0; j < layercollision->getLayerSize().height; j++) {
				auto col = layercollision->getTileAt(Vec2(i, j));
				if (col != NULL)
				{
					//add body to tile map
					auto NodePhysicCol = PhysicsBody::createBox(col->getContentSize());
					NodePhysicCol->setCollisionBitmask(OBJECT_TITLE_MAP_COLLITION);
					NodePhysicCol->setContactTestBitmask(OBJECT_TITLE_MAP_COLLITION);
					NodePhysicCol->setDynamic(false);
					col->setTag(SET_TAG_OBJECT_MAP);
					col->setPhysicsBody(NodePhysicCol);
					logic->listCollision.pushBack(col);
				}
			}
		}
	}
}
void TileMapGame::GetObjectBlock()
{
	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectBlock");
	if (objects == NULL) return;
	else
	{
		auto blockShowUpPoint = objects->getObjects();
		for (int i = 0; i < blockShowUpPoint.size(); i++)
		{
			auto block = blockShowUpPoint.at(i).asValueMap();
			if (block["name"].asString() == "block")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;
				float xE = blockShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yE = blockShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vece = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;

				auto nodebody = Node::create();
				nodebody->setContentSize(Size(block["width"].asFloat(), block["height"].asFloat()));
				auto NodePhysicCol = PhysicsBody::createBox(nodebody->getContentSize());

				NodePhysicCol->setCollisionBitmask(TITLEMAP_GROUND_COLLISION_BITTMASK);
				NodePhysicCol->setContactTestBitmask(TITLEMAP_GROUND_COLLISION_BITTMASK);
				NodePhysicCol->setDynamic(false);
				nodebody->setPosition(vece);
				nodebody->setTag(SET_TAG_TILEMAP_GROUND);
				nodebody->setPhysicsBody(NodePhysicCol);
				this->addChild(nodebody, 1);
				logic->listTitleMap.pushBack(nodebody);
			}

			else if (block["name"].asString() == "blockmapboss")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;
				float xE = blockShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yE = blockShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vece = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;

				auto nodebody = Node::create();
				nodebody->setContentSize(Size(block["width"].asFloat(), block["height"].asFloat()));
				auto NodePhysicCol = PhysicsBody::createBox(nodebody->getContentSize());

				NodePhysicCol->setCollisionBitmask(TITLEMAP_GROUND_COLLISION_BITTMASK);
				NodePhysicCol->setContactTestBitmask(TITLEMAP_GROUND_COLLISION_BITTMASK);
				NodePhysicCol->setDynamic(false);
				nodebody->setPosition(vece);
				nodebody->setTag(SET_TAG_TILEMAP_GROUND);
				nodebody->setPhysicsBody(NodePhysicCol);
				this->addChild(nodebody);
				logic->listTitleMap.pushBack(nodebody);
			}
			else if (block["name"].asString() == "door")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;
				float xD = blockShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yD = blockShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vece = convertToNodeSpaceAR(Vec2(xD, yD)) / diffy;

				nodebody = Node::create();
				nodebody->setContentSize(Size(block["width"].asFloat(), block["height"].asFloat()));
				nodebody->setPosition(vece);
				this->addChild(nodebody);
				logic->listTitleMap.pushBack(nodebody);

				door = Door::createSprDoorEndGame("Sprites/Door/doorEnd (1).png");
				door->setPosition(nodebody->getPosition());
				this->addChild(door);

			}
		}
	}
}
bool TileMapGame::GetObjectPlayer()
{
	auto visibleSize = Director::getInstance()->getVisibleSize();
	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");
	if (objects == NULL) return false;
	else
	{
		auto playerShowUpPoint = objects->getObject("SpawnPlayer");

		float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
		float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

		float xP = playerShowUpPoint["x"].asDouble() * diffx;
		float yP = playerShowUpPoint["y"].asDouble() * diffy;
		auto  vecP = convertToNodeSpaceAR(Vec2(xP, yP)) / diffx;

		player = Player::create("Sprites/Gameplay/Player/Idle/PlayerIdle (1).png");
		auto size = player->spr->getContentSize();
		player->setScale(visibleSize.width / size.width * .025F, visibleSize.height / size.height * .065F);
		player->setPosition(vecP);
		player->spr->runAction(RepeatForever::create(player->Unit::CreateAnimation("PlayerIdle (%d).png", 11, .1F)));
		this->addChild(player, 7);
	}
	return true;
}
bool TileMapGame::GetObjectEnemys()
{
#pragma region Skeleton
	auto visibleSize = Director::getInstance()->getVisibleSize();
	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");

	if (objects == NULL) return false;
	else
	{
		auto enemyShowUpPoint = objects->getObjects();
		for (int i = 0; i < enemyShowUpPoint.size(); i++)
		{
			auto bien = enemyShowUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnEnemyLandMove")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;
				float xE = enemyShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yE = enemyShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vece = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;

				skeletonEnemy = SkeletonEnemy::create("Sprites/Gameplay/Enemy/EnemyOnland/Skeleton/Idle/idle-ED1 (1).png");
				auto size = skeletonEnemy->spr->getContentSize();
				skeletonEnemy->setScale(visibleSize.width / size.width * .045F, visibleSize.height / size.height * .09F);
				skeletonEnemy->setPosition(vece);
				skeletonEnemy->setName("setup");
				skeletonEnemy->spr->runAction(RepeatForever::create(skeletonEnemy->CreateAnimation("walk-ED1 (%d).png", 6, 0.25F)));
				this->addChild(skeletonEnemy, 4);
				logic->listEnemyOnLandMove.pushBack(skeletonEnemy);
			}
		}
	}
#pragma endregion

#pragma region Enemy_dullnessShoot
	if (objects == NULL) return false;
	else
	{
		auto enemyShowUpPoint = objects->getObjects();
		for (int i = 0; i < enemyShowUpPoint.size(); i++)
		{
			auto bien = enemyShowUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnDullnessShoot")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

				float xE = enemyShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yE = enemyShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vece = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;

				dullnessShoot = DullnessShoot::create("Sprites/Gameplay/Enemy/EnemyOnland/DullnessShoot/idle/idle-1.png");
				auto size = dullnessShoot->spr->getContentSize();
				dullnessShoot->setScale(visibleSize.width / size.width * .03F, visibleSize.height / size.height * .09F);
				dullnessShoot->setPosition(vece);
				dullnessShoot->setName("setup");
				dullnessShoot->spr->runAction(RepeatForever::create(dullnessShoot->Unit::CreateAnimation("idle-%d.png", 2, SPEED_ANIMATION_ENEMY)));
				this->addChild(dullnessShoot, 4);
				logic->listEnemyDullnessShoot.pushBack(dullnessShoot);
			}
		}
	}
#pragma endregion

#pragma region Tilemap_enemy_tree_hurt
	if (objects == NULL) return false;
	else
	{
		auto enemyShowUpPoint = objects->getObjects();
		for (int i = 0; i < enemyShowUpPoint.size(); i++)
		{
			auto bien = enemyShowUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnEnemyTreeHurt")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

				float xE = enemyShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yE = enemyShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vece = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;

				treehurt = TreeHurt::create("Sprites/Gameplay/Enemy/EnemyOnland/TreeHurt/idle/idle_TH (1).png");
				auto size = treehurt->spr->getContentSize();
				treehurt->setScale(visibleSize.width / size.width * .05F, visibleSize.height / size.height * .025F);
				treehurt->setPosition(vece);
				treehurt->spr->runAction(RepeatForever::create(treehurt->CreateAnimation("idle_TH (%d).png", 4, .25F)));
				this->addChild(treehurt, 4);
				logic->listEnemyTreeHurt.pushBack(treehurt);
			}
		}
	}
#pragma endregion

#pragma region BatEnemy
	if (objects == NULL) return false;
	else {
		auto enemyShowUpPoint = objects->getObjects();
		for (int i = 0; i < enemyShowUpPoint.size(); i++)
		{
			auto bien = enemyShowUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnEnemyBat")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

				float xE = enemyShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yE = enemyShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vece = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;

				batEnemy = BatEnemy::create("Sprites/Gameplay/Enemy/EnemyFly/BatEnemy/Fly/BatFly_01.png");
				auto size = batEnemy->spr->getContentSize();
				batEnemy->setScale(visibleSize.width / size.width * .025F, visibleSize.height / size.height * .025F);
				batEnemy->setPosition(vece);
				batEnemy->spr->runAction(RepeatForever::create(batEnemy->CreateAnimation("BatFly_0%d.png", 6, .25F)));
				batEnemy->maxUp = batEnemy->getPositionY() + 100;
				batEnemy->maxDown = batEnemy->getPositionY() - 100;
				this->addChild(batEnemy, 4);
				logic->listBatEnemy.pushBack(batEnemy);
			}
		}
	}
#pragma endregion

#pragma region Spikes
	if (objects == NULL) return false;
	else {
		auto spikes = objects->getObjects();
		for (int i = 0; i < spikes.size(); i++)
		{
			auto bien = spikes.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnSpikes")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

				float x = spikes.at(i).asValueMap()["x"].asDouble() * diffx;
				float y = spikes.at(i).asValueMap()["y"].asDouble() * diffy;
				auto  vect = convertToNodeSpaceAR(Vec2(x, y)) / diffy;

				bubbleEnemy = BubbleEnemy::create("Sprites/Object/Spikes/spike.png");
				auto size = bubbleEnemy->spr->getContentSize();
				bubbleEnemy->setScale(visibleSize.width / size.width * .0225F,
					visibleSize.height / size.height * .04F);
				bubbleEnemy->spr->runAction(RepeatForever::create(RotateBy::create(2.0f, 360)));
				bubbleEnemy->setPosition(vect);
				bubbleEnemy->setName("setup");
				this->addChild(bubbleEnemy, 3);
				logic->listEnemyBubble.pushBack(bubbleEnemy);
			}
		}
	}
#pragma endregion

#pragma region Winzard

	if (objects == NULL) return false;
	else {
		auto enemyShowUpPoint = objects->getObjects();
		for (int i = 0; i < enemyShowUpPoint.size(); i++)
		{
			auto bien = enemyShowUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnEnemyWinzard")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

				float x = enemyShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float y = enemyShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;
				auto  vec = convertToNodeSpaceAR(Vec2(x, y)) / diffy;

				winzard = Winzard::create("Sprites/Gameplay/Enemy/EnemyFly/Winzard/Shoot/winzard-shoot (1).png");
				auto size = winzard->spr->getContentSize();
				winzard->setScale(visibleSize.width / size.width * .03F,
					visibleSize.height / size.height * .09F);
				winzard->setPosition(vec);
				winzard->spr->runAction(RepeatForever::create(winzard->CreateAnimation("winzard_Idle (%d).png",5, 0.15f)));
				logic->winzardSize = winzard->spr->getContentSize();
				this->addChild(winzard, 4);
				logic->listEnemyWinzard.pushBack(winzard);
			}
		}
	}

#pragma endregion

#pragma region SoldierGuard

	if (objects == NULL) return false;
	else {
		auto enemyShowUpPoint = objects->getObjects();
		for (int i = 0; i < enemyShowUpPoint.size(); i++)
		{
			auto bien = enemyShowUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnSoldierGuard")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

				float x = enemyShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float y = enemyShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;
				auto  vec = convertToNodeSpaceAR(Vec2(x, y)) / diffy;

				soldierguard = SoldierGuard::create("Sprites/Gameplay/Enemy/EnemyOnland/SoldierGuard/Idle/soldierguard_idle (1).png");
				auto size = soldierguard->spr->getContentSize();
				soldierguard->setScale(visibleSize.width / size.width * .05F, visibleSize.height / size.height * .09F);
				soldierguard->setPosition(vec);
				soldierguard->spr->runAction(RepeatForever::create(soldierguard->CreateAnimation("soldierguard_idle (%d).png", 2, .25F)));
				this->addChild(soldierguard, 4);
				logic->listEnemySoldierGuard.pushBack(soldierguard);
			}
		}
	}
#pragma endregion

#pragma region LothricKnight
	if (objects == NULL) return false;
	else {
		auto enemyShowUpPoint = objects->getObjects();
		for (int i = 0; i < enemyShowUpPoint.size(); i++)
		{
			auto bien = enemyShowUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnLothricKnight")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

				float x = enemyShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float y = enemyShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;
				auto  vec = convertToNodeSpaceAR(Vec2(x, y)) / diffy;

				lothricknight = LothricKnight::create("Sprites/Gameplay/Enemy/EnemyOnland/LothricKnight/Idle/LothricKnight_idle (1).png");
				auto size = lothricknight->spr->getContentSize();
				lothricknight->setScale(visibleSize.width / size.width * .029F, visibleSize.height / size.height * .09F);
				lothricknight->setPosition(vec);
				this->addChild(lothricknight, 4);
				lothricknight->spr->runAction(RepeatForever::create(lothricknight->CreateAnimation("LothricKnight_idle (%d).png", 4, .25F)));
				logic->listEnemyLothricKnight.pushBack(lothricknight);
			}
		}
	}
#pragma endregion

	return true;
}
bool TileMapGame::GetObjectClimb()
{
	auto visibleSize = Director::getInstance()->getVisibleSize();
	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");
	auto enemyShowUpPoint = objects->getObjects();
	for (int i = 0; i < enemyShowUpPoint.size(); i++)
	{
		auto bien = enemyShowUpPoint.at(i).asValueMap();
		if (bien["name"].asString() == "spawClimb")
		{
			float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
			float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

			float x = enemyShowUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
			float y = enemyShowUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;
			auto  vec = convertToNodeSpaceAR(Vec2(x, y)) / diffy;

			climb = Climb::createClimb("Sprites/Object/Climb/climb.png");
			climb->setPosition(vec);
			this->addChild(climb, 4);
			climb->maxUp = climb->getPositionY() + 100;
			climb->maxDown = climb->getPositionY() - 100;
			logic->listClimb.pushBack(climb);
		}
	}
	return true;

}
bool TileMapGame::GetObjectObstancle()
{
	auto visibleSize = Director::getInstance()->getVisibleSize();
	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");

	if (objects == NULL) return false;
	else
	{
		auto obstancleUpPoint = objects->getObjects();
		for (int i = 0; i < obstancleUpPoint.size(); i++)
		{
			auto bien = obstancleUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnObstancle")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;
				float xE = obstancleUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yE = obstancleUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vecT = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;
				traps = Traps::create("Sprites/Object/Obstancle/Traps/trap/traps.png");
				traps->setPosition(vecT);
				this->addChild(traps);
				logic->listTraps.pushBack(traps);
			}
		}
	}
	TMXObjectGroup* objectsDead = tileMap->getObjectGroup("ObjectDead");

	if (objectsDead == NULL) return false;
	else
	{
		auto D = objectsDead->getObject("spawnObjectDead");
		float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
		float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;
		float xE = D["x"].asDouble() * diffx;
		float yE = D["y"].asDouble() * diffy;

		auto  vece = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;

		auto nodebody = Node::create();
		nodebody->setContentSize(Size(D["width"].asFloat(), D["height"].asFloat()));
		auto NodePhysicCol = PhysicsBody::createBox(nodebody->getContentSize());

		NodePhysicCol->setCollisionBitmask(OBJECT_DEAD_COLLITION);
		NodePhysicCol->setContactTestBitmask(OBJECT_DEAD_COLLITION);
		NodePhysicCol->setDynamic(false);
		nodebody->setPosition(vece);
		nodebody->setTag(SET_TAG_DEAD);
		nodebody->setPhysicsBody(NodePhysicCol);
		this->addChild(nodebody);
		logic->sizeObjectDead = nodebody->getContentSize();
		logic->posObjectDead = nodebody->getPosition();
	}
	return true;
}
void TileMapGame::GetObjectTarget() {
	auto visibleSize = Director::getInstance()->getVisibleSize();
	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");
	if (objects == NULL) return;
	else
	{
		auto obstancleUpPoint = objects->getObjects();
		for (int i = 0; i < obstancleUpPoint.size(); i++)
		{
			auto bien = obstancleUpPoint.at(i).asValueMap();
			if (bien["name"].asString() == "SpawnChest")
			{
				float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
				float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;
				float xE = obstancleUpPoint.at(i).asValueMap()["x"].asDouble() * diffx;
				float yE = obstancleUpPoint.at(i).asValueMap()["y"].asDouble() * diffy;

				auto  vecT = convertToNodeSpaceAR(Vec2(xE, yE)) / diffy;
				chest = Chest::create("Sprites/Chest/chest_01.png");
				auto size = chest->spr->getContentSize();
				chest->setScale(visibleSize.width / size.width * .025F, 
					visibleSize.height / size.height * .04F);
				chest->setPosition(vecT);
				this->addChild(chest, 5);
				logic->listChest.pushBack(chest);
			}
		}

		auto congChua = objects->getObject("SpawnCongChua");
		if (!congChua.empty())
		{
			float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
			float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

			float xC = congChua["x"].asDouble() * diffx;
			float yC = congChua["y"].asDouble() * diffy;

			auto  vece = convertToNodeSpaceAR(Vec2(xC, yC)) / diffy;

			target = Target::create("Sprites/Object/CongChua/CongChuaIdle (1).png");
			auto size = target->spr->getContentSize();
			target->setScale(visibleSize.width / size.width * .0175F, 
				visibleSize.height / size.height * .0475F);
			target->setPosition(vece);
			this->addChild(target, 6);
		}

		auto king = objects->getObject("SpawnKing");
		if (!king.empty())
		{
			float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
			float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

			float xC = king["x"].asDouble() * diffx;
			float yC = king["y"].asDouble() * diffy;

			auto  vece = convertToNodeSpaceAR(Vec2(xC, yC)) / diffy;

			npc = NPC::create("Sprites/Object/king/kingIdle/king (1).png");
			auto size = npc->spr->getContentSize();
			npc->setScale(visibleSize.width / size.width * .15F, 
				visibleSize.height / size.height * .1F);
			npc->setPosition(vece);
			this->addChild(npc, 2);
		}

		auto bonfire = objects->getObject("SpawnBonfire");
		if (!bonfire.empty())
		{
			float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
			float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

			float xC = bonfire["x"].asDouble() * diffx;
			float yC = bonfire["y"].asDouble() * diffy;

			auto  vece = convertToNodeSpaceAR(Vec2(xC, yC)) / diffy;

			npc = NPC::createFireborn("Sprites/Object/bonfires/bonfire (1).png");
			auto size = npc->spr->getContentSize();
			npc->setScale(visibleSize.width / size.width * .035F, 
				visibleSize.height / size.height * .075F);
			npc->setPosition(vece);
			this->addChild(npc, 10);
		}
		//else return;
	}

}
void TileMapGame::GetObjectDoorStart() {
	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");
	if (objects == NULL) return;
	else {
		auto doorStart = objects->getObject("SpawnDoorStart");
		if (!doorStart.empty())
		{
			float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
			float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

			float xDT = doorStart["x"].asDouble() * diffx;
			float yDT = doorStart["y"].asDouble() * diffy;

			auto  vecDT = convertToNodeSpaceAR(Vec2(xDT, yDT)) / diffy;

			door = Door::createSprDoorStart("Sprites/Map/pops/door-start.png");
			door->setPosition(vecDT);
			this->addChild(door);
		}
		else return;
	}
}
void TileMapGame::GetObjectDoorEnd() {

	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");
	if (objects == NULL) return;
	else {
		auto doorEnd = objects->getObject("SpawnDoorEnd");
		if (!doorEnd.empty())
		{
			float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
			float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

			float xDE = doorEnd["x"].asDouble() * diffx;
			float yDE = doorEnd["y"].asDouble() * diffy;

			auto  vecDE = convertToNodeSpaceAR(Vec2(xDE, yDE)) / diffy;

			door = Door::createSprDoorEnd("Sprites/Map/pops/door-end.png");
			door->setPosition(vecDE);
			this->addChild(door);
		}
		else return;
	}
}
void TileMapGame::GetObjectDoorEndGame() {

	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");
	if (objects == NULL) return;
	else {
		auto doorEnd = objects->getObject("SpawDoorEndGame");
		if (!doorEnd.empty())
		{
			float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
			float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

			float xDE = doorEnd["x"].asDouble() * diffx;
			float yDE = doorEnd["y"].asDouble() * diffy;

			auto  vecDE = convertToNodeSpaceAR(Vec2(xDE, yDE)) / diffy;

			door = Door::createSprDoorEndGame("Sprites/Door/doorEnd (1).png");
			door->setPosition(vecDE);
			this->addChild(door, 1);
		}
		else return;
	}
}
void TileMapGame::GetObjectBuffalo()
{
	auto visibleSize = Director::getInstance()->getVisibleSize();
	TMXObjectGroup* objects = tileMap->getObjectGroup("ObjectGame");
	if (objects == NULL) return;
	else {
		auto bossBuffalo = objects->getObject("SpawnBuffalo");
		if (!bossBuffalo.empty())
		{
			float diffx = tileMap->getMapSize().width * tileMap->getTileSize().width / tileMap->getContentSize().width;
			float diffy = tileMap->getMapSize().height * tileMap->getTileSize().height / tileMap->getContentSize().height;

			float xDE = bossBuffalo["x"].asDouble() * diffx;
			float yDE = bossBuffalo["y"].asDouble() * diffy;

			auto  vecDE = convertToNodeSpaceAR(Vec2(xDE, yDE)) / diffy;

			buffalo = Buffalo::create("Sprites/Gameplay/Enemy/Boss/Buffalo/Idle/Buffalo_Idle (1).png");
			auto size = buffalo->spr->getContentSize();
			buffalo->setScale(visibleSize.width / size.width * .25F, visibleSize.height / size.height * .5F);
			buffalo->setPosition(vecDE);
			buffalo->state = STATE::IDLE;
			buffalo->spr->runAction(RepeatForever::create(buffalo->Unit::CreateAnimation("Buffalo_Idle (%d).png", 5, .3F)));
			this->addChild(buffalo, 4);
		}
		else return;
	}
}
